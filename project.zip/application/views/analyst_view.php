<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?= $page ?> Page</title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper">
			<?php $this->load->view('header'); ?>
			<?php $this->load->view('sidebar'); ?>
			<div class="page-wrapper">
				<div class="content container-fluid">
					<div class="page-header" style="margin-top: auto;">
						<span><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceSubserviceName['client_name'] ?> <br>
							<b>Service :</b> <?= $clientServiceSubserviceName['service_name'] ?>&nbsp;&nbsp; <b>Subservice :</b> <?= $clientServiceSubserviceName['subservice_name'] ?>
						</span>
						<!-- <span style="float: left;"><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceName->client_name ?> <br>
							<b>Service :</b> <?= $clientServiceName->service ?><br>
						</span> -->
					</div>
				</div>

				<div class="container-fluid">
					<div class="email-wrap">
						<div class="row">

							<!-- Left Box -->
								<div class="col-xl-4 col-md-6 xl-40">
									<div class="card">
										<div class="card-header">
											<h4 class="card-title float-left mt-2">My Pipeline</h4>
										</div>
										<div class="table-responsive">
											<table class="table table-hover table-center">
												<tbody>
													<tr>
														<td class="text-nowrap"><a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#assignedModal">Total Assign Loans</a></td>	
														<?php 
															$count=0;
															foreach($loans as $assignedLoans) {
																if($assignedLoans['review_status'] == 'assigned'){
																	$count = $count+1;
																}
															}
														?>
														<td class="text-nowrap" style="text-align: end; color: <?= ($count > 0)?'green':'red'; ?>;">
															<b>(<?= $count ?>)</b>
														</td>	
													</tr>
													<tr>
														<td class="text-nowrap"><a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#pendingModal">Total Pending Loans</a></td>
														<?php 
															$count=0;
															foreach($loans as $pendingLoans) {
																if($pendingLoans['review_status'] == 'pending'){
																	$count = $count+1;
																}
															}
														?>
														<td class="text-nowrap" style="text-align: end; color: <?= ($count > 0)?'green':'red'; ?>;">
															<b>(<?= $count ?>)</b>
														</td>	
													</tr>
													<tr>
														<td class="text-nowrap"><a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#todaysCompletedModal">Today's Completed Loans</a></td>
														<?php 
															$count=0;
															foreach($todaysCompletedLoans as $completedLoans) {
																if($completedLoans['review_status'] == 'completed'){
																	$count = $count+1;
																}
															}
														?>
														<td class="text-nowrap" style="text-align: end; color: <?= ($count > 0)?'green':'red'; ?>;">
															<b>(<?= $count ?>)</b>
														</td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
									<!-- <div class="card">
										<div class="card-header">
											<h4 class="card-title float-left mt-2">MTD Production Summary</h4>
										</div>
										<div class="table-responsive">
											<table class="table table-hover table-center">
												<tbody>
													<tr>
														<td class="text-nowrap">Initial</td>	
														<td class="text-nowrap" style="text-align: end;">(0)</td>	
													</tr>
													<tr>
														<td class="text-nowrap">Condtion</td>
														<td class="text-nowrap" style="text-align: end;">(0)</td>	
													</tr>
														<tr>
															<td class="text-nowrap">CTC</td>
															<td class="text-nowrap" style="text-align: end;">(0)</td>	
														</tr>
												</tbody>
											</table>
											<div class="card-body">
												<div class="alert alert-warning alert-dismissible fade show" role="alert"><strong></strong> Coming Soon...
											</div>
											</div>
										</div>
									</div> -->
								</div>
							<!-- /. Left Box -->

							<!-- Right Box -->
								<div class="col-xl-8 col-md-12 xl-60">
									<div class="card">
										<div class="card card-table flex-fill">
											<div class="card-header">
												<!-- <h4 class="card-title float-left mt-2">Booking</h4> -->
												<?php $this->load->view('notification'); ?>
												<div class="col-xl-4">
													<select class="form-control shadow-sm" onchange="location = this.value;" style="font-weight: bold; color: #009689;border: aliceblue;">
														<?php 
															foreach($reviewType as $row) {
																$explode = explode(",", $clientServiceSubserviceName['review_type_id']); 
																if(in_array($row['review_type_id'], $explode)){
																	$explode = explode(",", $empDetails['review_type_id']); 
																	if(in_array($row['review_type_id'], $explode)) {
																		if($row['review_type_id'] == $this->session->userdata('review_type_id')) { ?>
																			<option value="<?= base_url('user/reviewType/'.$row['review_type_id']) ?>"><?= $row['review_type'] ?></option>
																		<?php }
																	}

																}
															}

															foreach($reviewType as $row) {
																$explode = explode(",", $clientServiceSubserviceName['review_type_id']); 
																if(in_array($row['review_type_id'], $explode)){
																	$explode = explode(",", $empDetails['review_type_id']); 
																	if(in_array($row['review_type_id'], $explode)){?>
																		<option value="<?= base_url('user/reviewType/'.$row['review_type_id']) ?>"><?= $row['review_type'] ?></option>
																	<?php }

																}
															}
														?>
														<!-- <option><?= $row['review_type'] ?></option> -->
													</select>
												</div>												
											</div><br>
											<div class="card-body">

												<?php if(!empty($loans)) { 
														$progress_loans=0;														
														foreach ($loans as $row) {
															if($row['review_status'] == 'progress'){
																$progress_loans = 1;
																break;
															}
														}

														// print($progress_loans);exit();

														if($progress_loans != 1){
															foreach ($loans as $row) {
																if($row['review_status'] == 'assigned'){
																	break;
																}
															}
														}
														

													if($row['review_status'] == 'progress') { 
														$presentDate = new DateTime($currentDate);
										                $oldDate = new DateTime($row['start_date']);
										                $timeDiff = $oldDate->diff($presentDate);
														?>
														<!-- Inprogress Loans -->
														<div class="col-xl-12">
															<div class="row">
																<div class="col-xl-6 col-md-6 xl-60">
																	<span style="font-size: 20px;"><strong>#<?= $row['loan_no'] ?></strong></span> <br>
																	<span>Received D&T : <?= date('m/d/Y h:i A', strtotime($row['received_date'])) ?></span> <br>
																	<span>Assigned D&T : <?= date('m/d/Y h:i A', strtotime($row['assigned_date'])) ?></span> <br>
																	<span>SLA D&T : <?= date('m/d/Y h:i A', strtotime($row['sla_date'])) ?></span> <br>
																</div>
																<div class="col-xl-6 col-md-6 xl-60">
																	<span>Borrower Name : <?= $row['borrower_name'] ?></span> <br>																	
																	<span>State : <?= $row['state'] ?></span> 
																		<?php if($row['state_type'] == 0){
																			echo "<span style='color: red;'> (NL)</span>";
																		} ?><br>
																	<span>Channel : 
																		<?php 
																			foreach ($channel as $channelData) {
																				if($channelData['channel_id'] == $row['channel_id']){
																					echo $channelData['channel'];
																				}
																			}
																		?>
																	</span> <br>
																	<span>Started D&T : <?= date('m/d/Y h:i A', strtotime($row['start_date'])) ?></span> <br>
																	<span>Since : <?= $timeDiff->format('%h hr %i min') ?></span>
																</div>
															</div><br>
															<li class="list-divider" style="color: #ffffff;"></li><br>
															<!-- border-bottom: 0.5rem solid;border-bottom-color: #ffbc34!important; -->
															<div class="row">
																<div class="col-xl-12 col-md-12 xl-60">

																	<?= form_open('user/analyst_view'); ?>
																		<div class="row">
																			<input type="hidden" name="id" value="<?= base64_encode($row['id']) ?>">
																			<div class="col-md-12">	
																				<div class="row">
																					<div class="col-md-3">
																						<div class="form-group">
																							<label>Review Status*:</label>
																							<select class="form-control" name="review_status" id="review_status" onchange="changeStatus()">
																								<option value="">Select...</option>
																								<option value="pulledback">Pulledback</option>
																								<option value="pending">Pending</option>
																								<option value="completed">Completed</option>
																							</select>
																							<?= form_error('review_status','<span style="color: red;">','</span>') ?>
																						</div>
																					</div>																				
																					<div class="col-md-3">
																						<div class="form-group">
																							<label>Loan Type*:</label>
																							<select class="form-control" name="loan_type_id">
																								<option value="">Select...</option>
																								<?php 
																									foreach($loan_type as $loanType) {?>
																										<option value="<?= $loanType['loan_type_id'] ?>"><?= $loanType['loan_type'] ?></option>
																									<?php 
																									}
																								?>
																							</select>
																							<?= form_error('loan_type','<span style="color: red;">','</span>') ?>	
																						</div>
																					</div>
																					<div class="col-md-3">
																						<div class="form-group">
																							<label>Transaction Type*:</label>
																							<select class="form-control" name="transaction_type" id="transaction_type" onchange="changeStatus()">
																								<option value="">Select...</option>
																								<option value="Purchase" id="purchase">Purchase</option>
																								<option value="Refinance">Refinance</option>
																							</select>
																							<?= form_error('transaction_type','<span style="color: red;">','</span>') ?>	
																						</div>
																					</div>
																					<div class="col-md-3" id="loan_purpose" style="display: none;">
																						<div class="form-group">
																							<label>Loan Purpose*:</label>
																							<select class="form-control" name="loan_purpose">
																								<option value="">Select...</option>
																								<option value="Cash-out">Cash-out</option>
																								<option value="No Cash-out">No Cash-out</option>
																								<option value="Limited Cash-out">Limited Cash-out</option>
																							</select>
																							<!-- <?= form_error('loan_purpose','<span style="color: red;">','</span>') ?>	 -->
																						</div>
																					</div>
																				</div>

																				<div class="row">
																					<?php if($row['state'] == NULL) { ?>
																						<div class="col-md-4">
																							<div class="form-group">
																								<label>State:</label>
																								<select class="js-example-basic-single col-sm-12" name="state" id="validationCustom04" required>
																									<option value="">Select...</option>
																									<?php 
																										foreach ($stateList as $state) { ?>
																											<option value="<?= $state['postal_name'] ?>"><?= $state['state_name'] ?></option>
																										<?php }
																									?>
																								</select>
																								<!-- <?= form_error('blue_print','<span style="color: red;">','</span>') ?>	 -->
																							</div>
																						</div>
																					<?php } ?>

																					<?php 
																						if(($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_03' && $this->session->userdata('subservice_id') == 'SR_003') || ($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_04' && $this->session->userdata('subservice_id') == 'SR_004')) {
																							if($row['team'] == 1) { ?>
																								<div class="col-md-6" id="uw_emp" style="display: none;">
																									<div class="form-group">
																										<?php 
																											if($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_03' && $this->session->userdata('subservice_id') == 'SR_003'){ ?>
																												<label>UW Name*:</label>
																											<?php } elseif($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_04' && $this->session->userdata('subservice_id') == 'SR_004') { ?> 
																												<label>Processor Name*:</label>
																											<?php }
																										?>
																										
																										<select class="form-control" name="emp_id">
																											<option value="">--Select--</option>
																											<?php 
																												foreach($analystDetails as $analyst) {
																													if($analyst['user_type'] == 'user4' || $analyst['user_type'] == 'user5' || $analyst['user_type'] == 'user6'){ 
																														if($row['client_id'] == $this->session->userdata('client_id') && $row['service_id'] == $this->session->userdata('service_id') && $row['subservice_id'] == $this->session->userdata('subservice_id') && $row['review_type_id'] == $this->session->userdata('review_type_id')){ 
																															if($clientServiceSubserviceName['client_id'] == $this->session->userdata('client_id') && $clientServiceSubserviceName['service_id'] == $this->session->userdata('service_id') && $clientServiceSubserviceName['subservice_id'] == $this->session->userdata('subservice_id')) { 
																																$explodeSkillset = explode(',', $analyst['skillset']);
																																if(in_array($clientServiceSubserviceName['id'], $explodeSkillset)) { 
																																	$explodeChannel = explode(',', $analyst['channel_id']);
																																	if(in_array($row['channel_id'], $explodeChannel)) { 
																																		if($analyst['team'] == 0) {?>
																																			<option value="<?= $analyst['emp_id'] ?>"><?= $analyst['emp_fname'].' '.$analyst['emp_lname'] ?></option>
																																	<?php }
																																	}
																																}
																															}
																														}
																													}
																												}
																											?>
																										</select>
																										<?= form_error('emp_id','<span style="color: red;">','</span>') ?>
																									</div>
																								</div>
																							<?php } 
																						}

																					?>

																					<?php if($this->session->userdata('client_id') == 'CL_85' && $this->session->userdata('service_id') == 'SR_04' && $this->session->userdata('subservice_id') == 'SR_004') { ?>
																						<div class="col-md-4">
																							<div class="form-group">
																								<label>Income Type:</label>
																								<select class="form-control" name="income_type" required>
																									<option value="">Select...</option>
																									<option value="Salaried">Salaried</option>
																									<option value="Self-employee">Self-employee</option>
																									<option value="Other Income">Other Income</option>
																								</select>
																							</div>
																						</div>
																					<?php } ?>
																					
																					<?php if($row['blue_print'] == 0) { ?>
																						<div class="col-md-2">
																							<div class="form-group">
																								<label>Blue Print:</label>
																								<select class="form-control" name="blue_print">
																									<option value="">Select...</option>
																									<option value="1">Yes</option>
																									<option value="0">No</option>
																								</select>
																								<?= form_error('blue_print','<span style="color: red;">','</span>') ?>	
																							</div>
																						</div>
																					<?php } ?>
																				</div>

																				<div class="row">
																					<div class="col-md-12">
																						<div class="form-group">
																							<label>Comments*:</label>
																								<textarea rows="5" cols="5" class="form-control" placeholder="Enter text here" name="comments"></textarea>
																								<?= form_error('comments','<span style="color: red;">','</span>') ?>
																								<?= form_error('comments','<span style="color: red;">','</span>') ?>
																						</div>
																					</div>
																				</div>

																				<div class="card-footer">
																					<div class="text-right">
																						<input type="submit" name="complete_activity" Value="Complete Activity" class="btn btn-primary btn-sm">
																					</div>
																				</div>
																			</div>
																		</div>
																	<?= form_close(); ?>

																</div>
															</div>														
														</div>
													<?php }elseif($row['review_status'] == 'assigned') { ?>
														<!-- Assigned Loans -->
														<div class="col-xl-12">
															<?= form_open('user/start_activity');  ?>
																<div class="row">
																	<input type="hidden" name="id" value="<?= $row['id'] ?>">
																	<div class="col-xl-6 col-md-6 xl-60">
																		<span style="font-size: 20px;"><strong>#<?= $row['loan_no'] ?></strong></span> <br>
																		<span>Received D&T : <?= date('m/d/Y h:i A', strtotime($row['received_date'])) ?> </span> <br><br>
																		<span>Assigned D&T : <?= date('m/d/Y h:i A', strtotime($row['assigned_date'])) ?> </span> <br>
																		<span>SLA D&T : <?= date('m/d/Y h:i A', strtotime($row['sla_date'])) ?> </span> <br>
																	</div>
																	<div class="col-xl-6 col-md-6 xl-60">
																		<!-- <span>Client Name : <?= $row['client_id'] ?></span> <br> -->
																		<!-- <span>Service : <?= $row['client_id'] ?></span> <br> -->
																		<span>Borrower Name : <?= $row['borrower_name'] ?></span> <br>																		
																		<span>Channel : 
																			<?php 
																				foreach ($channel as $channelData) {
																					if($channelData['channel_id'] == $row['channel_id']){
																						echo $channelData['channel'];
																					}
																				}
																			?>
																		</span> <br>

																		<div class="row">
																			<div class="col-md-2">State :</div>																			
																				<div class="col-md-6">
																					<?php 
																						if($row['state'] != NULL){
																							echo $row['state'];
																							if($row['state_type'] == 0){
																								echo "<span style='color: red;'> (NL)</span>";
																							}
																						}else {?>
																							<div class="form-group">
																								<select class="js-example-basic-single col-sm-12" name="state" id="validationCustom04" required>
																									<option value="">Select...</option>
																									<?php 
																										foreach ($stateList as $state) { ?>
																											<option value="<?= $state['postal_name'] ?>"><?= $state['state_name']."(".$state['postal_name'].")" ?></option>
																										<?php }
																									?>
																								</select>
																								<!-- <?= form_error('blue_print','<span style="color: red;">','</span>') ?>	 -->
																							</div>
																						<?php }
																					?>
																				</div>
																				<?php if($row['state'] == NULL){ ?>
																					<div class="col-md-2">
																						<!-- <button class="btn btn-primary btn-xs" style="height: 25px; padding: 0px 20px;">Save</button> -->
																						<input type="submit" name="btn_save" value="Save" class="btn btn-primary btn-xs" style="height: 25px; padding: 0px 20px;">
																					</div>
																				<?php } ?>
																		</div>
																	</div>
																</div>
																<li class="list-divider" style="color: #ffffff;"></li><br>
																<!-- <a href="<?= base_url('user/start_activity/'.base64_encode($row['id'])); ?>" class="btn btn-primary float-right veiwbutton">Start Activity</a> -->
																<?php if($row['state'] != NULL) { ?>
																	<div class="text-right">
																		<button type="submit" class="btn btn-primary">Start Activity</button>
																	</div>
																<?php }else{ ?>
																	<div class="col-xl-12">
																		<div class="alert alert-warning alert-dismissible fade show" role="alert">
																			<strong>State</strong> is blank now, so please select the <b>State</b> first.
																		</div>
																	</div>
																<?php } ?>
															</form>
														</div> 
													<?php }else{ ?>
														<!-- No loans -->
														<div class="col-xl-12">
															<div class="alert alert-danger alert-dismissible fade show" role="alert">
																<strong><i class="fa fa-exclamation"></i></strong> There are no assign <b>Loans</b> in the pipeline!
															</div>
														</div>
													<?php }
												}else{ ?>
													<!-- No loans -->
														<div class="col-xl-12">
															<div class="alert alert-danger alert-dismissible fade show" role="alert">
																<strong><i class="fa fa-exclamation"></i></strong> There are no assign <b>Loans</b> in the pipeline!
															</div>
														</div>
												<?php } ?>
												

											</div>
										</div>
									</div>
								</div>

							<!-- /. Right Box -->

						</div>
					</div>
				</div>

			</div>
		</div>
		<?php require 'assets/js.php' ?> 
		<?php $this->load->view('footer'); ?>


		<script type="text/javascript">
		    function changeStatus(){

		    	var review_status = document.getElementById("review_status");
		    	var transaction_type = document.getElementById("transaction_type");
		    
		    	if (review_status.value == "completed") {
		            document.getElementById("uw_emp").style.display="block";
		        }else{
		            document.getElementById("uw_emp").style.display="none";
		        }

		        if (transaction_type.value == "Refinance") {
		            document.getElementById("loan_purpose").style.display="block";
		        }else{
		            document.getElementById("loan_purpose").style.display="none";
		        }

		    }
		</script>

		<!-- assigne Modal -->
			<div class="modal fade" id="assignedModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  <div class="modal-dialog modal-xl">
			    <div class="modal-content">
			      <div class="modal-header">
			        <h5 class="modal-title" id="exampleModalLabel">Assigned Loans :</h5>
			        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
			      </div>   
				      <div class="modal-body">
				        <table id="example1" class="table table-striped">
							<thead>
								<tr>
									<th>Loan</th>
									<th>Received D&T</th>
									<th>Borrower</th>
									<th>Channel</th>
									<th>Assigned D&T</th>									
									<th>Priority</th>
									<th>SLA</th>
									<th>Action</th>
								</tr>
							</thead>
							
							<tbody>
								<?php
									foreach($loans as $row) {
										if($row['review_status'] == 'assigned'){ 

											// form_open('user/start_activity');
											?>


											<tr>
												<?= form_open('user/start_activity') ?>
													<input type="hidden" name="id" value="<?= $row['id'] ?>">
													<td><?= $row['loan_no'] ?></td>
													<td><?= date('m/d/Y h:i A', strtotime($row['received_date'])) ?></td>
													<td><?= $row['borrower_name'] ?></td>
													<td>
														<?php 
															foreach ($channel as $channelData) {
																if($channelData['channel_id'] == $row['channel_id']){
																	echo $channelData['channel'];
																}
															}
														?>
													</td>
													<td><?= date('m/d/Y h:i A', strtotime($row['assigned_date'])) ?></td>
													<td>
														<?php 
															if($row['priority'] == 1){
																echo "Low";
															}elseif($row['priority'] == 2){
																echo "Medium";
															}elseif($row['priority'] == 3){
																echo "High";
															}elseif($row['priority'] == 4){
																echo "Rush";
															}
														?>
													</td>
													<td>
														<?php 
															if($currentDate <= $row['sla_date']){
																$currentDate = date('Y-m-d', strtotime($currentDate));
																$sla_date = date('Y-m-d', strtotime($row['sla_date']));
																if($currentDate == $sla_date){ ?>
																	<span class="blink" style="color: green;  animation: blinker 1.6s linear infinite;"><?= date('m/d/Y h:i A', strtotime($row['sla_date'])) ?></span>
																<?php }else{ ?>
																	<span class="blink" style="color: green;"><?= date('m/d/Y h:i A', strtotime($row['sla_date'])) ?></span>	
																<?php }
															}else{ ?>
																<span class="blink" style="color: red;"><?= date('m/d/Y h:i A', strtotime($row['sla_date'])) ?></span>
															<?php }
														?>
													</td>
													<td><!-- <i class="fa fa-info-circle" aria-hidden="true" style="color: #009688;"></i> -->
														<!-- <a href="" style="background-color: #009688; color: #ffffff; padding-left: 5px; padding-right: 5px; padding-bottom: 3px; border-radius: 4px;"><i class="fa fa-play fa-xs" aria-hidden="true"></i> Start</a> -->
														<?php if($progress_loans != 1) { ?>
															<!-- <input type="submit" name="" value="Start" class="btn btn-primary btn-sm"> -->
														<?php } ?>
														<a href="<?= base_url('user/getLoanInformationById/').base64_encode($row['id'])?>"><i class="fa fa-info-circle" aria-hidden="true" style="color: #009688;"></i></a>
													</td>
												</form>
											</tr>
											
										<?php }
									}
								?>
																			
							</tbody>
							
						</table>
				      </div>
			    </div>
			  </div>
			</div>
		<!-- end Modal -->

		<!-- Pending Modal -->
			<div class="modal fade" id="pendingModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  <div class="modal-dialog modal-xl">
			    <div class="modal-content">
			      <div class="modal-header">
			        <h5 class="modal-title" id="exampleModalLabel">Pending Loans :</h5>
			        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
			      </div>   
				      <div class="modal-body">
				        <table id="example2" class="table table-striped">
							<thead>
								<tr>
									<th>Loan</th>
									<th>Received D&T</th>
									<th>Assigned D&T</th>
									<th>Loan Type</th>
									<th>Priority</th>
									<th>SLA</th>
									<th>Action</th>
								</tr>
							</thead>
							
							<tbody>
								<?php
									foreach($loans as $row) {
										if($row['review_status'] == 'pending'){ 

											// form_open('user/start_activity');
											?>


											<tr>
												<?= form_open('user/start_activity') ?>
													<input type="hidden" name="id" value="<?= $row['id'] ?>">
													<td><?= $row['loan_no'] ?></td>
													<td><?= date('m/d/Y h:i A', strtotime($row['received_date'])) ?></td>
													<td><?= date('m/d/Y h:i A', strtotime($row['assigned_date'])) ?></td>
													<td>
														<?php 
															foreach($loan_type as $loanType) {
																if($loanType['loan_type_id'] == $row['loan_type_id']){
																	echo $loanType['loan_type'];
																}
															}
														?>
													</td>
													<td>
														<?php 
															if($row['priority'] == 1){
																echo "Low";
															}elseif($row['priority'] == 2){
																echo "Medium";
															}elseif($row['priority'] == 3){
																echo "High";
															}elseif($row['priority'] == 4){
																echo "Rush";
															}
														?>
													</td>
													<td>
														<?php 
															if($currentDate <= $row['sla_date']){
																$currentDate = date('Y-m-d', strtotime($currentDate));
																$sla_date = date('Y-m-d', strtotime($row['sla_date']));
																if($currentDate == $sla_date){ ?>
																	<span class="blink" style="color: green;  animation: blinker 1.6s linear infinite;"><?= date('m/d/Y h:i A', strtotime($row['sla_date'])) ?></span>
																<?php }else{ ?>
																	<span class="blink" style="color: green;"><?= date('m/d/Y h:i A', strtotime($row['sla_date'])) ?></span>	
																<?php }
															}else{ ?>
																<span class="blink" style="color: red;"><?= date('m/d/Y h:i A', strtotime($row['sla_date'])) ?></span>
															<?php }
														?>
													</td>
													<td><!-- <i class="fa fa-info-circle" aria-hidden="true" style="color: #009688;"></i> -->
														<!-- <a href="" style="background-color: #009688; color: #ffffff; padding-left: 5px; padding-right: 5px; padding-bottom: 3px; border-radius: 4px;"><i class="fa fa-play fa-xs" aria-hidden="true"></i> Start</a> -->
														<?php if($progress_loans != 1) { ?>
															<!-- <input type="submit" name="" value="Start" class="btn btn-primary btn-sm"> -->
														<?php } ?>
														<a href="<?= base_url('user/getLoanInformationById/').base64_encode($row['id'])?>"><i class="fa fa-info-circle" aria-hidden="true" style="color: #009688;"></i></a>
													</td>
												</form>
											</tr>
											
										<?php }
									}
								?>
																			
							</tbody>
							
						</table>
				      </div>
			    </div>
			  </div>
			</div>
		<!-- end Modal -->

		<!-- Todays Completed Modal -->
			<div class="modal fade" id="todaysCompletedModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  <div class="modal-dialog modal-xl">
			    <div class="modal-content">
			      <div class="modal-header">
			        <h5 class="modal-title" id="exampleModalLabel">Todays Completed Loans :</h5>
			        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
			      </div>   
				      <div class="modal-body">
				        <table id="example3" class="table table-striped">
							<thead>
								<tr>
									<th>Loan</th>
									<th>Received D&T</th>
									<th>Borrower</th>
									<th>State</th>
									<th>Loan Type</th>
									<th>Assigned D&T</th>
									<th>Action</th>
								</tr>
							</thead>
							
							<tbody>
								<?php
									foreach($todaysCompletedLoans as $row) { ?>
										<tr>
											<td><?= $row['loan_no'] ?></td>
											<td><?= date('m/d/Y h:i A', strtotime($row['received_date'])) ?></td>
											<td><?= $row['borrower_name'] ?></td>
											<td><?= $row['state'] ?></td>
											<td>
												<?php 
													foreach($loan_type as $loanType) {
														if($loanType['loan_type_id'] == $row['loan_type_id']){
															echo $loanType['loan_type'];
														}
													}
												?>
											</td>
											<td><?= date('m/d/Y h:i A', strtotime($row['assigned_date'])) ?></td>
											<td><a href="<?= base_url('user/getLoanInformationById/').base64_encode($row['id'])?>"><i class="fa fa-info-circle" aria-hidden="true" style="color: #009688;"></i></a></td>
										</tr>											
								<?php } ?>
																			
							</tbody>
							
						</table>
				      </div>
			    </div>
			  </div>
			</div>
		<!-- end Modal -->



	</body>
</html>