<!-- <footer class="text-right shadow-sm">
  <div class="text-right p-3" style="background-color: #f0f1f2;">
    © 2020 Copyright:
    Designed & Developed by 
    <a class="" href="mailto:Ranganath.N@altisource.com?cc=Kumar.Sumeet@altisource.com;Dibyendu.Sahoo@altisource.com">Dibyendu</a>
  </div>
</footer> -->

<!-- Report Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Export the report :</h5>
	        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">×</span>
			</button>
	      </div>
			<?= form_open('user/export_report'); ?>      
		      <div class="modal-body">
		        <div class="col-md-12">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Form:</label>
								<input type="date" name="fromdate" class="form-control" required="">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>To:</label>
								<input type="date" name="todate" class="form-control" required="">
							</div>
						</div>
					</div>
					<div class="row" style="display: none;">
						<div class="col-md-12">
							<div class="form-group">
								<label>Review Status:</label>
								<select class="form-control" required="">
									<!-- <option value="">Select...</option>
									<option value="pending">Pending</option> -->
									<option value="completed">Completed</option>
								</select>
							</div>
						</div>
					</div>
				</div>
		      </div>
		      <div class="modal-footer">
		        <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
		        <input type="submit" name="export_report" value="Export" class="btn btn-primary btn-sm">
		      </div>
		    </form>
	    </div>
	  </div>
	</div>
