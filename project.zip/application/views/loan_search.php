<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?= $page ?> Page</title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper">
			<?php $this->load->view('header'); ?>
			<?php $this->load->view('sidebar'); ?>
			<div class="page-wrapper">
				<div class="content container-fluid">
					<div class="page-header" style="margin-top: auto;">
						<span><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceSubserviceName['client_name'] ?> <br>
							<b>Service :</b> <?= $clientServiceSubserviceName['service_name'] ?>&nbsp;&nbsp; <b>Subservice :</b> <?= $clientServiceSubserviceName['subservice_name'] ?>
						</span>
						<!-- <span style="float: left;"><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceName->client_name ?> <br>
							<b>Service :</b> <?= $clientServiceName->service ?><br>
						</span> -->
					</div>
				</div>
				<div class="main-wrapper login-body">
					<div class="login-wrapper" style="vertical-align: inherit;">
						<div class="container">
							<div class="loginbox" style="min-height: auto; max-width: 500px;">
								<div class="login-right" style="width: 100%;">
									<div class="login-right-wrap">	
										<p class="account-subtitle">Search the loan no :</p>
										<?php $this->load->view('notification'); ?>								
										<?= form_open('user/loan_information') ?>
											<div class="form-group">
												<input class="form-control" type="text" name="loan_no" placeholder="Enter loan no."> 
												<?php 
													if(!empty($this->session->flashdata('loan_no'))){ ?>
														<span style="color:red;">*<?= $this->session->flashdata('loan_no'); ?></span>
													<?php }
												?>
											</div>
											<div class="form-group">
												<button class="btn btn-primary btn-block" type="submit">Search</button>
											</div>
										<?= form_close(); ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
				
			</div>
		</div>
		<?php require 'assets/js.php' ?> 
		<?php $this->load->view('footer'); ?>
	</body>
</html>