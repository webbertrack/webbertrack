<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?= $page ?> Page</title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper">
			<?php $this->load->view('header'); ?>
			<?php $this->load->view('sidebar'); ?>
			<div class="page-wrapper">
				<div class="content container-fluid">
					<div class="page-header" style="margin-top: auto;">
						<span><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceSubserviceName['client_name'] ?> <br>
							<b>Service :</b> <?= $clientServiceSubserviceName['service_name'] ?>&nbsp;&nbsp; <b>Subservice :</b> <?= $clientServiceSubserviceName['subservice_name'] ?>
						</span>
						<!-- <span style="float: left;"><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceName->client_name ?> <br>
							<b>Service :</b> <?= $clientServiceName->service ?><br>
						</span> -->
					</div>
				</div>

				<div class="container-fluid">
					<div class="email-wrap">
						
						<div class="row">
							<div class="col-md-12 d-flex">
								<div class="card card-table flex-fill">
									<?php if(!empty($this->session->flashdata('success'))) { ?>
										<div class="alert alert-success alert-dismissible fade show" role="alert">
											<?= $this->session->flashdata('success') ?>
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
											<span aria-hidden="true">×</span>
											</button>
										</div>
									<?php }elseif(!empty($this->session->flashdata('error'))) { ?>
										<div class="alert alert-danger alert-dismissible fade show" role="alert">
											<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
											<?= $this->session->flashdata('error') ?>
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
											<span aria-hidden="true">×</span>
											</button>
										</div>
									<?php } ?>									
									<div class="card-header">
										<h4 class="card-title float-left mt-2"><span>My Information</span></h4>
									</div>
									<?= form_open('user/update_my_information') ?>
										<br>
										<div class="card-body">
											<div class="col-md-12 d-flex">
												<input type="hidden" name="id" value="<?= $empDetails['id'] ?>">
												<div class="col-md-12">
													<div class="row">
														<div class="col-md-2">											
															<div class="form-group">
																<label>Emp ID:</label>												
																<input type="text" value="<?= $empDetails['emp_id'] ?>" class="form-control" readonly>
																<?= form_error('emp_id','<span style="color: red;">','</span>') ?>
															</div>
														</div>
														<div class="col-md-3">
															<div class="form-group">
																<label>First Name:</label>
																<input type="text" name="emp_fname" value="<?= $empDetails['emp_fname'] ?>" class="form-control">
																<?= form_error('emp_fname','<span style="color: red;">','</span>') ?>
															</div>
														</div>
														<div class="col-md-3">
															<div class="form-group">
																<label>Last Name:</label>
																<input type="text" name="emp_lname" value="<?= $empDetails['emp_lname'] ?>" class="form-control">
																<?= form_error('emp_lname','<span style="color: red;">','</span>') ?>
															</div>
														</div>
														<div class="col-md-4">
															<div class="form-group">
																<label>Mail ID:</label>
																<input type="email" name="mail_id" value="<?= $empDetails['mail_id'] ?>" class="form-control">
																<?= form_error('mail_id','<span style="color: red;">','</span>') ?>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>	
										<div class="card-footer">
											<input type="submit" name="" class="btn btn-primary btn-sm" value="Update">
										</div>	
									<?= form_close(); ?>															
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-6 d-flex">
								<div class="card card-table flex-fill">
									<?php if(!empty($this->session->flashdata('error1'))) { ?>
										<div class="alert alert-danger alert-dismissible fade show" role="alert">
											<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
											<?= $this->session->flashdata('error1') ?>
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
											<span aria-hidden="true">×</span>
											</button>
										</div>
									<?php } ?>
									<div class="card-header">
										<h4 class="card-title float-left mt-2"><span>Change Password</span></h4>
									</div>
									<br>
									<?= form_open('user/update_password'); ?>
										<div class="card-body">
											<div class="col-md-12 d-flex">
												<input type="hidden" name="id" value="<?= $empDetails['id'] ?>">
												<div class="col-md-12">
													<div class="row">
														<div class="col-md-12">											
															<div class="form-group">
																<label>Current Password:</label>												
																<input type="text" name="current_password" class="form-control">
																<?= form_error('current_password','<span style="color: red;">','</span>') ?>
															</div>
														</div>
														<div class="col-md-12">
															<div class="form-group">
																<label>New Password:</label>
																<input type="text" name="new_password" class="form-control">
																<?= form_error('new_password','<span style="color: red;">','</span>') ?>
															</div>
														</div>
														<div class="col-md-12">
															<div class="form-group">
																<label>Confirm Password:</label>
																<input type="text" name="confirm_password" class="form-control">
																<?= form_error('confirm_password','<span style="color: red;">','</span>') ?>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="card-footer">
											<input type="submit" class="btn btn-primary btn-sm" name="" value="Update">
										</div>
									<?= form_close() ?>																	
								</div>
							</div>
							<div class="col-md-6 d-flex">
								<div class="card card-table flex-fill">
									<div class="card-header">
									<h4 class="card-title float-left mt-2"><span>Note:</span></h4>
									</div>
									<br>
									<div class="card-body">
										<div class="col-md-12 d-flex">
											<input type="hidden" name="id" value="<?= $empDetails['id'] ?>">
											<div class="col-md-12">
												<div class="row">
													<b>
														<ol>
									                      <li> Password field must be at least one lowercase letter.</li><br>
									                      <li> Password field must be at least one uppercase letter.</li><br>
									                      <li> Password field must have at least one number.</li><br>
									                      <li> Password field must be at least 8 characters in length.</li><br>
									                      <li> Password field cannot exceed 32 characters in length.</li><br>
									                      <li> Password field must have at least one special character (!@#$%^&amp;*()\-_=+{};:,&lt;.&gt;ยง~').</li>
									                    </ol>
									                </b>
												</div>
											</div>
										</div>
									</div>																	
								</div>
							</div>
						</div>						
					
					</div>
				</div>

			</div>
		</div>
		<?php require 'assets/js.php' ?> 
		<?php $this->load->view('footer'); ?>

		<script type="text/javascript">
			function delete_empid(id){
				if(confirm("Are you sure, you want to delete this Employee?")){
					window.location.href='<?php echo base_url('user/delete_empid/'); ?>'+id;
				}
			}	
		</script>

	</body>
</html>