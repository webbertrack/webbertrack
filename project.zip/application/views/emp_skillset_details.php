<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?= $page ?> Page</title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper">
			<?php $this->load->view('header'); ?>
			<?php $this->load->view('sidebar'); ?>
			<div class="page-wrapper">
				<div class="content container-fluid">
					<div class="page-header" style="margin-top: auto;">
						<span><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceSubserviceName['client_name'] ?> <br>
							<b>Service :</b> <?= $clientServiceSubserviceName['service_name'] ?>&nbsp;&nbsp; <b>Subservice :</b> <?= $clientServiceSubserviceName['subservice_name'] ?>
						</span>
						<!-- <span style="float: left;"><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceName->client_name ?> <br>
							<b>Service :</b> <?= $clientServiceName->service ?><br>
						</span> -->
					</div>
				</div>

				<div class="container-fluid">
					<div class="email-wrap">
						<div class="row">
							<div class="col-md-12">
								<div class="card">					
									<?php $this->load->view('notification'); ?>
									<div class="card-header text-right">
										<a href="javascript:void(0)" onclick="reset_password(<?= $emp_info['id'] ?>)" class="btn btn-primary btn-sm">Password Resate <i class='fa fa-repeat'></i></a>
									</div>
									<div class="card-body">
										<?= form_open('user/update_skillset') ?>
											<div class="row">
												<input type="hidden" name="id" value="<?= $emp_info['id'] ?>">
												<div class="col-md-12">
													<div class="row">
														<div class="col-md-1">											
															<div class="form-group">
																<label>Emp ID:</label>												
																<input type="text" name="emp_id" value="<?= $emp_info['emp_id'] ?>" class="form-control">
																<?= form_error('emp_id','<span style="color: red;">','</span>') ?>
															</div>
														</div>
														<div class="col-md-2">
															<div class="form-group">
																<label>First Name:</label>
																<input type="text" name="emp_fname" value="<?= $emp_info['emp_fname'] ?>" class="form-control">
																<?= form_error('emp_fname','<span style="color: red;">','</span>') ?>
															</div>
														</div>
														<div class="col-md-2">
															<div class="form-group">
																<label>Last Name:</label>
																<input type="text" name="emp_lname" value="<?= $emp_info['emp_lname'] ?>" class="form-control">
																<?= form_error('emp_lname','<span style="color: red;">','</span>') ?>
															</div>
														</div>
														<div class="col-md-4">
															<div class="form-group">
																<label>Mail ID:</label>
																<input type="email" name="mail_id" value="<?= $emp_info['mail_id'] ?>" class="form-control">
																<?= form_error('mail_id','<span style="color: red;">','</span>') ?>
															</div>
														</div>
														<div class="col-md-3">
															<div class="form-group">
																<label>Usert Type:</label>
																<select class="form-control" name="user_type">	
																	<?php 
																		if($emp_info['user_type'] == 'user4') { ?>
																			<option value="user4">Team Lead</option>																				
																		<?php }elseif($emp_info['user_type'] == 'user4') { ?>
																			<option value="user6">Analsyt</option>	
																		<?php }
																	?>								
																	<?php if($empDetails['user_type'] == 'user3') { ?>														
																		<!-- <option value="">--Select--</option> -->
																		<option value="user4">Team Lead</option>
																		<option value="user6">Analyst</option>
																	<?php }elseif($empDetails['user_type'] == 'user4') { ?>
																		<option value="user6">Analyst</option>
																	<?php } ?>
																</select>
																<?= form_error('user_type','<span style="color: red;">','</span>') ?>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-2">
													<div class="form-group">
														<label>Review Type: <?= form_error('review_type_id','<span style="color: red;">','</span>') ?></label>
														<?php foreach($reviewType as $review_type) { 
															$explode = explode(",", $clientServiceSubserviceName['review_type_id']);						
															if(in_array($review_type['review_type_id'], $explode)){
																$explodeRev = explode(",", $emp_info['review_type_id']) ?>
																<div class="checkbox">
																	<label><input type="checkbox" name="review_type_id[]" value="<?= $review_type['review_type_id'] ?>" <?= (in_array($review_type['review_type_id'], $explodeRev)?'checked':'unchecked') ?>> <?= $review_type['review_type'] ?></label>
																</div>
															<?php }
														} ?>								
													</div>
												</div>
												<div class="col-md-2">
													<div class="form-group">
														<label>Loan Type: <?= form_error('loan_type_id','<span style="color: red;">','</span>') ?></label>
														<?php foreach($loan_type as $loantype) { 
															$explode = explode(",", $emp_info['loan_type_id']);
															?>
															<div class="checkbox">
																<label><input type="checkbox" name="loan_type_id[]" value="<?= $loantype['loan_type_id'] ?>" <?= (in_array($loantype['loan_type_id'], $explode)?'checked':'unchecked') ?>> <?= $loantype['loan_type'] ?></label>
															</div>
														<?php } 
														?>								
													</div>
												</div>

												<?php  
													if(($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_03' && $this->session->userdata('subservice_id') == 'SR_003') || ($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_04' && $this->session->userdata('subservice_id') == 'SR_004') ) { ?>

														<div class="col-md-2">
															<div class="form-group">
																<label>Channel: <?= form_error('channel_id','<span style="color: red;">','</span>') ?></label>
																<?php foreach($channel as $channelName) { 
																	$explode = explode(",", $emp_info['channel_id']);
																	?>
																	<div class="checkbox">
																		<label><input type="checkbox" name="channel_id[]" value="<?= $channelName['channel_id'] ?>" <?= (in_array($channelName['channel_id'], $explode)?'checked':'unchecked') ?>> <?= $channelName['channel'] ?></label>
																	</div>
																<?php } 
																?>								
															</div>
														</div>

													<?php }
												?>

												<div class="col-md-1">
													<div class="form-group">
														<label>Team: <?= form_error('team','<span style="color: red;">','</span>') ?></label>
														<div class="radio">
															<label><input type="radio" name="team" value="1" <?= (($emp_info['team']==1)?'checked':'unchecked') ?>> Offshore</label>
														</div>
														<div class="radio">
															<label><input type="radio" name="team" value="0" <?= (($emp_info['team']==0)?'checked':'unchecked') ?>> Onshore</label>
														</div>								
													</div>
												</div>

												<?php if($emp_info['team']==1) { ?>
													<div class="col-md-2">
														<div class="form-group">
															<label>Pod: </label>
															<select class="js-example-basic-single col-sm-12" name="">	
																<option value="">--Select--</option>
																<?php foreach ($analystDetails as $emp) { 
																	if($clientServiceSubserviceName['id'] == $emp['skillset']) { 
																		if($emp['team'] == 0) { ?>
																			<option value="<?= $emp['id'] ?>"><?= $emp['emp_fname'].' '.$emp['emp_lname'] ?></option>
																	<?php }
																	}
																}?>
															</select>								
														</div>
													</div>
												<?php } ?>
													
												<div class="col-md-2">
													<div class="form-group">
														<label>Status: <?= form_error('status','<span style="color: red;">','</span>') ?></label>
														<div class="radio">
															<label><input type="radio" name="status" value="1" <?= (($emp_info['status']==1)?'checked':'unchecked') ?>> Active</label>
														</div>
														<!-- <div class="radio">
															<label><input type="radio" name="status" value="2" <?= (($emp_info['status']==2)?'checked':'unchecked') ?>> New Joining</label>
														</div> -->
														<div class="radio">
															<label><input type="radio" name="status" value="0" <?= (($emp_info['status']==0)?'checked':'unchecked') ?>> Inactive</label>
														</div>								
													</div>
												</div>
											</div>
											<div class="card-footer">
												<div class="text-right">
													<button type="submit" class="btn btn-primary">Update</button>
												</div>
											</div>
										<?= form_close() ?>
									</div>
								</div>
							</div>
						</div>						
					</div>
				</div>

			</div>
		</div>
		<?php require 'assets/js.php' ?> 
		<?php $this->load->view('footer'); ?>

		<script type="text/javascript">
			function reset_password(id){
				if(confirm("Are you sure, you want to reset this password?")){
					window.location.href='<?php echo base_url('user/reset_password/'); ?>'+id;
				}
			}	
		</script>

	</body>
</html>