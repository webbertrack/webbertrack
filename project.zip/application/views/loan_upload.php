<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?= $page ?> Page</title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper">
			<?php $this->load->view('header'); ?>
			<?php $this->load->view('sidebar'); ?>
			<div class="page-wrapper">
				<div class="content container-fluid">
					<div class="page-header" style="margin-top: auto;">
						<span style="float: left;"><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceSubserviceName['client_name'] ?> <br>
							<b>Service :</b> <?= $clientServiceSubserviceName['service_name'] ?>&nbsp;&nbsp; <b>Subservice :</b> <?= $clientServiceSubserviceName['subservice_name'] ?>
						</span>
					</div>
				</div>
				<div class="content container-fluid">
					<div class="row">	
						<div class="col-lg-12">
							<div class="card">
								<div class="card-header">
									<?php 
										$subservice = $clientServiceSubserviceName['subservice_name']; 
										$new_str = str_replace(' ', '', $subservice);
									?>
									<!-- <?php echo $clientServiceSubserviceName['id'] ?> -->
									
									<h4 class="card-title">Upload the excel file <span style="float: right;" title="Download the template">
										<?php if($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_03' && $this->session->userdata('subservice_id') == 'SR_003') { ?>
											<a href="<?= base_url('assets/file_format/cherry_creek_underwriting_template.xlsx'); ?>" target="_blank" class="btn btn-primary btn-sm"><i class="fa fa-download"></i></a>
										<?php }elseif($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_04' && $this->session->userdata('subservice_id') == 'SR_004') { ?>
											<a href="<?= base_url('assets/file_format/cherry_creek_processing_template.xlsx'); ?>" target="_blank" class="btn btn-primary btn-sm"><i class="fa fa-download"></i></a>
										<?php } ?>										
									</span></h4>
								</div>
								<?php $attributes = array('enctype'=>'multipart/form-data');
                					echo form_open('user/import_data', $attributes); ?>
									<div class="card-body">
										<?php 
											if(!empty($this->session->flashdata('error'))){ ?>
												<div class="alert alert-danger alert-dismissible fade show" role="alert">
													<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
													<?= $this->session->flashdata('error') ?>
													<button type="button" class="close" data-dismiss="alert" aria-label="Close">
													<span aria-hidden="true">×</span>
													</button>
												</div>
											<?php }elseif(!empty($this->session->flashdata('success'))) { ?>
												<div class="alert alert-success alert-dismissible fade show" role="alert">
													<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
													<?= $this->session->flashdata('success') ?>
													<button type="button" class="close" data-dismiss="alert" aria-label="Close">
													<span aria-hidden="true">×</span>
													</button>
												</div>
											<?php }
										?>                					
										<input class="form-control" type="file" name="upload_file" required>							
									</div>
									<div class="card-footer">
										<input type="submit" name="upload" value="Upload" class="btn btn-primary btn-sm">
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php require 'assets/js.php' ?> 
		<?php $this->load->view('footer'); ?>
	</body>
</html>