<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?= $page ?> Page</title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper">
			<?php $this->load->view('header'); ?>
			<?php $this->load->view('sidebar'); ?>
			<div class="page-wrapper">
				<div class="content container-fluid">
					<div class="page-header" style="margin-top: auto;">
						<span><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceSubserviceName['client_name'] ?> <br>
							<b>Service :</b> <?= $clientServiceSubserviceName['service_name'] ?>&nbsp;&nbsp; <b>Subservice :</b> <?= $clientServiceSubserviceName['subservice_name'] ?>
						</span>
					</div>
				</div>

				<div class="container-fluid">
					<div class="email-wrap">
						<div class="row">
							<div class="col-xl-6 col-md-6 xl-40">
								<div class="row">
									<div class="col-md-12">
										<div class="card">
											<?php $this->load->view('notification'); ?>
											<!-- <div class="card-header">
												<h4 class="card-title">Two Column Vertical Form</h4>
											</div> -->
											<?= form_open('user/updateloansinfo'); ?>
												<div class="card-body">
													
														<div class="row">
															<div class="col-md-6">
																<!-- <h4 class="card-title">Personal details</h4> -->
																<input type="hidden" name="id" value="<?= $loan['id'] ?>">
																<div class="form-group">
																	<label>Loan No:</label>
																	<input type="text" class="form-control" readonly="" value="#<?= $loan['loan_no'] ?>">
																</div>
																<div class="form-group">
																	<label>Received D&T:</label>
																	<input type="text" class="form-control" readonly="" value="<?= date('m/d/Y h:i A', strtotime($loan['received_date'])) ?>">
																</div>
																<div class="form-group">
																	<label>Borrower Name:*</label>
																	<input type="text" class="form-control" name="borrower_name" value="<?= $loan['borrower_name'] ?>">
																	<?= form_error('borrower_name','<span style="color: red;">','</span>') ?>
																</div>
																<!-- <div class="form-group">
																	<label>Satate:</label>
																	<input type="text" class="form-control" name="state" value="<?= $loan['state'] ?>">
																	<?= form_error('state','<span style="color: red;">','</span>') ?>
																</div> -->
																<div class="form-group">
																	<label>Satate:</label>
																	<select class="js-example-basic-single col-sm-12" name="state" id="validationCustom04">
																		<option value="">Select...</option>
																		<?php 
																			foreach ($stateList as $state) { ?>
																				<option value="<?= $state['postal_name'] ?>"><?= $state['state_name']."(".$state['postal_name'].")" ?></option>
																			<?php }
																		?>
																	</select>
																	<?= form_error('state','<span style="color: red;">','</span>') ?>
																</div>
															</div>


															<div class="col-md-6">
																<!-- <h4 class="card-title">Personal details</h4> -->
																<div class="form-group">
																	<label>Review Type:*</label>
																	<select class="form-control" name="review_type_id" required="">
																		<?php
																			foreach($reviewType as $row) {					
																				if($loan['review_type_id'] == $row['review_type_id']){ ?>
																					<option value="<?= $row['review_type_id'] ?>"><?= $row['review_type'] ?></option>
																				<?php }
																			}																

																			foreach($reviewType as $row) {
																				$explode = explode(",", $clientServiceSubserviceName['review_type_id']); 
																				if(in_array($row['review_type_id'], $explode)) { ?>
																					<option value="<?= $row['review_type_id'] ?>"><?= $row['review_type'] ?></option>
																				<?php }
																			}
																		?>
																	</select>
																	<?= form_error('review_type_id','<span style="color: red;">','</span>') ?>
																</div>
																<div class="form-group">
																	<label>Channel:*</label>
																	<select class="form-control" name="channel_id" required="">
																		<?php
																			foreach($channelData as $row) {
																				if($row['channel_id'] == $loan['channel_id']){ ?>
																					<option value="<?= $row['channel_id'] ?>"><?= $channel['channel'] ?></option>									
																				<?php }
																			}

																			foreach($channelData as $row) { ?>
																				<option value="<?= $row['channel_id'] ?>"><?= $row['channel'] ?></option>
																			<?php }																			
																		?>
																	</select>
																	<?= form_error('channel_id','<span style="color: red;">','</span>') ?>
																</div>
																<!-- <div class="form-group">
																	<label>Loan Type:</label>
																	<select class="form-control" name="loan_type_id">
																		<?php 
																			foreach($loan_type as $loanType) {
																				if($loanType['loan_type_id'] == $loan['loan_type_id']){ ?>
																					<option value="<?= $loanType['loan_id'] ?>"><?= $loanType['loan_type'] ?></option>
																				<?php }
																			}
																		 
																			foreach($loan_type as $loanType) { ?>
																				<option value="<?= $loanType['loan_type_id'] ?>"><?= $loanType['loan_type'] ?></option>
																			<?php }
																		?>
																	</select>
																	<?= form_error('loan_type_id','<span style="color: red;">','</span>') ?>
																</div>
																<div class="form-group">
																	<label>Transaction Type:</label>
																	<select class="form-control" name="transaction_type">
																		<option value="">--Select--</option>
																		<option value="Purchase">Purchase</option>
																		<option value="Refinance">Refinance</option>
																	</select>
																	<?= form_error('transaction_type','<span style="color: red;">','</span>') ?>
																</div>
																<div class="form-group">
																	<label>Loan Purpose:</label>
																	<select class="form-control" name="loan_purpose">
																		<option value="">--Select--</option>
																		<option value="Cash-out">Cash-out</option>
																		<option value="No Cash-out">No Cash-out</option>
																		<option value="Limited Cash-out">Limited Cash-out</option>
																	</select>
																</div> -->
																<?= form_error('loan_purpose','<span style="color: red;">','</span>') ?>
															</div>
								
														</div>
														<!-- <div class="text-right">
															<button type="submit" class="btn btn-primary">Update</button>
														</div> -->
														
												</div>
												<div class="card-footer">
													<input type="submit" name="btn_update" value="Update" class="btn btn-primary btn-sm">
												</div>
											<?= form_close() ?>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
		<?php require 'assets/js.php' ?> 
		<?php $this->load->view('footer'); ?>
	</body>
</html>