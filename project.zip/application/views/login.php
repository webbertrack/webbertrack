<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title>Trelix WMS | <?= $page ?></title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper login-body">
			<div class="login-wrapper">
				<div class="container">
					<div class="loginbox" style="min-height: auto; max-width: 500px;">
						<div class="login-right" style="width: 100%;">
							<div class="login-right-wrap">									
								<h1><span><img src="<?= base_url('assets/img/trelix_logo.png') ?>" style="width: 25%;"/> <span style="color: #545658; font-size: 25px;">WMS</span></span></h1>
								<p class="account-subtitle">Welcome back! Log in to you account</p>

								<!-- <?= password_hash('welcome', PASSWORD_DEFAULT); ?> -->
								<!-- <?php 
									if(!empty($this->session->userdata('error'))) { ?>
										<div class="alert alert-danger alert-dismissible fade show" role="alert">
											<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
											<?= $this->session->flashdata('error') ?>
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
											<span aria-hidden="true">×</span>
											</button>
										</div>
									<?php }
								?> -->
								<?php $this->load->view('notification'); ?>
								
								<?= form_open('login/authentication') ?>
									<div class="form-group">
										<input class="form-control" type="text" name="emp_id" autocomplete="off" value="<?php echo set_value('emp_id'); ?>" placeholder="Employee ID"> 
										<?php 
											if(!empty($this->session->flashdata('emp_id'))){ ?>
												<span style="color:red;">*<?= $this->session->flashdata('emp_id'); ?></span>
											<?php }
										?>
									</div>
									<div class="form-group">
										<input class="form-control" type="password" name="login[password]" autocomplete="new-password" placeholder="Password"> 
										<?php 
											if(!empty($this->session->flashdata('password'))){ ?>
												<span style="color:red;">*<?= $this->session->flashdata('password'); ?></span>
											<?php }
										?>
									</div>
									<div class="form-group">
										<button class="btn btn-primary btn-block" type="submit">Sign In</button>
									</div>
									<div class="text-center dont-have">Don’t have an account? 
										<a href="<?= base_url('login/register') ?>">Register</a>
									</div>
								</form>
							<!-- <div class="text-center dont-have">Don’t have an account? <a href="register.html">Register</a></div> -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php require 'assets/js.php' ?>
	</body>
</html>