<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?= $page ?> Page</title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper">
			<?php $this->load->view('header'); ?>
			<?php $this->load->view('sidebar'); ?>
			<div class="page-wrapper">
				<div class="content container-fluid">
					<div class="page-header" style="margin-top: auto;">
						<span><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceSubserviceName['client_name'] ?> <br>
							<b>Service :</b> <?= $clientServiceSubserviceName['service_name'] ?>&nbsp;&nbsp; <b>Subservice :</b> <?= $clientServiceSubserviceName['subservice_name'] ?>
						</span>
						<!-- <span style="float: left;"><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceName->client_name ?> <br>
							<b>Service :</b> <?= $clientServiceName->service ?><br>
						</span> -->
					</div>
				</div>

				<div class="container-fluid">
					<div class="email-wrap">
							<div class="row">
								<div class="col-md-12 d-flex">
									<div class="card card-table flex-fill">
										<?php $this->load->view('notification'); ?>
										<!-- <div class="card-header">
											<h4 class="card-title float-left mt-2"><span><?= $page ?></span></h4>
										</div> -->
										<br>
										<div class="card-body">
											<div class="col-md-12 d-flex">
												<div class="table-responsive">
													<table id="example" class="table table-striped">
														<thead>
															<tr>
																<th>sl no.</th>
																<th>Loan</th>
																<th>Received D&T</th>
																<th>Borrower Name</th>
																<th>State</th>
																<th>Analyst Name</th>
																<th>Action</th>
															</tr>
														</thead>
														<tbody>
															<?php $sl=1;
																foreach($incorrectLoans as $row) {?>
																	<tr>
																		<?= form_open('user/loan_info') ?>
																			<td><input type="hidden" class="form-control" style="width: 1px;" name="id" value="<?= $row['id'] ?>"><?= $sl ?></td>
																			<td><?= $row['loan_no'] ?></td>
																			<td><?= date('m/d/Y h:i A', strtotime($row['received_date'])) ?></td>
																			<td><?= $row['borrower_name'] ?></td>
																			<td><?= $row['state'] ?></td>
																			<td>
																				<?php 
																					foreach($analystDetails as $analyst){
																						if($row['emp_id'] == $analyst['emp_id']){ ?>
																							<option value="<?= $analyst['emp_id'] ?>"><?= $analyst['emp_fname'].' '.$analyst['emp_lname'] ?></option>
																						<?php }
																					}
																				?>
																			</td>
																			<td>
																				<input type="submit" class="btn btn-primary btn-sm" name="btn_info" value="Edit">
																				<!-- <a href="<?= base_url('user/loan_info/').base64_encode($row['id']) ?>"><i class="fa fa-edit"></i></a> -->
																			</td>
																		<?= form_close() ?>
																	</tr>
																<?php $sl++;}
															?>											
														</tbody>
													</table>
												</div>
											</div>
										</div>																	
									</div>
								</div>
							</div>						
					</div>
				</div>

			</div>
		</div>
		<?php require 'assets/js.php' ?> 
		<?php $this->load->view('footer'); ?>
	</body>
</html>