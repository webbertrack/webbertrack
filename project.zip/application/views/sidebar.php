<div class="sidebar" id="sidebar" style="top: 52px;">
			<div class="sidebar-inner slimscroll">
				<div id="sidebar-menu" class="sidebar-menu" style="padding: 0px 0 0 1px;">
					<ul style="margin-right: 10px;">
						<!-- <li> <a href="index.html"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a> </li> -->
						<!-- <li class="list-divider"></li> -->
						<!-- <?php if($empDetails['user_type'] == 'user3' || $empDetails['user_type'] == 'user4') { ?> 
							<li class="<?= ($page == 'Dashboard')?'active':'' ?>"> <a href="<?= base_url('user/dashboard'); ?>"><i class="fa fa-tachometer-alt"></i> <span>Dashboard</span></a> </li>
						<?php } ?>	 -->		
						<?php 
							if($empDetails['user_type'] == 'user3' || $empDetails['user_type'] == 'user4') {?>
								<li class="submenu"> 
									<a href="#" <?= ($page == 'Review Type')?'style="background-color: #009688; color: white;"':'' ?>><i class="fa fa-folder-open"></i> <span> Review Type </span> <span class="menu-arrow"></span></a>
									<ul class="submenu_class" style="display: <?= ($page == 'Review Type')?'block':'none' ?>;">
										<!-- <li><a href=""> Initial </a></li> -->
										<!-- <li><a href=""> <?= $row->review_type ?> </a></li> -->
										<!-- <?php 
											foreach ($reviewType as $row) { 
												$explodeReviewType = explode(',', $empDetails['review_type_id']);
												if(in_array($row->review_type_id, $explodeReviewType)){ ?>
													<li><a class="<?= ($page == 'Review Type' && ($row->review_type_id == $this->session->userdata('review_type_id')))?'active':'' ?>" href="<?= base_url('user/review_type/'.base64_encode($row->review_type_id)) ?>"> <?= $row->review_type ?> </a></li>
												<?php }
											}
										?> -->

										<?php 
											foreach($reviewType as $row) {
												$explode = explode(",", $clientServiceSubserviceName['review_type_id']); 
												if(in_array($row['review_type_id'], $explode)){
													$explode = explode(",", $empDetails['review_type_id']); 
													if(in_array($row['review_type_id'], $explode)){?>
														<li><a class="<?= ($page == 'Review Type' && ($row['review_type_id'] == $this->session->userdata('review_type_id')))?'active':'' ?>" href="<?= base_url('user/review_type1/'.base64_encode($row['review_type_id'])) ?>"> <?= $row['review_type'] ?> </a></li>
													<?php }
												}
											}
										?>

									</ul>
								</li>
							<?php }
						?>
						<li class="<?= ($page == 'Analyst View')?'active':'' ?>"> <a href="<?= base_url('user/analyst_view') ?>"><i class="fa fa-eye"></i> <span>Analyst View</span></a> </li>	

						<?php if($empDetails['user_type'] == 'user3' || $empDetails['user_type'] == 'user4') { ?> 
							<li class="<?= ($page == 'Rejected Loans')?'active':'' ?>"> <a href="<?= base_url('user/rejectedloans') ?>"><i class="fa fa-list"></i> <span>Rejected Loans</span></a> </li>

							<li class="<?= ($page == 'Incomplete Loan Information List')?'active':'' ?>"> <a href="<?= base_url('user/incorrect_loans_list'); ?>"><i class="fa fa-book"></i> <span>Incomplete Loan Info </span></a> </li>

							
							<li class="<?= ($page == 'State')?'active':'' ?>"> <a href="<?= base_url('user/state') ?>"><i class="fa fa-flag"></i> <span>State</span></a> </li>	
							
						
							<li class="<?= ($page == 'Manage Team')?'active':'' ?>"> 
								<a href="<?= base_url('user/manage_team'); ?>">
									<i class="fa fa-user"></i> <span>Manage Team</span>
									<!-- <sup style=" width: 20px; height: 20px; background-color: #ffbc34; color: white; clip-path: circle();"><span>3</span></sup> -->
									<!-- <sup><i class="fa fa-bell" style="font-size:20px;color:white"></i></sup> -->
									
									<?php 

										$count = 0;
										if(!empty($specificEmployees)) {
											if($empDetails['user_type'] == 'user3'){
												foreach ($specificEmployees as $emp) {
													if(($emp['user_type'] == 'user4' || $emp['user_type'] == 'user6') && $emp['status'] == 2){
														$explode = explode(",", $emp['skillset']);
														if(in_array($clientServiceSubserviceName['id'], $explode)) {
															$count = $count+1;
														}
													}
												}	
											}elseif($empDetails['user_type'] == 'user4'){
												foreach ($specificEmployees as $emp) {
													if($emp['user_type'] == 'user6' && $emp['status'] == 2){
														$explode = explode(",", $emp['skillset']);
														if(in_array($clientServiceSubserviceName['id'], $explode)) {
															$count = $count+1;
														}
													}
												}	
											}
												
										}										
										if($count > 0){ ?>
											<span style="animation: blinker 1.6s linear infinite;"><sup style="color: white; padding: 3px; width: 20px; height: 20px; background-color: red; border-radius: 100px;"><b><?= $count ?></b></sup></span>
										<?php }										
									?>
								</a> 
							</li>

							<li class="<?= ($page == 'Loan Upload')?'active':'' ?>"> <a href="<?= base_url('user/loan_upload'); ?>"><i class="fa fa-upload"></i> <span>Loan Upload</span></a> </li>

						<?php } ?>						

						<?php if($empDetails['user_type'] == 'user2') { ?> 
							<li class="<?= ($page == 'Client List')?'active':'' ?>"> <a href="<?= base_url('user/client_list'); ?>"><i class="fa fa-list"></i> <span>Client List</span></a> </li>
						<?php } ?> 
						<?php if($page == 'Loan Search') { ?>
							<li class="<?= ($page == 'Loan Search')?'active':'' ?>"> <a href="<?= base_url('user/loan_search'); ?>"><i class="fa fa-search"></i> <span>Loan Search</span></a> </li>
						<?php } ?>

						<?php if($page == 'My Profile') { ?>
							<li class="<?= ($page == 'My Profile')?'active':'' ?>"> <a href="<?= base_url('user/profile'); ?>"><i class="fa fa-user"></i> <span>My Profile</span></a> </li>
						<?php } ?>

						<li> <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa fa-file-excel"></i> <span>Report</span></a> </li>
						
					</ul>
				</div>
			</div>
		</div>