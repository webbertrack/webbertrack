<div class="header shadow-sm" style="height: 50px;">
	<div class="header-left" style="background-color: #f9fbfd; height: 1px;">
		<img src="<?= base_url('assets/img/trelix_logo.png') ?>" style="width: 40%;"/>
		<a href="javascript:void(0)" class="logo" style="font-family: Times New Roman; line-height: 45px;"><span style="color: #545658; font-size: 25px;">WMS</span></a>
		<a href="" class="logo logo-small" style="font-family: Times New Roman; line-height: 25px;"><span style="color: #545658; font-size: 20px;">WMS</span></a>
	</div>

	<?php if($page != 'Login Page') { ?>
		<a href="javascript:void(0);" id="toggle_btn" style="height: 47px;">
			<i class="fa fa-bars" aria-hidden="true" style="font-size: 20px;"></i> 
		</a>
	<?php } ?> 

	<ul class="nav user-menu" style="margin: 5px;">
		<a href="#" data-toggle="dropdown"><div class="avatar avatar-sm"><?= strtoupper(substr($empDetails['emp_fname'], 0, 1)).''.strtoupper(substr($empDetails['emp_lname'], 0, 1)) ?></div></a>
		<div class="dropdown-menu">
			<div class="user-header">
				<div class="avatar avatar-sm"><?= strtoupper(substr($empDetails['emp_fname'], 0, 1)).''.strtoupper(substr($empDetails['emp_lname'], 0, 1)) ?>					
				</div>
				<div class="user-text">
					<h6><?= $empDetails['emp_fname'].' '.$empDetails['emp_lname'] ?></h6>
					<p class="text-muted mb-0">
						<?php 
							if($empDetails['user_type'] == 'user1'){
								echo "Super Admin";
							}elseif($empDetails['user_type'] == 'user2'){
								echo "Supervisor";
							}elseif($empDetails['user_type'] == 'user3'){
								echo "Manager";
							}elseif($empDetails['user_type'] == 'user4'){
								echo "Team Lead";
							}elseif($empDetails['user_type'] == 'user5'){
								echo "Special Analyst";
							}elseif($empDetails['user_type'] == 'user6'){
								echo "Analyst";
							}elseif($empDetails['user_type'] == 'user7'){
								echo "RTA";
							}
						?>
					</p>
				</div>
			</div>
			<?php if($page != 'Login Page') { ?> 
				<a class="dropdown-item" href="<?= base_url('user/profile') ?>">My Profile</a> 
				<!-- <a class="dropdown-item" href="#">Account Settings</a>  -->
			<?php } ?>
			<a class="dropdown-item" href="mailto:Ranganath.N@altisource.com?cc=Kumar.Sumeet@altisource.com;Dibyendu.Sahoo@altisource.com">Contact us</a>
			<a class="dropdown-item" href="<?= base_url('login/logout') ?>">Logout</a> 
		</div>
	</ul>

	<!-- <?php if($page != 'Login Page' AND $page != 'Loan Search') { ?> -->
		<div class="top-nav-search" style="margin-top: 4px; float: left;">
			<!-- <form style="margin-top: 0px;"> -->
			<?php $attributes = array('style'=>'margin-top: 0px;');
				echo form_open('user/loan_information', $attributes);?>
				<!-- <input type="text" class="form-control" name="loan_no" id="search" placeholder="Search the loan no" style="border-radius: 10px; background-color: #ffffff; color: #ffffff;"> -->
				<input type="text" class="form-control" name="loan_no" placeholder="Search the loan no" style="border-radius: 10px;">
				<button class="btn" type="submit" style="color: #bcc6d1;"><i class="fas fa-search"></i></button>
			<?= form_close() ?>
		</div>
	<!-- <?php } ?> -->
</div>