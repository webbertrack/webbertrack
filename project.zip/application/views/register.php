<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title>Trelix WMS | <?= $page ?></title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper login-body">
			<div class="login-wrapper">
				<div class="container">
					<div class="loginbox" style="min-height: auto; max-width: 700px;">
						<div class="login-right" style="width: 100%;">
							<div class="login-right-wrap">									
								<h1><!-- <img src="<?= base_url('assets/img/trelix_logo.jpg') ?>" style="width: 25%;"/>| --> WMS</h1>
								<!-- <p class="account-subtitle">Welcome back! Log in to you account</p> -->

								<!-- <?= password_hash('welcome', PASSWORD_DEFAULT); ?> -->
								<?php 
									if(!empty($this->session->userdata('error'))) { ?>
										<div class="alert alert-danger alert-dismissible fade show" role="alert">
											<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
											<?= $this->session->flashdata('error') ?>
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
											<span aria-hidden="true">×</span>
											</button>
										</div>
									<?php }
								?>
								
								<?= form_open('login/new_registration') ?>
									<div class="row">
										<input type="hidden" name="password" value="<?= password_hash('welcome', PASSWORD_DEFAULT) ?>">
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-6">											
													<div class="form-group">
														<label>Employee ID:</label>												
														<input type="text" name="emp_id" value="<?= set_value('emp_id') ?>" class="form-control">
														<?= form_error('emp_id','<span style="color: red;">','</span>') ?>
													</div>
												</div>
												<div class="col-md-6">											
													<div class="form-group">
														<label>User Type:</label>												
														<select class="form-control" name="user_type">
															<option value="">--Select--</option>
															<option value="user6">Analyst</option>
															<!-- <option value="user5">Special Analyst</option> -->
															<option value="user4">Team Lead</option>
														</select>
														<?= form_error('user_type','<span style="color: red;">','</span>') ?>
													</div>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-6">											
													<div class="form-group">
														<label>First Name:</label>												
														<input type="text" name="emp_fname" value="<?= set_value('emp_fname') ?>" class="form-control">
														<?= form_error('emp_fname','<span style="color: red;">','</span>') ?>
													</div>
												</div>
												<div class="col-md-6">											
													<div class="form-group">
														<label>Last Name :</label>												
														<input type="text" name="emp_lname" value="<?= set_value('emp_lname') ?>" class="form-control">
														<?= form_error('emp_lname','<span style="color: red;">','</span>') ?>
													</div>
												</div>
											</div>
										</div>
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-12">											
													<div class="form-group">
														<label>Mail ID:</label>												
														<input type="email" name="mail_id" value="<?= set_value('mail_id') ?>" class="form-control">
														<?= form_error('mail_id','<span style="color: red;">','</span>') ?>
													</div>
												</div>
											</div>
										</div>
										<!-- <div class="col-md-12">
											<div class="row">
												<div class="col-md-12">											
													<div class="form-group">
														<label>User Type:</label>												
														<select name="skillset" class="js-example-basic-single col-sm-12">
															<option value="">--Select--</option>
															<?php 
																foreach($userType as $user_type) { 
																	if($user_type['user_type'] == 'user6'){ ?>
																		<option value=""><?= $user_type['user'] ?></option>
																	<?php }
																?>
																	
																<?php }
															?>
														</select>
														<?= form_error('skillset','<span style="color: red;">','</span>') ?>
													</div>
												</div>
											</div>
										</div> -->
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-12">											
													<div class="form-group">
														<label>Client, Service & Subservice:</label>												
														<select name="skillset" class="js-example-basic-single col-sm-12">
															<option value="">--Select--</option>
															<?php 
																foreach($client_service_subservice as $css) { ?>
																	<option value="<?= $css['id'] ?>"><?= $css['client_name'].'->'.$css['service_name'].'->'.$css['subservice_name'] ?></option>
																<?php }
															?>
														</select>
														<?= form_error('skillset','<span style="color: red;">','</span>') ?>
													</div>
												</div>
											</div>
										</div>
									</div>									
									<div class="form-group">
										<button class="btn btn-primary btn-block" type="submit">Register</button>
									</div>
									<div class="text-center dont-have">Already have an account? 
										<a href="<?= base_url('login') ?>">Sign In</a>
									</div>
								<?= form_close() ?>
							<!-- <div class="text-center dont-have">Don’t have an account? <a href="register.html">Register</a></div> -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php require 'assets/js.php' ?>
	</body>
</html>