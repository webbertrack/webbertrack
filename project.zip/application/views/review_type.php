<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?= $page ?> Page</title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper">
			<?php $this->load->view('header'); ?>
			<?php $this->load->view('sidebar'); ?>
			<div class="page-wrapper">
				<div class="content container-fluid">
					<div class="page-header" style="margin-top: auto;">
						<span><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceSubserviceName['client_name'] ?> <br>
							<b>Service :</b> <?= $clientServiceSubserviceName['service_name'] ?>&nbsp;&nbsp; <b>Subservice :</b> <?= $clientServiceSubserviceName['subservice_name'] ?>
						</span>
						<!-- <span style="float: right;"><b>Client :</b> <?= $clientServiceName->client_name ?> <br>
							<b>Service :</b> <?= $clientServiceName->service ?>
						</span> -->
						<!-- <span style="float: left;"><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceName->client_name ?> <br>
							<b>Service :</b> <?= $clientServiceName->service ?><br>
						</span> -->
					</div>
				</div>

				<div class="container-fluid">
					<div class="email-wrap">
						<div class="row">
							<div class="col-xl-12 col-md-6 xl-40">
								<div class="row">
									<div class="col-xl-3 col-sm-6 col-12">
										<div class="card board1 fill">
											<a href="<?= base_url('user/unassignedloans') ?>">
												<div class="card-body">
													<div class="dash-widget-header">
														<div>
															<?php 
																$count=0;
																foreach($UAPloans as $unassignedLoans) {
																	if($unassignedLoans['review_status'] == 'unassigned'){
																		$count=$count+1;
																	}
																}
															?>
															<h3 class="card_widget_header"><?= $count ?></h3>
															<h6 class="text-muted">Unassigned Loans</h6> 
														</div>
													</div>
												</div>
											</a>
										</div>
									</div>
									<div class="col-xl-3 col-sm-6 col-12">
										<div class="card board1 fill">
											<a href="<?= base_url('user/assignedloans') ?>">
												<div class="card-body">
													<div class="dash-widget-header">
														<div>
															<?php 
																$count=0;
																foreach($UAPloans as $assignedLoans) {
																	if($assignedLoans['review_status'] == 'assigned'){
																		$count=$count+1;
																	}
																}
															?>
															<h3 class="card_widget_header"><?= $count ?></h3>
															<h6 class="text-muted">Assigned Loans</h6> 
														</div>
													</div>
												</div>
											</a>
										</div>
									</div>
									<div class="col-xl-3 col-sm-6 col-12">
										<div class="card board1 fill">
											<a href="<?= base_url('user/progressloans') ?>">
												<div class="card-body">
													<div class="dash-widget-header">
														<div>
															<?php 
																$count=0;
																foreach($UAPloans as $progress) {
																	if($progress['review_status'] == 'progress'){
																		$count=$count+1;
																	}
																}
															?>
															<h3 class="card_widget_header"><?= $count ?></h3>
															<h6 class="text-muted">Inprogress Loans</h6> 
														</div>
													</div>
												</div>
											</a>
										</div>
									</div>
									<div class="col-xl-3 col-sm-6 col-12">
										<div class="card board1 fill">
											<a href="<?= base_url('user/pendingloans') ?>">
												<div class="card-body">
													<div class="dash-widget-header">
														<div>
															<?php 
																$count=0;
																foreach($UAPloans as $pendingLoans) {
																	if($pendingLoans['review_status'] == 'pending'){
																		$count=$count+1;
																	}
																}
															?>
															<h3 class="card_widget_header"><?= $count ?></h3>
															<h6 class="text-muted">Pending Loans</h6> 
														</div>
													</div>
												</div>
											</a>
										</div>
									</div>
									<div class="col-xl-3 col-sm-6 col-12">
										<div class="card board1 fill">
											<a href="<?= base_url('user/pulledbackloans') ?>">
												<div class="card-body">
													<div class="dash-widget-header">
														<div>
															<?php 
																$count=0;
																foreach($UAPloans as $pulledbackLoans) {
																	if($pulledbackLoans['review_status'] == 'pulledback'){
																		$count=$count+1;
																	}
																}
															?>
															<h3 class="card_widget_header"><?= $count ?></h3>
															<h6 class="text-muted">PulledBack Loans</h6> 
														</div>
													</div>
												</div>
											</a>
										</div>
									</div>
									<div class="col-xl-3 col-sm-6 col-12">
										<div class="card board1 fill">
											<a href="<?= base_url('user/todaysCompletedLoans') ?>">
												<div class="card-body">
													<div class="dash-widget-header">
														<div>
															<?php 
																	$count=0;
																	foreach($allEmpCompletedLoans as $todaysCompletedLoans) {
																		if($todaysCompletedLoans['review_status'] == 'completed'){
																			$count=$count+1;
																		}
																	}
																?>
																<h3 class="card_widget_header"><?= $count ?></h3>
															<h6 class="text-muted">Todays Completed Loans</h6> 
														</div>
													</div>
												</div>
											</a>
										</div>
									</div>
								</div>
							</div>
							<!-- <div class="col-md-12 d-flex">
								<div class="card card-table flex-fill">
									<div class="card-header">
										<h4 class="card-title float-left mt-2">Booking</h4>
										<button type="button" class="btn btn-primary float-right veiwbutton">Veiw All</button>
									</div>
									<div class="card-body">
										<div class="table-responsive">
											<table class="table table-hover table-center">
												<thead>
													<tr>
														<th>Booking ID</th>
														<th>Name</th>
														<th>Email ID</th>
														<th>Aadhar Number</th>
														<th class="text-center">Room Type</th>
														<th class="text-right">Number</th>
														<th class="text-center">Status</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td class="text-nowrap">
															<div>BKG-0001</div>
														</td>
														<td class="text-nowrap">Tommy Bernal</td>
														<td><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="3743585a5a4e55524559565b77524f565a475b521954585a">[email&nbsp;protected]</a></td>
														<td>12414786454545</td>
														<td class="text-center">Double</td>
														<td class="text-right">
															<div>631-254-6480</div>
														</td>
														<td class="text-center"> <span class="badge badge-pill bg-success inv-badge">INACTIVE</span> </td>
													</tr>
													<tr>
														<td class="text-nowrap">
															<div>BKG-0002</div>
														</td>
														<td class="text-nowrap">Ellen Thill</td>
														<td><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="89fbe0eae1e8fbedebfbe6ebfafdc9ecf1e8e4f9e5eca7eae6e4">[email&nbsp;protected]</a></td>
														<td>5456223232322</td>
														<td class="text-center">Double</td>
														<td class="text-right">
															<div>830-468-1042</div>
														</td>
														<td class="text-center"> <span class="badge badge-pill bg-success inv-badge">INACTIVE</span> </td>
													</tr>
													<tr>
														<td class="text-nowrap">
															<div>BKG-0003</div>
														</td>
														<td class="text-nowrap">Corina Kelsey</td>
														<td><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="76131a1a1318021e1f1a1a36130e171b061a135815191b">[email&nbsp;protected]</a></td>
														<td>454543232625</td>
														<td class="text-center">Single</td>
														<td class="text-right">
															<div>508-335-5531</div>
														</td>
														<td class="text-center"> <span class="badge badge-pill bg-success inv-badge">INACTIVE</span> </td>
													</tr>
													<tr>
														<td class="text-nowrap">
															<div>BKG-0004</div>
														</td>
														<td class="text-nowrap">Carolyn Lane</td>
														<td><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="50333f22393e313b353c23352910373d31393c7e333f3d">[email&nbsp;protected]</a></td>
														<td>2368989562621</td>
														<td class="text-center">Double</td>
														<td class="text-right">
															<div>262-260-1170</div>
														</td>
														<td class="text-center"> <span class="badge badge-pill bg-success inv-badge">INACTIVE</span> </td>
													</tr>
													<tr>
														<td class="text-nowrap">
															<div>BKG-0005</div>
														</td>
														<td class="text-nowrap">Denise</td>
														<td><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="1c7f7d6e73706572707d72795c7b717d7570327f7371">[email&nbsp;protected]</a></td>
														<td>3245455582287</td>
														<td class="text-center">Single</td>
														<td class="text-right">
															<div>570-458-0070</div>
														</td>
														<td class="text-center"> <span class="badge badge-pill bg-success inv-badge">INACTIVE</span> </td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div> -->
						</div>
					</div>
				</div>

			</div>
		</div>
		<?php require 'assets/js.php' ?> 
		<?php $this->load->view('footer'); ?>
	</body>
</html>