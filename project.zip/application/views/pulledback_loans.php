<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?= $page ?> Page</title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper">
			<?php $this->load->view('header'); ?>
			<?php $this->load->view('sidebar'); ?>
			<div class="page-wrapper">
				<div class="content container-fluid">
					<div class="page-header" style="margin-top: auto;">
						<span><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceSubserviceName['client_name'] ?> <br>
							<b>Service :</b> <?= $clientServiceSubserviceName['service_name'] ?>&nbsp;&nbsp; <b>Subservice :</b> <?= $clientServiceSubserviceName['subservice_name'] ?>
						</span>
						<!-- <span style="float: left;"><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceName->client_name ?> <br>
							<b>Service :</b> <?= $clientServiceName->service ?><br>
						</span> -->
					</div>
				</div>

				<div class="container-fluid">
					<div class="email-wrap">
						<?= form_open('user/loan_assign') ?>
							<div class="row">
								<div class="col-md-12 d-flex">
									<div class="card card-table flex-fill">
										<?php $this->load->view('notification'); ?>
										<div class="card-header">
											<h4 class="card-title float-left mt-2">PulledBack Loans</h4>
											<input type="submit" name="btn_pulledback" value="Reassign" class="btn btn-primary btn-sm float-right veiwbutton">
										</div>
										<div class="card-body">
											<div class="col-md-12 d-flex">
												<div class="table-responsive">
													<table id="example" class="table table-striped">
														<thead>
															<tr>
																<th><input type="checkbox" id="checkAll"></th>
																<th>Loan</th>
																<th>Received D&T</th>
																<th>Borrower</th>
																<th>State</th>
																<!-- <th>Loan Type</th> -->
																<th style="width: 20%;">Analyst Name</th>
																<th>Priority</th>
																<th>Action</th>
															</tr>
														</thead>
														<tbody>
															<?php 
																foreach($UAPloans as $row) {
																	if($row['review_status'] == 'pulledback'){ ?>
																		<tr>	
																			<td><input type="checkbox" name="update[]" value="<?= $row['id'] ?>"></td>
																			<td><?= $row['loan_no'] ?></td>
																			<td><?= date('m/d/Y h:i A', strtotime($row['received_date'])) ?></td>
																			<td><?= $row['borrower_name'] ?></td>
																			<td>
																				<?php if($row['state'] != NULL) { 
																					echo $row['state'];
																					if($row['state_type'] == 0){
																						echo "<span style='color: red; font-weight: bold;'> (NL)</span>";
																					}
																					// else{
																					// 	echo "<span style='color: #009688; font-weight: bold;'> (L)</span>";
																					// }
																				 } ?>
																			</td>
																			<!-- <td>
																				<?php 
																					foreach($loan_type as $loanType) {
																						if($row['loan_type_id'] == $loanType['loan_type_id']){
																							echo $loanType['loan_type'];
																						}
																					}
																				?>
																			</td> -->
																			<td>
																				<!-- <select class="select2" style="width: 100%;" id="select2" > -->
																				<select class="js-example-basic-single col-sm-12" name="emp_id_<?= $row['id'] ?>">
																					<?php 
																						foreach($analystDetails as $analyst){
																							if($row['emp_id'] == $analyst['emp_id']){ ?>
																								<option value="<?= $analyst['emp_id'] ?>"><?= $analyst['emp_fname'].' '.$analyst['emp_lname'] ?></option>
																							<?php }
																						}
																					?>
																					<?php 
																						foreach($analystDetails as $analyst) {
																							if($analyst['user_type'] == 'user4' || $analyst['user_type'] == 'user5' || $analyst['user_type'] == 'user6'){
																								if($row['client_id'] == $this->session->userdata('client_id') && $row['service_id'] == $this->session->userdata('service_id') && $row['subservice_id'] == $this->session->userdata('subservice_id') && $row['review_type_id'] == $this->session->userdata('review_type_id')){ 
																									$explodeLoanType = explode(',', $analyst['loan_type_id']);
																									if(in_array($row['loan_type_id'], $explodeLoanType)){ ?>
																										<option value="<?= $analyst['emp_id'] ?>"><?= $analyst['emp_fname'].' '.$analyst['emp_lname'] ?></option>
																									<?php }
																								}
																							}
																						}
																					?>
																				</select>
																			</td>
																			<td>
																				<select class="js-example-basic-single col-sm-12" name="priority_<?= $row['id'] ?>">
																					<option value="<?= $row['priority'] ?>">
																						<?php 
																							if($row['priority'] == 1){
																								echo "Low";
																							}elseif($row['priority'] == 2){
																								echo "Medium";
																							}elseif($row['priority'] == 3){
																								echo "High";
																							}elseif($row['priority'] == 4){
																								echo "Rush";
																							}
																						?>
																					</option>
																					<option value="1">Low</option>
																					<option value="2">Medium</option>
																					<option value="3">High</option>
																					<option value="4">Rush</option>
																				</select>
																			</td>
																			<td class="text-right">
																				<div class="dropdown dropdown-action"> 
																					<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fas fa-ellipsis-v ellipse_color"></i></a>
																					<div class="dropdown-menu dropdown-menu-right"> 
																						<a class="dropdown-item" href="<?= base_url('user/getLoanInformationById/').base64_encode($row['id'])?>" title="Loan Information"><i class="fa fa-info-circle m-r-5" style="color: #009688;"></i> Info</a> 	
																						<a class="dropdown-item"  href="javascript:void(0)" onclick="deleteLoanNo(<?= $row['id'] ?>)"><i class="fas fa-trash-alt m-r-5" style="color: red;"></i> Delete</a> 
																					</div>
																				</div>
																			</td>
																		</tr>
																	<?php }
																}
															?>											
														</tbody>
													</table>
												</div>
											</div>
										</div>																	
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>

			</div>
		</div>
		<?php require 'assets/js.php' ?> 
		<?php $this->load->view('footer'); ?>
	</body>
</html>