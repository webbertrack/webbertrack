<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?= $page ?> Page</title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper">
			<?php $this->load->view('header'); ?>
			<?php $this->load->view('sidebar'); ?>
			<div class="page-wrapper">
				<div class="content container-fluid">
					<div class="page-header" style="margin-top: auto;">
						<span><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceSubserviceName['client_name'] ?> <br>
							<b>Service :</b> <?= $clientServiceSubserviceName['service_name'] ?>&nbsp;&nbsp; <b>Subservice :</b> <?= $clientServiceSubserviceName['subservice_name'] ?>
						</span>
						<!-- <span style="float: left;"><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceName->client_name ?> <br>
							<b>Service :</b> <?= $clientServiceName->service ?><br>
						</span> -->
					</div>
				</div>

				<div class="container-fluid">
					<div class="email-wrap">
							<div class="row">
								<div class="col-md-12 d-flex">
									<div class="card card-table flex-fill">
										<?php $this->load->view('notification'); ?>

										<div>
											<span class="badge btn-primary" style="padding: 5px;">
												<a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target=".addNewPodModal" style="color: white;">Add new POD <i class="fa fa-plus-circle"></i> </a>
											</span>	
										</div>
										<!-- <div class="card-header">
											<h4 class="card-title float-left mt-2"><span><?= $page ?></span></h4>
										</div> -->
										<br>
										<div class="card-body">
											<div class="col-md-12 d-flex">
												<div class="table-responsive">
													<table id="example" class="table table-striped">
														<thead>
															<tr>
																<!-- <th hidden="">sl no.</th> -->
																<th>Emp ID</th>
																<th>Name</th>
																<th>Mail Id</th>
																<th>User Type</th>
																<th>Team</th>
																<th>Status</th>
																<th>Action</th>
															</tr>
														</thead>
														<tbody>
															<?php $sl=1; foreach ($specificEmployees as $emp) { 
																if($empDetails['user_type'] == 'user3'){
																	if($emp['user_type'] == 'user4' || $emp['user_type'] == 'user6'){
																		$explode = explode(",", $emp['skillset']);
																		if(in_array($clientServiceSubserviceName['id'], $explode)) { ?>
																			<tr>
																				<?= form_open('user/emp_details') ?>
																					<input type="hidden" name="id" value="<?= $emp['id'] ?>">
																					<td><?= $emp['emp_id'] ?></td>
																					<td><?= $emp['emp_fname'].' '.$emp['emp_lname'] ?></td>
																					<td><?= $emp['mail_id'] ?></td>
																					<td>
																						<?php 
																							if($emp['user_type'] == 'user1'){
																								echo "Super Admin";
																							}elseif($emp['user_type'] == 'user2'){
																								echo "Supervisor";
																							}elseif($emp['user_type'] == 'user3'){
																								echo "<span style='color: #070096; font-weight: bold;'>Manager</span>";
																							}elseif($emp['user_type'] == 'user4'){
																								echo "<span style='color: #0072ff; font-weight: bold;'>Team Lead</span>";
																							}elseif($emp['user_type'] == 'user5'){
																								echo "Special Analyst";
																							}elseif($emp['user_type'] == 'user6'){
																								echo "<span style='color: #1bc3e2; font-weight: bold;'>Analyst</span>";
																							}elseif($emp['user_type'] == 'user7'){
																								echo "RTA";
																							}
																						?>
																					</td>
																					<td>
																						<?php if($emp['team'] == 1) { 
																							echo "Offshore";
																						}else{
																							echo "Onshore";
																						} ?>
																					</td>
																					<td>
																						<?php 
																							if($emp['status'] == 1){ ?>
																								<span class="badge btn-primary">Active</span>
																							<?php }elseif(($emp['status'] == 2)){ ?>
																								<span class="badge btn-warning">New Joining</span>
																							<?php }elseif(($emp['status'] == 0)){ ?>
																								<span class="badge btn-danger">Inactive</span>
																							<?php }
																						?>
																					</td>
																					<td>
																						<button type="submit" class="btn btn-sm" style="background: none;"><i class="fa fa-edit" style="color: #009688;"></i></button>
																						<a href="javascript:void(0)" onclick="delete_empid(<?= $emp['id'] ?>)"><i class="fa fa-trash" style="color: red;"></i></a>
																					</td>
																				<?= form_close() ?>
																			</tr>	
																		<?php } 
																	} $sl++;
																}elseif($empDetails['user_type'] == 'user4'){
																	if($emp['user_type'] == 'user5' || $emp['user_type'] == 'user6'){
																		$explode = explode(",", $emp['skillset']);
																		if(in_array($clientServiceSubserviceName['id'], $explode)) { ?>
																			<tr>
																				<?= form_open('user/emp_details') ?>
																					<input type="hidden" name="id" value="<?= $emp['id'] ?>">
																					<td><?= $emp['emp_id'] ?></td>
																					<td><?= $emp['emp_fname'].' '.$emp['emp_lname'] ?></td>
																					<td><?= $emp['mail_id'] ?></td>
																					<td>
																						<?php 
																							if($emp['user_type'] == 'user1'){
																								echo "Super Admin";
																							}elseif($emp['user_type'] == 'user2'){
																								echo "Supervisor";
																							}elseif($emp['user_type'] == 'user3'){
																								echo "<span style='color: #070096; font-weight: bold;'>Manager</span>";
																							}elseif($emp['user_type'] == 'user4'){
																								echo "<span style='color: #0072ff; font-weight: bold;'>Team Lead</span>";
																							}elseif($emp['user_type'] == 'user5'){
																								echo "Special Analyst";
																							}elseif($emp['user_type'] == 'user6'){
																								echo "<span style='color: #1bc3e2; font-weight: bold;'>Analyst</span>";
																							}elseif($emp['user_type'] == 'user7'){
																								echo "RTA";
																							}
																						?>
																					</td>
																					<td>
																						<?php if($emp['team'] == 1) { 
																							echo "Offshore";
																						}else{
																							echo "Onshore";
																						} ?>
																					</td>
																					<td>
																						<?php 
																							if($emp['status'] == 1){ ?>
																								<span class="badge btn-primary">Active</span>
																							<?php }elseif(($emp['status'] == 2)){ ?>
																								<span class="badge btn-warning">New Joining</span>
																							<?php }else{ ?>
																								<span class="badge btn-danger">Deactive</span>
																							<?php }
																						?>
																					</td>
																					<td>
																						<!-- <input type="submit" class="btn btn-primary btn-sm" name="btn_info" value="Edit"> -->
																						<button type="submit" class="btn btn-sm" style="background: none;"><i class="fa fa-edit" style="color: #009688;"></i></button>
																						<a href="javascript:void(0)" onclick="delete_empid(<?= $emp['id'] ?>)"><i class="fa fa-trash" style="color: red;"></i></a>&nbsp;
																						<!-- <a href="javascript:void(0)"><i class="fa fa-repeat"></i></a> -->
																					</td>
																				<?= form_close() ?>
																			</tr>	
																		<?php } 
																	} $sl++;
																}
															}?>																	
														</tbody>
													</table>
												</div>
											</div>
										</div>																	
									</div>
								</div>
							</div>						
					</div>
				</div>

			</div>
		</div>
		<?php require 'assets/js.php' ?> 
		<?php $this->load->view('footer'); ?>

		<div class="modal fade addNewPodModal" >
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h6 class="modal-title" id="myLargeModalLabel">Add new POD</h6>
						<button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close" style="color: #c7b5b5; background-color: white; border: 0;">X</button>
					</div>
					<div class="modal-body">
						<?php $attributes = array('role' => 'form');
						echo form_open('user/addNewPodLeader',$attributes); ?>
							<div class="row g-3">
								<div class="col-md-12">
									<label class="form-label">POD No.</label>
									<select class="js-example-basic-single col-sm-12" name="pod_no" id="validationCustom04" required>
										<option value="">--Select--</option>
										<option value="POD 1">POD 1</option>
										<option value="POD 2">POD 2</option>
										<option value="POD 3">POD 3</option>
										<option value="POD 4">POD 4</option>
									</select><br>
									<label class="form-label" for="validationCustom01" style="padding-top: 15px;">UW Name</label>
									<select class="js-example-basic-single col-sm-12" name="id" required>
										<option value="">--Select--</option>
										<?php foreach ($analystDetails as $emp) { 
											if($clientServiceSubserviceName['id'] == $emp['skillset']) { 
												if($emp['pod'] != NULL) { ?>
													<option value="<?= $emp['pod'] ?>"><?= $emp['emp_fname'].' '.$emp['emp_lname'] ?></option>
											<?php }
											}
										}?>
									</select> 
								</div> 
							</div><br>
							<div class="row g-3"></div>
							<div class="card-footer">
								<button class="btn btn-primary btn-sm">Save</button>
							</div>
						<?= form_close(); ?>  
					</div>
				</div>
			</div>
		</div>

		<script type="text/javascript">
			function delete_empid(id){
				if(confirm("Are you sure, you want to delete this Employee?")){
					window.location.href='<?php echo base_url('user/delete_empid/'); ?>'+id;
				}
			}	
		</script>

	</body>
</html>