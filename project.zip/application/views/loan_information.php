<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?= $page ?> Page</title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper">
			<?php $this->load->view('header'); ?>
			<?php $this->load->view('sidebar'); ?>
			<div class="page-wrapper">
				<div class="content container-fluid">
					<div class="page-header" style="margin-top: auto;">
						<span><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceSubserviceName['client_name'] ?> <br>
							<b>Service :</b> <?= $clientServiceSubserviceName['service_name'] ?>&nbsp;&nbsp; <b>Subservice :</b> <?= $clientServiceSubserviceName['subservice_name'] ?>
						</span>
						<!-- <span style="float: left;"><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceName->client_name ?> <br>
							<b>Service :</b> <?= $clientServiceName->service ?><br>
						</span> -->
					</div>
				</div>

				<div class="container-fluid">
					<div class="email-wrap">
						<div class="row">
							<div class="col-md-12">
								<div class="profile-header">
									<div class="row align-items-center">	

										<div class="col col-md-4">
											<h4 class="user-name mb-3">#<?= $loan_info['loan_no'] ?></h4>
											<h6 class="text-muted mt-1">Received Date: <?= date('m/d/Y h:i A', strtotime($loan_info['received_date'])) ?></h6>
											<div class="user-Location mt-1">Borrower Name: <?= $loan_info['borrower_name'] ?></div>
											<div class="user-Location mt-1">Channel: 
												<?php 
													foreach ($channel as $channel_data) {
														if($loan_info['channel_id'] == $channel_data['channel_id']){
															echo $channel_data['channel'];
														}
													}
												?>
											</div>
											<div class="user-Location mt-1">State: <?= $loan_info['state'] ?>
												<?php if($loan_info['state_type'] == 0){
													echo "<span style='color: red;'> (NL)</span>";
												} ?>
											</div>											
										</div>
										<div class="col col-md-4">
											<div class="user-Location mt-1">Loan Type: 
												<?php 
													foreach ($loan_type as $loan_type_name) {
														if($loan_info['loan_type_id'] == $loan_type_name['loan_type_id']){
															echo $loan_type_name['loan_type'];
														}
													}
												?>	
											</div>	
											<div class="user-Location mt-1">Transaction Type: <?= $loan_info['transaction_type'] ?></div>
											<div class="user-Location mt-1">Purpose: <?= $loan_info['loan_purpose'] ?></div>										
										</div>
										<div class="col col-md-4">
											<h6 class="text-muted mt-1">SLA Date: 
												<?php 
													if($currentDate <= $loan_info['sla_date']){
														$currentDate = date('Y-m-d', strtotime($currentDate));
														$sla_date = date('Y-m-d', strtotime($loan_info['sla_date']));
														if($currentDate == $sla_date){ ?>
															<span class="blink" style="color: green;  animation: blinker 1.6s linear infinite;"><?= date('m/d/Y h:i A', strtotime($loan_info['sla_date'])) ?></span>
														<?php }else{ ?>
															<span class="blink" style="color: green;"><?= date('m/d/Y h:i A', strtotime($loan_info['sla_date'])) ?></span>	
														<?php }
													}else{ ?>
														<span class="blink" style="color: red;"><?= date('m/d/Y h:i A', strtotime($loan_info['sla_date'])) ?></span>
													<?php }
												?>
											</h6>										
										</div>
										<!-- <div class="col-auto profile-btn"> <a href="" class="btn btn-primary">
											Message
											</a> <a href="edit-profile.html" class="btn btn-primary">
											Edit
											</a> 
										</div> -->
										<!-- <div class="col ml-md-n2 profile-user-info"> -->
											<!-- <div class="user-Location mt-1"><b>SLA:</b> 
												<?php 
													if($currentDate <= $loan_info['sla_date']){
														$currentDate = date('Y-m-d', strtotime($currentDate));
														$sla_date = date('Y-m-d', strtotime($loan_info['sla_date']));
														if($currentDate == $sla_date){ ?>
															<span class="blink" style="color: green;  animation: blinker 1.6s linear infinite;"><?= date('m/d/Y h:i A', strtotime($loan_info['sla_date'])) ?></span>
														<?php }else{ ?>
															<span class="blink" style="color: green;"><?= date('m/d/Y h:i A', strtotime($loan_info['sla_date'])) ?></span>	
														<?php }
													}else{ ?>
														<span class="blink" style="color: red;"><?= date('m/d/Y h:i A', strtotime($loan_info['sla_date'])) ?></span>
													<?php }
												?>
											</div> -->
											<!-- <div class="user-Location mt-1">Transaction Type: <?= $loan_info['transaction_type'] ?></div>
											<div class="user-Location mt-1">Loan Purpose: <?= $loan_info['loan_purpose'] ?></div> -->
										<!-- </div> -->

									</div>
								</div>

								<?php if($loan_info['review_status'] != 'completed' ) { ?>
									<div class="profile-menu">
										<span><h5>Current Status</h5></span>
										<?php if($loan_info['status'] != 0) { ?>
											
												<!-- <ul class="nav nav-tabs nav-tabs-solid">
													<li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#per_details_tab">About</a> </li>
													<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#password_tab">Password</a> </li>
												</ul> -->																				
												<span><b>Review Status :</b> <?= $loan_info['review_status'] ?></span><br>
												<span><b>Name :</b> 
													<?php 
														foreach ($analystDetails as $emp) {
															if($loan_info['emp_id'] == $emp['emp_id']){
																echo $emp['emp_fname'].' '.$emp['emp_lname'];
															}
														}
													?>
												</span><br>
												<span><b>Review Type :</b> 
													<?php 
														foreach ($reviewType as $review_type) {
															if($loan_info['review_type_id'] == $review_type['review_type_id']){
																echo $review_type['review_type'];
															}
														}
													?>
												</span>		
										<?php } else { ?>
											
												<div class="alert alert-warning alert-dismissible fade show" role="alert">
													<strong>State</strong> is in the rejected bucket.
												</div>
											
										<?php } ?>
									</div>
								<?php } ?>

								<div class="tab-content profile-tab-cont"></div>
							</div>
						</div>

						<!--  -->
						<div class="row">
							<div class="col-md-12 d-flex">
								<div class="card card-table flex-fill">
									<?php $this->load->view('notification'); ?>
									<!-- <div class="card-header">
										<h4 class="card-title float-left mt-2"><span><?= $page ?></span></h4>
									</div> -->
									<br>
									<div class="card-body">
										<div class="col-md-12 d-flex">
											<!-- <div class="table-responsive"> -->
												<!-- <table id="example" class="table table-striped"> -->
											<table  class="table table-striped">
													<thead>
														<tr>
															<!-- <th>sl no.</th> -->
															<th>Review Type</th>
															<th>Loan Type</th>
															<th>Analyst Name</th>
															<th>Team</th>
															<th>Assigned D&T</th>
															<th>Review Status</th>
															<th>Started D&T</th>
															<th>Pending D&T</th>
															<th>Completed D&T</th>
															<th>Comments</th>
														</tr>
													</thead>
													<tbody>
														<?php foreach($review_status_info as $row) { ?>
															<tr>												
																<!-- <td></td> -->
																<td>
																	<?php 
																		foreach ($reviewType as $review_type) {
																			if($row['review_type_id'] == $review_type['review_type_id']){
																				echo $review_type['review_type'];
																			}
																		}
																	?>
																</td>
																<td>
																	<?php 
																		foreach ($loan_type as $loan_type_name) {
																			if($row['loan_type_id'] == $loan_type_name['loan_type_id']){
																				echo $loan_type_name['loan_type'];
																			}
																		}
																	?>
																</td>
																<td>
																	<?php 
																		foreach ($analystDetails as $emp) {
																			if($row['emp_id'] == $emp['emp_id']){
																				echo $emp['emp_fname'].' '.$emp['emp_lname'];
																			}
																		}
																	?>
																</td>
																<td>
																	<?php 
																		foreach ($analystDetails as $emp) {
																			if($row['emp_id'] == $emp['emp_id']){
																				if($emp['team'] == 1){
																					echo "Offshore";
																				}else{
																					echo "Onshore";
																				}
																			}
																		}
																	?>
																</td>
																<td><?= date('m/d/Y h:i A', strtotime($row['assigned_date'])) ?></td>
																<td><?= $row['review_status'] ?></td>
																<td><?= date('m/d/Y h:i A', strtotime($row['start_date'])) ?></td>
																<td>
																	<?php 
																		if($row['review_status'] == 'pending'){
																			echo date('m/d/Y h:i A', strtotime($row['end_date']));
																		}
																	?>
																</td>
																<td>
																	<?php 
																		if($row['review_status'] == 'completed'){
																			echo date('m/d/Y h:i A', strtotime($row['end_date']));
																		}
																	?>
																</td>
																<td>
																	<textarea class="form-control" readonly=""><?= $row['comments'] ?></textarea>
																</td>
															</tr>
														<?php } ?>																								
													</tbody>
												</table>
											<!-- </div> -->
										</div>
									</div>																	
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
		<?php require 'assets/js.php' ?> 
		<?php $this->load->view('footer'); ?>
	</body>
</html>