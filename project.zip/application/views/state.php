<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?= $page ?> Page</title>
		<?php require 'assets/css.php' ?>
	</head>
	<body>
		<div class="main-wrapper">
			<?php $this->load->view('header'); ?>
			<?php $this->load->view('sidebar'); ?>
			<div class="page-wrapper">
				<div class="content container-fluid">
					<div class="page-header" style="margin-top: auto;">
						<span><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceSubserviceName['client_name'] ?> <br>
							<b>Service :</b> <?= $clientServiceSubserviceName['service_name'] ?>&nbsp;&nbsp; <b>Subservice :</b> <?= $clientServiceSubserviceName['subservice_name'] ?>
						</span>
						<!-- <span style="float: left;"><?= $page ?></span>
						<span style="float: right;"><b>Client :</b> <?= $clientServiceName->client_name ?> <br>
							<b>Service :</b> <?= $clientServiceName->service ?><br>
						</span> -->
					</div>
				</div>

				<div class="container-fluid">
					<div class="email-wrap">
							<div class="row">
								<div class="col-md-12 d-flex">
									<div class="card card-table flex-fill">

										<div>
											<span class="badge btn-primary" style="padding: 5px;">
												<a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target=".addNewStateModal" style="color: white;">Add new state <i class="fa fa-plus-circle"></i> </a>
											</span>	
										</div>
										

										<?php $this->load->view('notification'); ?>
										<!-- <div class="card-header">
											<h4 class="card-title float-left mt-2"><span><?= $page ?></span></h4>
										</div> -->
										<br>
										<div class="card-body">
											<div class="col-md-12 d-flex">
												<div class="table-responsive">
													<table id="example" class="table table-striped">
														<thead>
															<tr>
																<!-- <th hidden="">sl no.</th> -->
																<th>Sl. No.</th>
																<th>State</th>
																<th>Postal Code</th>
																<th>Type</th>
																<th>Action</th>
															</tr>
														</thead>
														<tbody>
															<?php $sl=1;
																foreach ($stateList as $state) { ?>
																	<tr>
																		<td><?= $sl ?></td>
																		<td><?= $state['state_name'] ?></td>
																		<td><?= $state['postal_name'] ?></td>
																		<td>
																			<!-- <?php 
																				if($state['type'] == 1){ ?>
																					<span class="badge btn-primary"><a href="<?= base_url('user/stateTypeNonLicensed/').base64_encode($state['id']) ?>" style="color: white;"> Licensed State </a></span>
																				<?php }else{ ?>
																					<span class="badge btn-danger"><a href="<?= base_url('user/stateTypeLicensed/').base64_encode($state['id']) ?>" style="color: white;"> Non-Licensed State </a></span>
																				<?php }
																			?> -->
																			<?php 
																				if($state['type'] == 1){ ?>
																					<span class="badge btn-primary"><a href="javascript:void(0)" onclick="update_nonLicensedStateType(<?= $state['id'] ?>)" style="color: white;"> Licensed State </a></span>
																				<?php }else{ ?>
																					<span class="badge btn-danger"><a href="javascript:void(0)" onclick="update_licensedStateType(<?= $state['id'] ?>)" style="color: white;"> Non-Licensed State </a></span>
																				<?php }
																			?>
																		</td>
																		<td>
																			<!-- <a href="<?= base_url('user/stateDelete/').base64_encode($state['id']) ?>"><i class="fa fa-trash" style="color: red;"></i></a> -->
																			<a href="javascript:void(0)" onclick="delete_state(<?= $state['id'] ?>)"><i class="fa fa-trash" style="color: red;"></i></a>
																		</td>
																	</tr>
																<?php $sl++; } 
															?>			 													
														</tbody>
													</table>
												</div>
											</div>
										</div>																	
									</div>
								</div>
							</div>						
					</div>
				</div>

			</div>
		</div>
		<?php require 'assets/js.php' ?> 
		<?php $this->load->view('footer'); ?>

		<div class="modal fade addNewStateModal" >
		  <div class="modal-dialog">
		    <div class="modal-content">
		        <div class="modal-header">
		          <h6 class="modal-title" id="myLargeModalLabel">Add new State</h6>
		          <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close" style="color: #c7b5b5; background-color: white; border: 0;">X</button>
		        </div>
		        <div class="modal-body">
		            <?php $attributes = array('role' => 'form', 'class' => 'was-validated');
		                echo form_open('user/addNewState',$attributes); ?>
			                <div class="row g-3">
			                    <div class="col-md-12">
			                      <label class="form-label" for="validationCustom01">State Name</label>
			                      <input class="form-control" id="validationCustom01" name="state_name" type="text"  required="" ><br>
			                      <label class="form-label" for="validationCustom01">Postal Name</label>
			                      <input class="form-control" id="validationCustom01" name="postal_name" type="text"  required="" ><br>
			                      <label class="form-label" for="validationCustom01">Type</label>
			                      <select class="form-control" id="validationCustom01" name="type" required="">
			                      	<option value="">--Select--</option>
			                      	<option value="1">Licensed State</option>
			                      	<option value="0">Non-Licensed State</option>
			                      </select>
			                      <!-- <div class="valid-feedback">Looks good!</div> -->
			                    </div> 
			                </div>
			                  <br>
			                <div class="row g-3">
			            </div>
				        <div class="card-footer">
				        	<button class="btn btn-primary btn-sm">Add</button>
				        </div>
		          </form>  
		    
		    </div>
		  </div>
		</div>

		<script type="text/javascript">
			function update_nonLicensedStateType(id){
				// alert(id);
				if(confirm("Are you sure, you want to change the state type?")){
					window.location.href='<?php echo base_url('user/stateTypeNonLicensed/'); ?>'+id;
				}
			}	
			
			function update_licensedStateType(id){
				// alert(id);
				if(confirm("Are you sure, you want to change the state type?")){
					window.location.href='<?php echo base_url('user/stateTypeLicensed/'); ?>'+id;
				}
			}	

			function delete_state(id){
				// alert(id);
				if(confirm("Are you sure, you want to delete the State?")){
					window.location.href='<?php echo base_url('user/stateDelete/'); ?>'+id;
				}
			}	
		</script>


	</body>
</html>