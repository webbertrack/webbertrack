<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title><?= $page ?> Page</title>
		<?php require 'assets/css.php' ?>
	</head>
	<body class="<?= ($page == 'Home')? 'mini-sidebar':'' ?>">
		<div class="main-wrapper">
			<?php $this->load->view('header'); ?>
			<div class="main-wrapper login-body">
				<div class="login-wrapper">
					<div class="container">
						<div class="loginbox" style="min-height: auto; max-width: 500px;">
							<div class="login-right" style="width: 100%;">
								<div class="login-right-wrap">			
									<!-- <?= form_open('user/setClientSerive_id') ?>
										<div class="form-group">
											<label class="col-form-label col-md-6">Client Name :</label>
											<select name="client_id" class="form-control" required>
												<option value="">Select...</option>
												<?php 
													foreach ($client as $row) { 
														$explodeClient = explode(',', $empDetails['client_id']);
														if(in_array($row->client_id, $explodeClient)){ ?>
															<option value="<?= $row->client_id ?>"><?= $row->client_name ?></option>
														<?php }
													}
												?>
											</select>
											<?php 
												if(!empty($this->session->flashdata('client_error'))){ ?>
													<span style="color:red;">*<?= $this->session->flashdata('client_error'); ?></span>
												<?php }
											?>
										</div>
										<div class="form-group">
											<label class="col-form-label col-md-6">Service :</label>
											<select name="service_id" class="form-control" required>
												<option value="">Select...</option>
												<?php 
													foreach ($client as $row) { 
														$explodeService = explode(',', $empDetails['service_id']);
														if(in_array($row->service_id, $explodeService)){ ?>
															<option value="<?= $row->service_id ?>"><?= $row->service ?></option>
														<?php }
													}
												?>
											</select>
											<?php 
												if(!empty($this->session->flashdata('service_error'))){ ?>
													<span style="color:red;">*<?= $this->session->flashdata('service_error'); ?></span>
												<?php }
											?>
										</div>
										<div class="form-group">
											<button class="btn btn-primary btn-block" type="submit">Next</button>
										</div>
									</form> -->


									<?= form_open('login/setClientSerive_id') ?>
										<div class="form-group">
											<label class="col-form-label col-md-12">Client, Service & Subservice :</label>
											<select name="client_service_subservice" class="form-control" required>
												<option value="">Select...</option>
												<?php 
													foreach($clientService as $row) {
														$explodeSkillset = explode(',', $empDetails['skillset']);
														if(in_array($row['id'], $explodeSkillset)){
															$client = $row['client_name'];
															$service = $row['service_name'];
															$subservice = $row['subservice_name'];
															$concat_id = $row['client_id'].'/'.$row['service_id'].'/'.$row['subservice_id']; 
															$concat = $client.'->'.$service.'->'.$subservice;?>
															<option value="<?= $concat_id ?>"><?= $concat ?></option>
														<?php }
													}
												?>
											</select>
											<?php 
												if(!empty($this->session->flashdata('error'))){ ?>
													<span style="color:red;">*<?= $this->session->flashdata('error'); ?></span>
												<?php }
											?>
										</div>
										<div class="form-group">
											<button class="btn btn-primary btn-block" type="submit">Submit</button>
										</div>
									</form>


								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php require 'assets/js.php' ?> 
		<?php $this->load->view('footer'); ?>
	</body>
</html>