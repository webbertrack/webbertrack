<?php 
	if(!empty($this->session->flashdata('success'))){ ?>
		<div class="alert alert-success alert-dismissible fade show" role="alert">
			<!-- <i class="fa fa-exclamation-triangle" aria-hidden="true"></i> -->
			<?= $this->session->flashdata('success') ?>
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">×</span>
			</button>
		</div>
	<?php }elseif(!empty($this->session->flashdata('error'))) { ?>
		<div class="alert alert-danger alert-dismissible fade show" role="alert">
			<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
			<?= $this->session->flashdata('error') ?>
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">×</span>
			</button>
		</div>
	<?php }elseif(!empty($this->session->flashdata('warning'))) { ?>
		<div class="alert alert-warning alert-dismissible fade show" role="alert">
			<!-- <i class="fa fa-exclamation-triangle" aria-hidden="true"></i> -->
			<?= $this->session->flashdata('warning') ?>
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">×</span>
			</button>
		</div>
	<?php } 
?>