<?php 
	
	$config = [
		'new_registration' => [
			[
				'field' => 'emp_id',
				'label' => 'Employee ID',
				'rules' => 'trim|required|is_unique[emp_details.emp_id]'
			],
			[
				'field' => 'emp_fname',
				'label' => 'First Name',
				'rules' => 'trim|required|alpha|min_length[3]|max_length[20]'
			],
			[
				'field' => 'emp_lname',
				'label' => 'Last Name',
				'rules' => 'trim|required|max_length[20]'
			],
			[
				'field' => 'mail_id',
				'label' => 'Mail ID',
				'rules' => 'trim|required|valid_email|is_unique[emp_details.mail_id]'
			],
			[
				'field' => 'skillset',
				'label' => 'Client',
				'rules' => 'trim|required'
			],
			[
				'field' => 'user_type',
				'label' => 'User Type',
				'rules' => 'trim|required|min_length[5]|max_length[5]'
			]
		],

		'add_state_rules' => [
			[
				'field' => 'state_name',
				'label' => 'State Name',
				'rules' => 'trim|required|alpha|min_length[3]|max_length[20]'
			],
			[
				'field' => 'postal_name',
				'label' => 'Postal Name',
				'rules' => 'trim|required|alpha|min_length[2]|max_length[2]'
			],
			[
				'field' => 'type',
				'label' => 'Type',
				'rules' => 'trim|required|is_natural'
			],			
		],

		'check_loan_no' => [
			[
				'field' => 'loan_no',
				'label' => 'Loan No',
				'rules' => 'trim|required|alpha_numeric'
			]
		],

		'complete_activity' => [
			[
				'field' => 'review_status',
				'label' => 'Review Status',
				'rules' => 'trim|required|alpha|min_length[7]|max_length[11]'
			],
			[
				'field' => 'loan_type_id',
				'label' => 'Loan Type',
				'rules' => 'trim|required|max_length[9]'
			],
			[
				'field' => 'transaction_type',
				'label' => 'Transaction Type',
				'rules' => 'trim|required|alpha|min_length[8]|max_length[10]'
			],
			// [
			// 	'field' => 'loan_purpose',
			// 	'label' => 'Loan Purpose',
			// 	'rules' => 'trim|required|min_length[7]|max_length[17]'
			// ],
			// [
			// 	'field' => 'emp_id',
			// 	'label' => 'Analyst Name',
			// 	'rules' => 'trim|required|max_length[10]'
			// ],
			[
				'field' => 'comments',
				'label' => 'Comments',
				'rules' => 'trim|required|min_length[3]|max_length[200]'
			]
		],

		'update_loan_info' => [
			[
				'field' => 'borrower_name',
				'label' => 'Borrower Name',
				'rules' => 'trim|required|alpha|min_length[3]|max_length[50]'
			],
			[
				'field' => 'state',
				'label' => 'State',
				'rules' => 'trim|alpha|min_length[2]|max_length[4]'
			],
			[
				'field' => 'review_type_id',
				'label' => 'Review Type',
				'rules' => 'trim|required|min_length[2]|max_length[20]'
			],
			[
				'field' => 'channel_id',
				'label' => 'Channel',
				'rules' => 'trim|required|min_length[3]|max_length[10]'
			],
			// [
			// 	'field' => 'loan_type_id',
			// 	'label' => 'Loan Type',
			// 	'rules' => 'trim|required|min_length[2]|max_length[20]'
			// ],
			// [
			// 	'field' => 'transaction_type',
			// 	'label' => 'Transaction Type',
			// 	'rules' => 'trim|required|min_length[2]|max_length[20]'
			// ],
			// [
			// 	'field' => 'loan_purpose',
			// 	'label' => 'Loan Purpose',
			// 	'rules' => 'trim|required|min_length[2]|max_length[20]'
			// ]
		],

		'update_skillset' => [
			[
				'field' => 'emp_id',
				'label' => 'Employee ID',
				'rules' => 'callback_valid_empId'
			],
			[
				'field' => 'emp_fname',
				'label' => 'First Name',
				'rules' => 'trim|required|alpha|min_length[3]|max_length[50]'
			],
			[
				'field' => 'emp_lname',
				'label' => 'Last Name',
				'rules' => 'trim|required|alpha|max_length[50]'
			],
			[
				'field' => 'mail_id',
				'label' => 'Mail ID',
				'rules' => 'trim|required|valid_email'
			],
			[
				'field' => 'user_type',
				'label' => 'User Type',
				'rules' => 'callback_valid_userType'
			],
		],

		'personal_information' => [
			[
				'field' => 'emp_fname',
				'label' => 'First Name',
				'rules' => 'trim|required|alpha|min_length[3]|max_length[50]'
			],
			[
				'field' => 'emp_lname',
				'label' => 'Last Name',
				'rules' => 'trim|required|alpha|min_length[3]|max_length[50]'
			],
			[
				'field' => 'mail_id',
				'label' => 'Mail ID',
				'rules' => 'trim|required|valid_email'
			],
		],
		'password_update_rules' => [
			[
				'field' => 'current_password',
				'label' => 'Password',
				'rules' => 'callback_current_password'
			],
			[
				'field' => 'new_password',
				'label' => 'Password',
				'rules' => 'callback_valid_password'
			],
			[
				'field' => 'confirm_password',
				'label' => 'Confirm Password',
				'rules' => 'required|matches[new_password]'
			],

		],

	];

?>