<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserModel extends CI_Model {

	// get the currect date and time
	public function currectDateTime(){		
		date_default_timezone_set("US/Eastern");
  		$current_date_time = date("Y-m-d H:i:s"); 
  		return $current_date_time;
	} 

	// Personal Information
		public function personal_information_update($formArray){
			$this->db->set(['emp_fname'=>$formArray['emp_fname'], 'emp_lname'=>$formArray['emp_lname'], 'mail_id'=>$formArray['mail_id']]);
			$this->db->where('emp_id', $this->session->userdata('emp_id'));
			$result = $this->db->update('emp_details');
			return $result;
		}
	// reset password
		public function reset_password($id){
			$password = password_hash('welcome', PASSWORD_DEFAULT);
			$this->db->set('password', $password);
			$this->db->where('id', $id);
			$result = $this->db->update('emp_details');
			return $result;
		}

		// change password
		public function checkPassword($old_password){
			// print_r($old_password);exit();
			$this->db->where('emp_id', $this->session->userdata('emp_id'));
			// $this->db->where('emp_password', $old_password);
			$query = $this->db->get('emp_details')->row_array();
			
			$inputPass = $old_password;
			$hasPassword = $query['password'];
			// print_r("1");exit();
			if (password_verify($inputPass, $hasPassword)) {
				// print_r("2");exit();
				return true;
				
			}else{
				// print_r("3");exit();
				return false;
				
			}
			// print_r("4");exit();
		}

		public function changePassword($passwordEncode){
			$passwordDecode = base64_decode($passwordEncode);
			// print_r($passwordDecode);exit();
			$new_password = password_hash($passwordDecode, PASSWORD_DEFAULT);			
			// print_r($new_password);exit();
			$this->db->set('password', $new_password);
			$this->db->where('emp_id', $this->session->userdata('emp_id'));
			$this->db->update('emp_details');

			$this->session->set_flashdata('success', 'Password successfully Updated!');
			return redirect('login/logout');
		}
	// end

	// get the emp details (active only)
	public function getEmployees(){
		$this->db->where('status', '1');
		$query = $this->db->get('emp_details')->result_array();
		return $query;
	}
	// get the all emp details
	public function getAllEmployees(){
		// $this->db->where('status', '1');
		$query = $this->db->get('emp_details')->result_array();
		return $query;
	}

	// delete the emp id
	public function delete_empid($id){
		$this->db->set('status','3');
		$this->db->where('id', $id);
		$this->db->update('emp_details');
		return true;
	}


	// get the only specific emp details
	public function getSpecificEmployees(){
		$this->db->where('status !=', '3');
		$this->db->order_by('user_type', 'asc');
		$query = $this->db->get('emp_details')->result_array();
		return $query;
	}

	// get the analyst details
	public function getAnalyst(){
		$condition = "`status`='1' AND `user_type` IN('user4','user5','user6')";
		$this->db->where($condition);
		$query = $this->db->get('emp_details')->result_array();
		// echo $this->db->last_query(); exit();
		return $query;
	} 

	// get the indivisual emp details
	public function getEmpInfo($id){
		$this->db->where('id', $id);
		$result = $this->db->get('emp_details')->row_array();
		return $result;
	}
	// update the emp skillset
	public function update_skillset($formArray){
		// print($formArray['status']);exit();

		if(!empty($formArray['review_type_id'])){
			$review_type_id = implode(",", $formArray['review_type_id']);	
		}else{
			$review_type_id = NULL;
		}

		if(!empty($formArray['loan_type_id'])){
			$loan_type_id = implode(",", $formArray['loan_type_id']);	
		}else{
			$loan_type_id = NULL;
		}

		if(!empty($formArray['channel_id'])){
			$channel_id = implode(",", $formArray['channel_id']);	
		}else{
			$channel_id = NULL;
		}
					
		
		$this->db->set(['emp_id'=>$formArray['emp_id'], 'emp_fname'=>$formArray['emp_fname'], 'emp_lname'=>$formArray['emp_lname'], 'mail_id'=>$formArray['mail_id'], 'user_type'=>$formArray['user_type'] , 'review_type_id'=> $review_type_id, 'loan_type_id'=> $loan_type_id, 'channel_id'=> $channel_id, 'team'=> $formArray['team'], 'status'=>$formArray['status'] ]);
		$this->db->where('id', $formArray['id']);
		$result = $this->db->update('emp_details');
		// echo $this->db->last_query();exit();
		return $result;		
	}

	// add the new POD leader
	public function addNewPodLeader($formArray){
		$this->db->set('pod', $formArray['pod_no']);
		$this->db->where('id', $formArray['id']);
		$this->db->update('emp_details');
		return true;
	}

	// get the state list
	public function getAllState(){
		$this->db->where('status', 1);
		$this->db->order_by('type', 'asc');
		$result = $this->db->get('details_state')->result_array();
		// echo $this->db->last_query();exit();
		return $result;
	}
	// add the new state
	public function addNewState($formArray){
		$this->db->insert('details_state', $formArray);
		return true;
	}
	// state delete
	public function stateDelete($id){
		$this->db->where('id', $id);
		$this->db->delete('details_state');
		return true;
	}
	// update the state type (Licensed/Non-Licensed)
	public function stateTypeUpdate($data){
		// $id = base64_decode($data['id']);
		$id=$data['id'];
		$this->db->set('type', $data['state_type']);
		$this->db->where('id', $id);
		$this->db->update('details_state');
	}

	// update the state name
	public function stateNameUpdate($data){

		// $resultState = $this->getAllState();
		// foreach ($resultState as $state) {
		// 	if($state['postal_name'] == $data['state']){
		// 		if($state['type'] == 0){
		// 			$status = 0;
		// 			$state_type = 0;
		// 		}else{
		// 			$status = 1;
		// 			$state_type = 1;
		// 		}
		// 	}else{
		// 		$status = 1;
		// 		$state_type = 1;
		// 	}
		// }

		$this->db->where(['status'=>1, 'postal_name'=>$data['state']]);
		$result = $this->db->get('details_state')->row_array();
		if($result['type'] == 0){
			$status = 0;
			$state_type = 0;
		}else{
			$status = 1;
			$state_type = 1;
		}

		$this->db->set(['state'=>$data['state'], 'state_type'=>$state_type, 'status'=>$status]);
		$this->db->where('id', $data['id']);
		$this->db->update('current_task');
		if ($state_type == 0) {
			return false;
		}else{
			return true;
		}
	}



	// get the search loan no
		public function search_loan_details($loan_no){
			$this->db->where(['client_id'=>$this->session->userdata('client_id'), 'service_id'=>$this->session->userdata('service_id'), 'subservice_id'=>$this->session->userdata('subservice_id'), 'loan_no'=>$loan_no]);
			$result = $this->db->get('current_task')->row_array();
			return $result;
		}
		public function search_loan_details_byId($id){
			$id = base64_decode($id);
			$this->db->where(['client_id'=>$this->session->userdata('client_id'), 'service_id'=>$this->session->userdata('service_id'), 'subservice_id'=>$this->session->userdata('subservice_id'), 'id'=>$id]);
			$result = $this->db->get('current_task')->row_array();
			return $result;
		}
		public function review_status($loan_no){
			$this->db->where(['client_id'=>$this->session->userdata('client_id'), 'service_id'=>$this->session->userdata('service_id'), 'subservice_id'=>$this->session->userdata('subservice_id'), 'loan_no'=>$loan_no]);
			// $this->db->order_by('id', 'asc');
			$result = $this->db->get('review_status')->result_array();
			// echo $this->db->last_query();exit();
			return $result;	
		}
		public function review_status_byId($id){
			$id = base64_decode($id);
			// $this->db->where('id', $id);
			// $result = $this->db->get('current_task')->row_array();
			$this->db->where(['client_id'=>$this->session->userdata('client_id'), 'service_id'=>$this->session->userdata('service_id'), 'subservice_id'=>$this->session->userdata('subservice_id'), 'loan_id'=>$id]);
			// $this->db->order_by('id', 'asc');
			$result = $this->db->get('review_status')->result_array();
			// echo $this->db->last_query();exit();
			return $result;	
		}
		// loan no deleted by Id
		public function delete_loan_byId($id){
			$this->db->set('status',3);
			$this->db->where('id', $id);
			$this->db->update('current_task');

			$this->db->set('status',3);
			$this->db->where('loan_id', $id);
			$this->db->update('review_status');

			return true;
		}


	// get the client, service and subservice name
	public function getClientServiceSubserviceName(){
		// $this->db->select('*');
		// $this->db->from('details_client');
		// $this->db->join('details_service', 'details_service.client_id = details_client.client_id');
		// $this->db->where(['details_client.client_id'=>$this->session->userdata('client_id'), 'details_service.service_id'=>$this->session->userdata('service_id')]);

		$this->db->where(['client_id'=>$this->session->userdata('client_id'), 'service_id'=>$this->session->userdata('service_id'), 'subservice_id'=>$this->session->userdata('subservice_id')]);
		$result = $this->db->get('client_service_subservice')->row_array();
		// echo $this->db->last_query();exit();
		// return $query->row();
		return $result;
	}

	// get the review type
	public function getReviewData(){
		$this->db->where('status', 1);
		$result = $this->db->get('details_review_type')->result_array();
		// echo $this->db->last_query();exit();
		return $result;
	}

	// get the channel
	public function getChannelData(){
		$this->db->where('status', 1);
		$result = $this->db->get('details_channel')->result_array();
		// echo $this->db->last_query();exit();
		return $result;
	}

	// get the review type as per the session value
	public function get_review_id(){
		$this->db->select('*');
		$this->db->from('details_service');
		$this->db->join('details_review_type', 'details_review_type.service_id = details_service.service_id');
		$this->db->join('details_client', 'details_client.client_id = details_service.client_id');
		$this->db->where(['details_client.client_id'=>$this->session->userdata('client_id'), 'details_service.service_id'=>$this->session->userdata('service_id')]);
		$query = $this->db->get();
		// echo $this->db->last_query();
		// exit();
		return $query->result();
	}

	// get the client data
	public function getClientData(){
		// $this->db->select('details_client.client_id as client_id, details_client.client_name as client_name, details_service.service_id as service_id, details_service.service as service_name');
		$this->db->select('*');
		$this->db->from('details_client');
		$this->db->join('details_service', 'details_service.client_id = details_client.client_id');
		$this->db->where(['details_client.status'=>1, 'details_service.status'=>1]);
		$query = $this->db->get();
		// echo $this->db->last_query();
		// exit();
		return $query->result();
	}

	// get loan type
	public function get_loan_type_id(){
		$this->db->where('status', 1);
		$query = $this->db->get('details_loan_type')->result_array();
		// echo $this->db->last_query();exit();
		return $query;
	}
	// insert the loan
	public function insert_batch($data){
		// print("1");exit();
		$currentDate = $this->currectDateTime();
		$this->db->insert_batch('loans', $data);
		$query = $this->db->get('loans')->result_array();
		$resultState = $this->getAllState();

		foreach($query as $row) {
			$client_id = $this->session->userdata('client_id');
			$service_id = $this->session->userdata('service_id');
			$subservice_id = $this->session->userdata('subservice_id');

			$this->db->where('loan_no', $row['loan_no']);
			$result = $this->db->get('current_task')->row_array();	

			// $this->db->where(['staus'=> 1, 'review_type_id'=>$this->$row['review_type_id']]);

			if($result > 0){
				if(($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_03' && $this->session->userdata('subservice_id') == 'SR_003') || ($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_04' && $this->session->userdata('subservice_id') == 'SR_004')){
					// if(($result['received_date'] != $row['received_date']) && ((($result['review_type_id'] == 'RT_101' && $result['review_status'] == 'completed') || ($result['review_type_id'] == 'RT_102')) && ($row['review_type_id'] == 'RT_102') || (($result['review_type_id'] == 'RT_102' && $result['review_status'] == 'completed') && $result['review_type_id'] == 'RT_103'))) {

					if (($result['received_date'] != $row['received_date']) && (($result['review_type_id'] == 'RT_101' && $result['review_status'] == 'completed' && $row['review_type_id'] == 'RT_102') || ($result['review_type_id'] == 'RT_102' && ($result['review_status'] == 'completed' || $result['review_status'] == 'pending' || $result['review_status'] == 'pulledback') && $row['review_type_id'] == 'RT_102') || ($result['review_type_id'] == 'RT_102' && $result['review_status'] == 'completed' && $row['review_type_id'] == 'RT_103'))) {

						if($client_id != NULL && $service_id != NULL && $subservice_id != NULL && $row['review_type_id'] != NULL && $row['channel_id'] != NULL){
							$status = 1;
						}else{
							$status = 0;
						}
						if($row['emp_id'] !=''){
							$emp_id = $row['emp_id'];
							$assigned_by = $this->session->userdata('emp_id');
							$assigned_date = $currentDate;
							$priority = $row['priority'];
							$review_status = 'assigned';
							$channel_id = $row['channel_id'];

							$emp_details = $this->getAnalyst();
							foreach($emp_details as $emp) {
								if($emp['emp_id'] == trim($row['emp_id'])){
									$team = $emp['team'];
									break;
								}else{
									$team = NULL;
								}
							}
						}else{
							$emp_id = NULL;
							$assigned_by = NULL;
							$assigned_date = NULL;
							$priority = NULL;
							$review_status = 'unassigned';
							$channel_id = NULL;
							$team = NULL;
						}
						$sla_date = date('Y-m-d H:i:s', strtotime($row['received_date']. '+24 hour'));					
						$day = date('l', strtotime($sla_date)); 
						if($day == 'Saturday'){ 
							$sla_date = date('Y-m-d H:i:s', strtotime($sla_date.'+48 hour'));
						}elseif($day == 'Sunday'){
							$sla_date = date('Y-m-d H:i:s', strtotime($sla_date.'+24 hour'));
						}else{
							$sla_date = $sla_date;
						}
						$data = array(						
							'review_type_id'=>$row['review_type_id'],
							'received_date'=>$row['received_date'],
							'loan_type_id'=>$row['loan_type_id'],
							'sla_date'=>$sla_date,
							'upload_date'=>$currentDate,
							'uploaded_by'=>$this->session->userdata('emp_id'),
							'emp_id'=>$emp_id,
							'assigned_by'=>$assigned_by,
							'assigned_date'=>$assigned_date,
							'priority'=>$priority,
							'review_status'=>$review_status,
							'channel_id'=>$channel_id,
							'team'=>$team,
							'status'=>$status
						);
						$this->db->set($data);
						$this->db->where('id', $result['id']);
						$this->db->update('current_task');	
					}
				}else{
					if($result['client_id'] == $this->session->userdata('client_id') && $result['service_id'] == $this->session->userdata('service_id') && $result['subservice_id'] == $this->session->userdata('subservice_id') && $result['received_date'] != $row['received_date'] && $result['review_status'] != 'progress' ){
						if($row['loan_no'] != NULL && $client_id != NULL && $service_id != NULL && $subservice_id != NULL && $row['loan_type_id'] != NULL && $row['review_type_id'] != NULL){
							$status = 1;
						}else{
							$status = 0;
						}
						if($row['emp_id'] !=''){
							$emp_id = $row['emp_id'];
							$assigned_by = $this->session->userdata('emp_id');
							$assigned_date = $currentDate;
							$priority = $row['priority'];
							$review_status = 'assigned';
						}else{
							$emp_id = NULL;
							$assigned_by = NULL;
							$assigned_date = NULL;
							$priority = NULL;
							$review_status = 'unassigned';
						}
						$sla_date = date('Y-m-d H:i:s', strtotime($row['received_date']. '+24 hour'));					
						$day = date('l', strtotime($sla_date)); 
						if($day == 'Saturday'){ 
							$sla_date = date('Y-m-d H:i:s', strtotime($sla_date.'+48 hour'));
						}elseif($day == 'Sunday'){
							$sla_date = date('Y-m-d H:i:s', strtotime($sla_date.'+24 hour'));
						}else{
							$sla_date = $sla_date;
						}

						$data = array(						
							'review_type_id'=>$row['review_type_id'],
							'received_date'=>$row['received_date'],
							'loan_type_id'=>$row['loan_type_id'],
							'sla_date'=>$sla_date,
							'upload_date'=>$currentDate,
							'uploaded_by'=>$this->session->userdata('emp_id'),
							'emp_id'=>$emp_id,
							'assigned_by'=>$assigned_by,
							'assigned_date'=>$assigned_date,
							'priority'=>$priority,
							'review_status'=>$review_status,
							'status'=>$status
						);					
					}
				}
			}else{
				if(($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_03' && $this->session->userdata('subservice_id') == 'SR_003') || ($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_04' && $this->session->userdata('subservice_id') == 'SR_004')){
					
					// print_r($row['review_type_id']);
					// echo "<pre>";
					// print_r($row['channel_id']);
					// exit();

					if($client_id != NULL && $service_id != NULL && $subservice_id != NULL && $row['review_type_id'] != NULL && $row['channel_id'] != NULL ){
						$status = 1;
					}else{
						$status = 0;
					}

					if($row['emp_id'] !=''){
						$emp_id = $row['emp_id'];
						$assigned_by = $this->session->userdata('emp_id');
						$assigned_date = $currentDate;
						$priority = $row['priority'];
						$review_status = 'assigned';

						$emp_details = $this->getAnalyst();
						foreach($emp_details as $emp) {
							if($emp['emp_id'] == trim($row['emp_id'])){
								$team = $emp['team'];
								break;
							}else{
								$team = NULL;
							}
						}
					}else{
						$emp_id = NULL;
						$assigned_by = NULL;
						$assigned_date = NULL;
						$priority = NULL;
						$review_status = 'unassigned';
						$team = NULL;
					}

					// foreach ($resultState as $state) {

					// 	if($state['state_name'] == $row['state'] || $state['postal_name'] == $row['state']){
					// 		if($state['type'] == 0){
					// 			$status1 = 0;
					// 			$state_type = 0;
					// 		}else{
					// 			$status1 = 1;
					// 			$state_type = 1;
					// 		}
					// 	}else{
					// 		$status1 = 1;
					// 		$state_type = 1;
					// 	}
					// }

					$this->db->where(['status'=>1, 'postal_name'=>$row['state']]);
					$result = $this->db->get('details_state')->row_array();
					if($result > 0){
						if($result['type'] == 0){
							$status1 = 0;
							$state_type = 0;
						}else{
							$status1 = 1;
							$state_type = 1;
						}
					}else{
						$status1 = 1;
						$state_type = 1;
					}

					if(($status == 0 && $status1 == 0) || ($status == 1 && $status1 == 0) || ($status == 0 && $status1 == 1)){
						$status = 0;
					}else{
						$status =1;
					}

					$sla_date = date('Y-m-d H:i:s', strtotime($row['received_date']. '+24 hour'));					
					$day = date('l', strtotime($sla_date)); 
					if($day == 'Saturday'){ 
						$sla_date = date('Y-m-d H:i:s', strtotime($sla_date.'+48 hour'));
					}elseif($day == 'Sunday'){
						$sla_date = date('Y-m-d H:i:s', strtotime($sla_date.'+24 hour'));
					}else{
						$sla_date = $sla_date;
					}

					$data = array(
						'client_id'=>$row['client_id'],
						'service_id'=>$row['service_id'],
						'subservice_id'=>$row['subservice_id'],
						'review_type_id'=>$row['review_type_id'],
						'channel_id'=>$row['channel_id'],
						'loan_no'=>$row['loan_no'],
						'initial_received_date'=>$row['received_date'],
						'received_date'=>$row['received_date'],											
						'borrower_name'=>$row['borrower_name'],						
						'state'=>$row['state'],	
						'state_type'=>$state_type,
						'sla_date'=>$sla_date,
						'upload_date'=>$currentDate,
						'uploaded_by'=>$this->session->userdata('emp_id'),
						'emp_id'=>$emp_id,
						'assigned_by'=>$assigned_by,
						'assigned_date'=>$assigned_date,
						'priority'=>$priority,
						'review_status'=>$review_status,
						'team'=>$team,						
						'status'=>$status
					);
					$this->db->insert('current_task', $data);

				}else{
					// print_r("4");exit();
					if($row['loan_no'] != NULL && $client_id != NULL && $service_id != NULL && $subservice_id != NULL && $row['loan_type_id'] != NULL && $row['review_type_id'] != NULL){
					$status = 1;
					}else{
						$status = 0;
					}
					// print($status);exit();

					if($row['emp_id'] !=''){
						$emp_id = $row['emp_id'];
						$assigned_by = $this->session->userdata('emp_id');
						$assigned_date = $currentDate;
						$priority = $row['priority'];
						$review_status = 'assigned';
					}else{
						$emp_id = NULL;
						$assigned_by = NULL;
						$assigned_date = NULL;
						$priority = NULL;
						$review_status = 'unassigned';
					}

					$sla_date = date('Y-m-d H:i:s', strtotime($row['received_date']. '+24 hour'));					
					$day = date('l', strtotime($sla_date)); 
					if($day == 'Saturday'){ 
						$sla_date = date('Y-m-d H:i:s', strtotime($sla_date.'+48 hour'));
					}elseif($day == 'Sunday'){
						$sla_date = date('Y-m-d H:i:s', strtotime($sla_date.'+24 hour'));
					}else{
						$sla_date = $sla_date;
					}

					$data = array(
						'client_id'=>$row['client_id'],
						'service_id'=>$row['service_id'],
						'subservice_id'=>$row['subservice_id'],
						'review_type_id'=>$row['review_type_id'],
						'loan_no'=>$row['loan_no'],
						'initial_received_date'=>$row['received_date'],
						'received_date'=>$row['received_date'],					
						'branch'=>$row['branch'],
						'processing_branch'=>$row['processing_branch'],
						'borrower_name'=>$row['borrower_name'],
						'stage'=>$row['stage'],
						'subject_property'=>$row['subject_property'],
						'loan_type_id'=>$row['loan_type_id'],
						'program_code'=>$row['program_code'],
						'reocount'=>$row['reocount'],
						'oldest_date'=>$row['oldest_date'],
						'recent_date'=>$row['recent_date'],
						'xdoc_unfiled_docs'=>$row['xdoc_unfiled_docs'],
						'app_accepted_date'=>$row['app_accepted_date'],
						'loan_registration_analyst'=>$row['loan_registration_analyst'],
						'state'=>$row['state'],					
						// 'transaction_type'=>$row['transaction_type'],
						// 'loan_purpose'=>$row['loan_purpose'],
						'sla_date'=>$sla_date,
						'upload_date'=>$currentDate,
						'uploaded_by'=>$this->session->userdata('emp_id'),
						'emp_id'=>$emp_id,
						'assigned_by'=>$assigned_by,
						'assigned_date'=>$assigned_date,
						'priority'=>$priority,
						'review_status'=>$review_status,
						'status'=>$status
					);
					$this->db->insert('current_task', $data);
				}				
			}
		}
		$this->db->truncate('loans');
		return true;
	}
	


	////////////////////////////////////// get the assigned, progress and pending loans 
	public function getAssignedPendingLoans(){
		$this->db->where(['status'=>1, 'emp_id'=>$this->session->userdata('emp_id'), 'client_id'=>$this->session->userdata('client_id'), 'service_id'=>$this->session->userdata('service_id'), 'subservice_id'=>$this->session->userdata('subservice_id'), 'review_type_id'=>$this->session->userdata('review_type_id')]);
		$this->db->where('review_status !=', 'unassigned');
		$this->db->where('review_status !=', 'completed');
		$this->db->order_by('priority', 'desc');
		$this->db->order_by('assigned_date', 'asc');
		$query = $this->db->get('current_task')->result_array();
		// echo $this->db->last_query();exit();
		return $query;
	}
	// get the todays completed loans
	public function getTodaysCompletedLoans(){
		$currentDate = $this->currectDateTime();
		$presentDate = date('Y-m-d');
		$nextDate = date('Y-m-d', strtotime($presentDate. '1+ day'));

		$this->db->where(['status'=>1, 'client_id'=>$this->session->userdata('client_id'), 'service_id'=>$this->session->userdata('service_id'), 'subservice_id'=>$this->session->userdata('subservice_id'), 'review_type_id'=>$this->session->userdata('review_type_id'), 'emp_id'=>$this->session->userdata('emp_id'), 'review_status'=>'completed']);
		$result = $this->db->get('review_status')->result_array();
		// echo $this->db->last_query();exit();
		return $result;
	}

	// start the new activity
	public function startActivity($id){
		$currentDate = $this->currectDateTime();

  		$this->db->where(['id'=>$id, 'review_status'=>'assigned', 'emp_id'=>$this->session->userdata('emp_id')]);
  		$this->db->or_where('review_status', 'pending');
  		$query = $this->db->get('current_task')->row_array();
  		
  		if($query){
  			$this->db->set(['review_status'=>'progress','start_date'=>$currentDate]);
  			$this->db->where('id', $id);
  			$this->db->update('current_task');
  			return true;
  		}else{
  			return false;
  		}
	}

	// complete the activity
	public function complete_activity($formArray){
		$currentDate = $this->currectDateTime();
		$id = base64_decode($formArray['id']);
		$this->db->where(['id'=>$id, 'emp_id'=>$this->session->userdata('emp_id'), 'review_status'=>'progress']);
		$query = $this->db->get('current_task')->row_array();
		
		$resultState = $this->getAllState();

		if($query){

			// time calculation for time taken
			$endDate = new DateTime($currentDate);
   			$startDate = new DateTime($query['start_date']);
   			$time_taken = $startDate->diff($endDate);

            // time calculation for sla time taken
            $assignedDate = new DateTime($query['assigned_date']);
            $sla_time_taken = $assignedDate->diff($endDate);	

            if($formArray['review_status'] == 'pending'){
            	$time_taken = $time_taken->format('%d:%h:%i:%s');
            	$sla_time_taken = $sla_time_taken->format('%d:%h:%i:%s');

            	$explode = explode(':', $time_taken);
            	$day = $explode[0]*24*60*60;
            	$hour = $explode[1]*60*60;
            	$minute = $explode[2]*60;
            	$second = $explode[3];
            	$convertedTime = $day+$hour+$minute+$second;            	
            	$totalTime = $convertedTime/3600;
            	$explode = explode('.', $totalTime);
            	$hours = $explode[0]; //hours
            	$minutes = $explode[1];
            	$concatMix = '0.'.$minutes;
            	$minutes = $concatMix * 60;
            	$minutesSeconds = round($minutes,2);
            	$explode = explode('.', $minutesSeconds);
            	$minutes = $explode[0]; //minutes
            	$seconds = $explode[1]; //seconds
            	$total_time_taken = $hours.':'.$minutes.':'.$seconds;
            	$total_time_taken_minute = $convertedTime / 60;
            	$total_time_taken_second = $convertedTime;

            	// print($total_time_taken);exit();
            	$explode = explode(':', $sla_time_taken);
            	$day = $explode[0]*24*60*60;
            	$hour = $explode[1]*60*60;
            	$minute = $explode[2]*60;
            	$second = $explode[3];
            	$convertedTime = $day+$hour+$minute+$second;            	
            	$totalTime = $convertedTime/3600;
            	$explode = explode('.', $totalTime);
            	$hours = $explode[0]; //hours
            	$minutes = $explode[1];
            	$concatMix = '0.'.$minutes;
            	$minutes = $concatMix * 60;
            	$minutesSeconds = round($minutes,2);
            	$explode = explode('.', $minutesSeconds);
            	$minutes = $explode[0]; //minutes
            	$seconds = $explode[1]; //seconds
            	$total_sla_time_taken = $hours.':'.$minutes.':'.$seconds;
            	$total_sla_time_taken_minute = $convertedTime / 60;
            	$total_sla_time_taken_second = $convertedTime;

            }else{
            	$total_time_taken = NULL;
				$total_sla_time_taken = NULL; 
				$total_time_taken_minute = NULL;
				$total_sla_time_taken_minute = NULL; 
				$total_time_taken_second = NULL;
				$total_sla_time_taken_second = NULL; 
            }		
            
            if(!empty($formArray['state'])){
            	foreach ($resultState as $state) {
					if($state['postal_name'] == $formArray['state']){
						if($state['type'] == 0){
							$state_type = 0;
						}else{
							$state_type = 1;
						}
					}else{
						$state_type = 1;
					}
				}
				$state_name = $formArray['state'];
            }else{
            	$state_name = $query['state']; 
            	$state_type = $query['state_type'];
            }

            if(!empty($formArray['blue_print'])) {
				if($formArray['blue_print'] == 1){
					$blue_print = 1;
				}else{
					$blue_print = 0;	
				}
			}else{
				$blue_print = 0;
			}

			if(!empty($formArray['loan_purpose'])){
				$loan_purpose = $formArray['loan_purpose'];
			}else{
				$loan_purpose = "N/A";
			}

			$multipleInsert = array(
				'client_id'=>$query['client_id'],
				'service_id'=>$query['service_id'],
				'subservice_id'=>$query['subservice_id'],
				'review_type_id'=>$query['review_type_id'],
				'channel_id'=>$query['channel_id'],
				'loan_id'=>$id,
				'loan_no'=>$query['loan_no'],
				'initial_received_date'=>$query['initial_received_date'],
				'received_date'=>$query['received_date'],
				'branch'=>$query['branch'],
				'processing_branch'=>$query['processing_branch'],				
				'borrower_name'=>$query['borrower_name'],
				'stage'=>$query['stage'],
				'subject_property'=>$query['subject_property'],
				'loan_type_id'=>$formArray['loan_type_id'],
				'program_code'=>$query['program_code'],
				'reocount'=>$query['reocount'],
				'oldest_date'=>$query['oldest_date'],
				'recent_date'=>$query['recent_date'],
				'xdoc_unfiled_docs'=>$query['xdoc_unfiled_docs'],
				'app_accepted_date'=>$query['app_accepted_date'],
				'loan_registration_analyst'=>$query['loan_registration_analyst'],
				// 'income_type'=>$formArray['income_type'],
				'state'=>$state_name,
				'state_type'=>$state_type,	
				'sla_date'=>$query['sla_date'],
				'upload_date'=>$query['upload_date'],
				'uploaded_by'=>$query['uploaded_by'],
				'emp_id'=>$query['emp_id'],
				'assigned_by'=>$query['assigned_by'],
				'assigned_date'=>$query['assigned_date'],
				'priority'=>$query['priority'],
				'start_date'=>$query['start_date'],
				'end_date'=>$currentDate,
				'review_status'=>$formArray['review_status'],
				'transaction_type'=>$formArray['transaction_type'],
				'loan_purpose'=>$loan_purpose,
				'comments'=>$formArray['comments'],
				'blue_print'=>$blue_print,
				// 'time_taken'=>$total_time_taken,
				// 'sla_time_taken'=>$total_sla_time_taken,
				'time_taken_minute'=>$total_time_taken_minute,
				'sla_time_taken_minute'=>$total_sla_time_taken_minute,
				'time_taken_second'=>$total_time_taken_second,
				'sla_time_taken_second'=>$total_sla_time_taken_second
			);
			$this->db->insert('review_status', $multipleInsert);

			if($formArray['review_status'] == 'completed'){
				$this->db->where(['loan_no'=>$query['loan_no'], 'client_id'=>$this->session->userdata('client_id'), 'service_id'=>$this->session->userdata('service_id'), 'subservice_id'=>$query['subservice_id'], 'review_status'=>'completed']);
				$this->db->or_where('review_status', 'pending');
				$this->db->order_by('id', 'desc');
				$result = $this->db->get('review_status')->result_array();

				$convertedTime = 0;
				$convertedSlaTime = 0; 
				foreach($result as $row) {
					// time calculation for time taken
					$endDate = new DateTime($currentDate);
		   			$startDate = new DateTime($row['start_date']);
		   			$time_taken = $startDate->diff($endDate);

		            // time calculation for sla time taken
		            $assignedDate = new DateTime($row['assigned_date']);
		            $sla_time_taken = $assignedDate->diff($endDate);

					$time_taken = $time_taken->format('%d:%h:%i:%s');
            		$sla_time_taken = $sla_time_taken->format('%d:%h:%i:%s');
					
					$explode = explode(':', $time_taken);
	            	$day = $explode[0]*24*60*60;
	            	$hour = $explode[1]*60*60;
	            	$minute = $explode[2]*60;
	            	$second = $explode[3];
	            	$convertedTime = ($day+$hour+$minute+$second)+$convertedTime; 

	            	$explode = explode(':', $sla_time_taken);
	            	$day = $explode[0]*24*60*60;
	            	$hour = $explode[1]*60*60;
	            	$minute = $explode[2]*60;
	            	$second = $explode[3];
	            	$convertedSlaTime = ($day+$hour+$minute+$second)+$convertedSlaTime; 	            	
				}
				$total_time_taken_minute = $convertedTime / 60;
            	$total_time_taken_second = $convertedTime;

            	$total_sla_time_taken_minute = $convertedSlaTime / 60;
            	$total_sla_time_taken_second = $convertedSlaTime;
				
				$data = array(
					'time_taken_minute'=>$total_time_taken_minute,
					'sla_time_taken_minute'=>$total_sla_time_taken_minute,
					'time_taken_second'=>$total_time_taken_second,
					'sla_time_taken_second'=>$total_sla_time_taken_second
				);
				$this->db->where(['loan_no'=>$query['loan_no'], 'client_id'=>$this->session->userdata('client_id'), 'service_id'=>$this->session->userdata('service_id'), 'subservice_id'=>$query['subservice_id'], 'review_status'=>'completed']);
				$this->db->order_by('id', 'desc');
				$this->db->update('review_status', $data);
			}


			// update current task
			if(!empty($formArray['emp_id'])) {
				$emp_id = $formArray['emp_id'];
				$team = 0;				
				$review_status = 'assigned';
				$assigned_date = $currentDate;
			}else{
				$emp_id = $query['emp_id'];
				$team = 0;
				$review_status= $formArray['review_status'];
				$assigned_date = $query['assigned_date'];
			}
			if(!empty($formArray['blue_print'])) {
				if($formArray['blue_print'] == 1){
					$blue_print = 1;
				}else{
					$blue_print = 0;	
				}
			}else{
				$blue_print = 0;
			}

			$data = array(
				'review_status'=>$review_status,
				'emp_id'=>$emp_id,
				'assigned_date'=>$assigned_date,
				'end_date'=>$currentDate,
				'team'=>$team,
				'blue_print'=>$blue_print,
				'loan_type_id'=>$formArray['loan_type_id'],
				'transaction_type'=>$formArray['transaction_type'],
				'loan_purpose'=>$formArray['loan_purpose'],
				'state'=>$state_name,
				'state_type'=>$state_type,	

			);
			$this->db->where('id', $id);
			$this->db->update('current_task', $data);
			
			return true;
		}else{
			return false;
		}		
	}



	// get the client service and review type details
	public function getClientServiceReviewType(){
		$this->db->select('*, details_client.client_id as client_id, details_service.service_id as service_id,');
		$this->db->from('details_client');
		$this->db->join('details_service', 'details_service.client_id = details_client.client_id');
		$this->db->join('details_review_type', 'details_review_type.service_id = details_service.service_id');
		$query = $this->db->get();
		// echo $this->db->last_query();exit();
		return $query->result();		

	}
	// get the loan type details
	public function getLoanType(){
		$this->db->where('status', 1);
		$query = $this->db->get('details_loan_type')->result_array();
		// echo $this->db->last_query();exit();
		return $query;
	}
	// get the loan type details
	public function getChannel(){
		$this->db->where('status', 1);
		$query = $this->db->get('details_channel')->result_array();
		// echo $this->db->last_query();exit();
		return $query;
	}

	///////////////////////////////////////////////// export the report ////////////////////////////////////////////////
	public function export_report($formArray){
		$fromDate = $formArray['fromdate'];
		$toDate = $formArray['todate'];
		$nextDate = date("Y-m-d", strtotime($toDate. '+1 day'));

		$this->load->model('loginModel');
		$empDetails = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));
		$emp_id = $this->session->userdata('emp_id');
		// print($empDetails['user_type']);exit();

		if($empDetails['user_type'] == 'user5' OR $empDetails['user_type'] == 'user6'){
			$condition = "`emp_id`='$emp_id'";
		}else{
			$condition = "`emp_id` is not NULL";
		}

		$this->db->where(['status'=>1, 'client_id'=>$this->session->userdata('client_id'), 'service_id'=>$this->session->userdata('service_id'), 'subservice_id'=>$this->session->userdata('subservice_id'), 'review_status'=>'completed']);
		$this->db->where($condition);
		$this->db->where(['end_date >='=> $fromDate, 'end_date <'=> $nextDate,]);
		$query = $this->db->get('review_status')->result_array();

		// echo $this->db->last_query();exit();
		return $query;
	}




	/////////////////////////////////////////////// Supervisor Panel /////////////////////////////////////////////////

		// get the unassigned, assigned, pending loans
		public function getUAPLoans(){
			$this->db->where([
				'status'=>1, 
				'client_id'=>$this->session->userdata('client_id'), 
				'service_id'=>$this->session->userdata('service_id'), 
				'review_type_id'=>$this->session->userdata('review_type_id'), 
				'review_status !='=>'completed',
			]);
			$query = $this->db->get('current_task')->result_array();
			// echo $this->db->last_query();exit();
			return $query;
		} 

		// get the rejected loans
		public function getRejectedLoans(){
			$this->db->where([
				'status'=>0, 
				'state_type'=>0,
				'client_id'=>$this->session->userdata('client_id'), 
				'service_id'=>$this->session->userdata('service_id'), 
				'review_type_id'=>$this->session->userdata('review_type_id'), 
				'review_status !='=>'completed',
			]);
			$query = $this->db->get('current_task')->result_array();
			// echo $this->db->last_query();exit();
			return $query;
		} 

		// get the incoorect loans list
		public function getIncorrectLoans(){
			$this->db->where(['status'=>0, 'state_type'=>1]);
			$query = $this->db->get('current_task')->result_array();
			return $query;
		}

		// get the incorrect loans details
		public function getIncorrectLoanInfo($formArray){		
			$this->db->where(['id'=>$formArray['id'], 'status'=>0]);
			$query = $this->db->get('current_task')->row_array();
			// echo $this->db->last_query();exit();
			return $query;
		}

		// multiple loan assigne
		public function multiple_loan_assign($update){	
			$currentDate = $this->currectDateTime();

			foreach($this->input->post("update") as $id){
				if(!empty($this->input->post("emp_id_".$id))){
					$this->db->where('emp_id', $this->input->post("emp_id_".$id));
					$result = $this->db->get('emp_details')->row_array();

					$this->db->where('id', $id);
					$query = $this->db->get('current_task')->row_array();
					$multipleUpdate = [
						'status' => 1,
						'review_status' => 'assigned',
						'assigned_date' => $currentDate,
						'priority' => $this->input->post("priority_".$id),
						'emp_id' => $this->input->post("emp_id_".$id),
						'assigned_by' => $this->session->userdata('emp_id'),
						'team' => $result['team']
					];
					$this->db->set($multipleUpdate);
					$this->db->where('id', $id);
					$this->db->update('current_task');
				}
			}
			return true;
		}

		// get the todays all completed loans
		public function getTodaysAllEmpCompletedLoans(){
			$currentDate = $this->currectDateTime();
			$presentDate = date('Y-m-d');
			$nextDate = date('Y-m-d', strtotime($presentDate. '1+ day'));

			$this->db->where(['status'=>1, 'client_id'=>$this->session->userdata('client_id'), 'service_id'=>$this->session->userdata('service_id'), 'review_type_id'=>$this->session->userdata('review_type_id'), 'review_status'=>'completed']);
			$query = $this->db->get('review_status')->result_array();
			// echo $this->db->last_query();exit();
			return $query;
		}


		// update the incomplete loan information
		public function updateloansinfo($formArray){
			$id = $formArray['id'];
			$borrower_name = $formArray['borrower_name'];			
			$review_type_id = $formArray['review_type_id'];
			$channel_id = $formArray['channel_id'];
			// $loan_type_id = $formArray['loan_type_id'];
			// $transaction_type = $formArray['transaction_type'];
			// $loan_purpose = $formArray['loan_purpose'];

			$state = $formArray['state'];

			if(!empty($state)){
				$this->db->where(['status'=>1, 'postal_name'=>$state]);
				$result = $this->db->get('details_state')->row_array();
				if($result > 0){
					if($result['type'] == 0){
						$status = 0;
						$state_type = 0;
					}else{
						$status = 1;
						$state_type = 1;
					}
				}else{
					$status = 1;
					$state_type = 1;
				}
			}else{
				$status = 1;
				$state_type = 1;
			}

			

			$this->db->set(['borrower_name'=>$borrower_name, 'state'=>$state, 'state_type'=>$state_type, 'review_type_id'=>$review_type_id, 'channel_id'=>$channel_id, /*'loan_type_id'=>$loan_type_id, 'transaction_type'=>'transaction_type', 'loan_purpose'=>$loan_purpose,*/ 'status'=>$status]);
			$this->db->where('id', $id);
			$result = $this->db->update('current_task');
			if($result){
				return true;
			}else{
				return false;
			}
		}

	// End


}