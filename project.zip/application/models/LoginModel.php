<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginModel extends CI_Model {

	// get the employee details
		public function getEmpDetails($emp_id){
			$this->db->where(['emp_id'=>$emp_id, 'status'=>'1']);
			$result = $this->db->get('emp_details')->row_array();
			// echo $this->db->last_query();exit();
			if($result){
				return $result;
			}else{
				return false;
			}
			// echo $this->db->last_query();
		}
	// End


	// add new employee or add new registration
		public function new_registration($formArray){
			$this->db->insert('emp_details', $formArray);
		}

	// get the user type
		public function getUserType(){
			$this->db->where('status', 1);
			$result = $this->db->get('details_user_type')->result_array();
			return $result;
		}

	// get the client, service and subservice details 
		public function getClientServiceData(){
			$this->db->where('status', 1);
			$result = $this->db->get('client_service_subservice')->result_array();
			return $result;
		}

	// update the employee session id
		public function updateEmpSessionId(){
			$this->db->set('emp_session_id', $this->session->userdata('emp_session_id'));
			$this->db->where('emp_id', $this->session->userdata('emp_id'));
			$this->db->update('emp_details');
			return true;
		}
	// End
}