<!-- 

	1. user1 - Super Admin
	2. user2 - Supervisor
	3. user3 - Manager
	4. user4 - TL
	5. user5 - Special Analyst
	6. user6 - Analyst
	7. user7 - RTA

 -->


<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	// login page
	public function index(){


		$popularBrowsers = ["Opera","OPR/", "Edg", "Chrome", "Safari", "Firefox", "MSIE", "Trident"];
		$userAgent = $_SERVER['HTTP_USER_AGENT'];
		$userBrowser = 'Other less popular browsers';
		foreach ($popularBrowsers as $browser) {
		    if (strpos($userAgent, $browser) !== false) {
		        $userBrowser = $browser;
		        break;
		    }
		}
		// switch ($userBrowser) {
		//     case 'OPR/':
		//         $userBrowser = 'Opera';
		//         break;
		//     case 'MSIE':
		//         $userBrowser = 'Internet Explorer';
		//         break;

		//     case 'Trident':
		//         $userBrowser = 'Internet Explorer';
		//         break;

		//     case 'Edg':
		//         $userBrowser = 'Microsoft Edge';
		//         break;
		// }

		if($userBrowser != 'Chrome'){
			echo "<b>".$userBrowser."</b> browser is not compatible for the WMS application. Please use the <b>Chrome browser</b>.";
		}else{
			$data['page'] = 'Login page';
			$this->load->view('login',$data);
		}		
	}

	// register page
	public function register(){
		$data['page'] = 'Register page';
		$this->load->model('loginModel');
		$data['client_service_subservice'] = $this->loginModel->getClientServiceData();		
		$data['userType'] = $this->loginModel->getUserType();
		$this->load->view('register',$data);	
	}
	// new registration
	public function new_registration(){
		// print("ok");exit();
		$data['page'] = 'Register page';
		$this->load->model('loginModel');
		$data['client_service_subservice'] = $this->loginModel->getClientServiceData();
		$this->load->library('form_validation');
		if ($this->form_validation->run('new_registration')) {
			$formArray = $this->input->post();
			$this->loginModel->new_registration($formArray);
			$this->session->set_flashdata('success', 'Wait for the Supervisor Approval.');
			return redirect('login');
		} else {
			$this->load->view('register',$data);	
		}			
	}

	public function authentication(){
		$emp_id = $this->input->post('emp_id');
		$this->load->model('loginModel');		
		if($empDetails = $this->loginModel->getEmpDetails($emp_id)) {	
			// print_r("1");exit();		
			$password = $this->input->post('login[password]');
			if(password_verify($password, $empDetails['password'])) {
				$sessionArray['emp_id'] = $empDetails['emp_id'];

				session_regenerate_id();
				$sessionArray['emp_session_id'] = session_id();
				$this->session->set_userdata($sessionArray);
				$this->loginModel->updateEmpSessionId();
				$this->session->set_userdata( $sessionArray );			
				redirect('login/client_service_subservice');
			}else{
				$this->session->set_flashdata('password', 'Password is incorrect!');
				return redirect('login');
			}
		}else{
			// print_r("2");exit();
			$this->session->set_flashdata('emp_id', 'Please check your employee id!');
			return redirect('login');
			// print("Please enter the correct Employee ID.");
		}
	}


	public function client_service_subservice(){
		$data['page'] = 'Login Page';
		$this->load->model('loginModel');

		$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));
		$data['clientService'] = $this->loginModel->getClientServiceData();

		$this->load->view('index', $data);
	}

	// set the client id, service id and subservice id
	public function setClientSerive_id(){
		$formArray = $this->input->post();
		$this->load->model('loginModel');
		$empDetails = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

		if(!empty($formArray['client_service_subservice'])){
			$explode = explode("/", $formArray['client_service_subservice']);
			$explodeReviewType = explode(",", $empDetails['review_type_id']);

			$client_id = $explode[0];
			$service_id = $explode[1];
			$subservice_id = $explode[2];

			$review_type_id = $explodeReviewType[0];

			$array = array(
				'client_id' => $client_id,
				'service_id' => $service_id,
				'subservice_id' => $subservice_id,
				'review_type_id' => $review_type_id,
			);			
			$this->session->set_userdata($array);

			if($empDetails['user_type'] == 'user5' || $empDetails['user_type'] == 'user6') {
				return redirect('user/analyst_view');
			}elseif($empDetails['user_type'] == 'user4') {
				// return redirect('user/dashboard');
				return redirect('user/review_type');
			}elseif($empDetails['user_type'] == 'user3') {
				return redirect('user/manage_team');
			}	

		}else{
			$this->session->set_flashdata('error', 'Select the option!');
			return redirect('login/client_service_subservice');
		}
	}


	// Log Out
		public function logout(){
			// $this->session->unset_userdata('emp_id');
			$this->session->sess_destroy('sessionArray');
			redirect('login');
		}
	// End

}