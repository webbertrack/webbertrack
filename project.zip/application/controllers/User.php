<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH.'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class User extends CI_Controller {

	public function __construct(){
		parent::__construct();		
		$this->load->model('loginModel');
		$emp_info = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));
		if (($this->session->userdata('emp_session_id') != $emp_info['emp_session_id']) || (empty($this->session->userdata('emp_id')))) {
			$this->session->set_flashdata('error', 'Your session has been expired!');
			return redirect(base_url('login'));
		}		
	}

	// default
	public function user_type(){
		$this->load->model('loginModel');
		$emp_info = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));
		return $emp_info;
	}

	// my profile
		public function profile(){
			$data['page'] = 'My Profile';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['specificEmployees'] = $this->userModel->getSpecificEmployees();			

			$this->load->view('my_profile', $data);
		}
		public function update_my_information(){
			$data['page'] = 'My Profile';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	

			$formArray = $this->input->post();		
			$this->load->library('form_validation');
			if($this->form_validation->run('personal_information')) {
				if($this->userModel->personal_information_update($formArray)){
					$this->session->set_flashdata('success', 'Information updated successfully.');
					return redirect('user/profile');
				}else{
					$this->session->set_flashdata('error', 'Error!');
					$this->load->view('my_profile', $data);
				}
			}else{
				$this->load->view('my_profile', $data);
			}
		}

		// Update password 
		public function update_password(){			
			$data['page'] = 'My Profile';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	

			$this->load->library('form_validation');
			// print_r("1");exit();
			if ($this->form_validation->run('password_update_rules')) {	
				// print_r("3");exit();
				$passwordEncode = base64_encode($this->input->post('new_password'));
				$this->userModel->changePassword($passwordEncode);
			}else{
				// print_r("2");exit();
				$this->load->view('my_profile', $data);
			}
		}

		// check the current password
		public function current_password($current_password){
			$password = trim($current_password);
			// print_r("4");exit();
			$this->load->model('userModel');
			$result = $this->userModel->checkPassword($current_password);

			if (empty($password))
			{
				$this->form_validation->set_message('current_password', 'The {field} field is required.');
				return FALSE;
			}
			if($result == FALSE){
				$this->form_validation->set_message('current_password', 'The {field} does not match.');
				return FALSE;
			}
			return TRUE;
		}

		// valid the new password
		public function valid_password($password = ''){
			$password = trim($password);
			$regex_lowercase = '/[a-z]/';
			$regex_uppercase = '/[A-Z]/';
			$regex_number = '/[0-9]/';
			$regex_special = '/[!@#$%^&*()\-_=+{};:,<.>ยง~]/';

			if (empty($password))
			{
				$this->form_validation->set_message('valid_password', 'The {field} field is required.');

				return FALSE;
			}

			if (preg_match_all($regex_lowercase, $password) < 1)
			{
				$this->form_validation->set_message('valid_password', 'The {field} field must be at least one lowercase letter.');

				return FALSE;
			}

			if (preg_match_all($regex_uppercase, $password) < 1)
			{
				$this->form_validation->set_message('valid_password', 'The {field} field must be at least one uppercase letter.');

				return FALSE;
			}

			if (preg_match_all($regex_number, $password) < 1)
			{
				$this->form_validation->set_message('valid_password', 'The {field} field must have at least one number.');

				return FALSE;
			}

			if (preg_match_all($regex_special, $password) < 1)
			{
				$this->form_validation->set_message('valid_password', 'The {field} field must have at least one special character.' . ' ' . htmlentities('!@#$%^&*()\-_=+{};:,<.>ยง~'));

				return FALSE;
			}

			if (strlen($password) < 8)
			{
				$this->form_validation->set_message('valid_password', 'The {field} field must be at least 8 characters in length.');

				return FALSE;
			}

			if (strlen($password) > 32)
			{
				$this->form_validation->set_message('valid_password', 'The {field} field cannot exceed 32 characters in length.');

				return FALSE;
			}

			return TRUE;
		}

		// reset the password
		public function reset_password($id){
			$this->load->model('userModel');
			if($this->userModel->reset_password($id)){
				$this->session->set_flashdata('success', 'Password reset successfully.');
				return redirect('user/manage_team');
			}else{
				$this->session->set_flashdata('error', 'Error!');
				return redirect('user/manage_team');
			}
		} 
	// end

	// get the currect date and time
	public function currectDateTime(){		
		date_default_timezone_set("US/Eastern");
  		$current_date_time = date("Y-m-d H:i:s"); 
  		return $current_date_time;
	} 

	// loan search 
		public function loan_search(){
			$data['page'] = 'Loan Search';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['loan_type'] = $this->userModel->getLoanType();

			$this->load->view('loan_search', $data);	
		}
		// post method
		public function loan_information(){
			$data['page'] = 'Loan Search';
			$data['currentDate'] = $this->currectDateTime();
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['channel'] = $this->userModel->getChannelData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['loan_type'] = $this->userModel->getLoanType();
			$data['analystDetails'] = $this->userModel->getAllEmployees();
			$loan_no = $this->input->post('loan_no');
			$this->load->model('userModel');
			$this->load->library('form_validation');
			if ($this->form_validation->run('check_loan_no')) {
				if($data['loan_info']=$this->userModel->search_loan_details($loan_no)){
					$data['review_status_info']=$this->userModel->review_status($loan_no);
					$this->load->view('loan_information', $data);	
				}else{
					$this->session->set_flashdata('warning', 'Please Check the loan no.');
					return redirect('user/loan_search');
				}
			} else {
				$this->session->set_flashdata('error', 'Enter the correct Loan no!');
				return redirect('user/loan_search');
			}
		}
		// get method
		public function getLoanInformationById($id){
			$data['page'] = 'Loan Search';
			$data['currentDate'] = $this->currectDateTime();
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['channel'] = $this->userModel->getChannelData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['loan_type'] = $this->userModel->getLoanType();
			$data['analystDetails'] = $this->userModel->getAllEmployees();

			if($data['loan_info']=$this->userModel->search_loan_details_byId($id)){
				$data['review_status_info']=$this->userModel->review_status_byId($id);
				$this->load->view('loan_information', $data);	
			}else{
				$this->session->set_flashdata('warning', 'Please Check the loan no.');
				return redirect('user/loan_search');
			}
		}
		// delete the loan no. by id
		public function delete_loan_byId($id){
			$this->load->model('userModel');
			if($this->userModel->delete_loan_byId($id)){
				$this->session->set_flashdata('success', 'Loan no. successfully deleted.');
				return redirect('user/loan_search');
			}else{
				$this->session->set_flashdata('error', 'error!');
				return redirect('user/loan_search');
			}
		}
	// end

	// home page
		public function index(){
			$data['page'] = 'Home';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['client'] = $this->userModel->getClientData();

			$this->load->view('index', $data);
		}
		// set the client_id and service_id inside the session
		public function setClientSerive_id(){
			$formArray = $this->input->post();
			if($formArray['client_id'] !='' && $formArray['service_id'] !=''){
				$array = array(
					'client_id' => $formArray['client_id'],
					'service_id' => $formArray['service_id'],
				);			
				$this->session->set_userdata( $array );

				$this->load->model('loginModel');
				$empDetails = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));
				$explodeReviewType = explode(',', $empDetails['review_type_id']);
				$sessionArray['review_type_id'] = $explodeReviewType[0];
				$this->session->set_userdata($sessionArray);

				if($empDetails['user_type'] == 'user5' || $empDetails['user_type'] == 'user6') {
					return redirect('user/analyst_view');
				}elseif($empDetails['user_type'] == 'user3' || $empDetails['user_type'] == 'user4'){
					// return redirect('user/dashboard');
					return redirect('user/review_type');
				}			
			}else{
				if($formArray['client_id'] == '') {
					$this->session->set_flashdata('client_error', 'Select the client name!');
				}if($formArray['service_id'] == '') {
					$this->session->set_flashdata('service_error', 'Select the service!');
				}
				return redirect('user/index');
			}
			exit();
		}
	// End 

	// dashboard
	public function dashboard(){
		$data['page'] = 'Dashboard';
		$this->load->model('loginModel');
		$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

		$this->load->model('userModel');
		$data['reviewType'] = $this->userModel->getReviewData();
		$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();

		// $data['loans'] = $this->userModel->getAssignedPendingLoans();			

		$this->load->view('dashboard', $data);
	}

	// State
	public function state(){
		$emp_info = $this->user_type();
			if($emp_info['user_type'] == 'user6'){
				return redirect('user/analyst_view');
			}
			$data['page'] = 'State';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			// $data['loan_type'] = $this->userModel->getLoanType();
			// $data['UAPloans'] = $this->userModel->getUAPLoans();
			// $data['analystDetails'] = $this->userModel->getEmployees();
			// $data['incorrectLoans'] = $this->userModel->getIncorrectLoans();
			// $data['specificEmployees'] = $this->userModel->getSpecificEmployees();	
			$data['stateList'] = $this->userModel->getAllState();

			$this->load->view('state', $data);
	}
	// add the new state
	public function addNewState(){
		$emp_info = $this->user_type();
		if($emp_info['user_type'] == 'user6'){
			return redirect('user/analyst_view');
		}
		$this->load->library('form_validation');
		
		if ($this->form_validation->run('add_state_rules')) {
			$formArray = $this->input->post();
			$this->load->model('userModel');
			if($this->userModel->addNewState($formArray)){
				$this->session->set_flashdata('success', 'State has been added successfully.');
				return redirect('user/state');
			}else{
				$this->session->set_flashdata('error', 'State not added successfully!');
				return redirect('user/state');
			}

		}else{
			$this->session->set_flashdata('error', 'Please insert the correct state.');
			return redirect('user/state');
		}
	}
	// update the state 
	public function updateState(){
		if($this->input->post('btn_save')){
			print_r($this->input->post('state'));exit();
		}
		
	}
	// delete the state
	public function stateDelete($id){
		// $id = base64_decode($id);
		$this->load->model('userModel');
		$this->userModel->stateDelete($id);

		$this->session->set_flashdata('success', 'State has been deleted!');
		return redirect('user/state');
	}
	// State type update (Licensed/Non-Licensed)
	public function stateTypeNonLicensed($id){
		$data['id'] = $id;
		$data['state_type'] = 0;
		$this->load->model('userModel');
		$this->userModel->stateTypeUpdate($data);
		$this->session->set_flashdata('success', 'State type has been updated!');
		return redirect('user/state');
	}
	public function stateTypeLicensed($id){
		$data['id'] = $id;
		$data['state_type'] = 1;
		$this->load->model('userModel');
		$this->userModel->stateTypeUpdate($data);
		$this->session->set_flashdata('success', 'State type has been updated!');
		return redirect('user/state');
	}


	// Incomplete Loan Information List
		public function incorrect_loans_list(){
			$emp_info = $this->user_type();
			if($emp_info['user_type'] == 'user6'){
				return redirect('user/analyst_view');
			}
			// print("3");exit();
			$data['page'] = 'Incomplete Loan Information List';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['loan_type'] = $this->userModel->getLoanType();
			$data['UAPloans'] = $this->userModel->getUAPLoans();
			$data['analystDetails'] = $this->userModel->getEmployees();
			$data['incorrectLoans'] = $this->userModel->getIncorrectLoans();
			$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	

			// if($this->input->post('btn_edit')){
			// 	$formArray = $this->input->post();
			// 	$this->load->model('userModel');
			// 	if($data['loan'] = $this->userModel->getIncorrectLoanInfo($formArray)){
			// 		// print("1");exit();
			// 		$this->load->view('update_loan_info', $data);
			// 	}else{
			// 		$this->session->set_flashdata('error', 'Wrong attempt!');
			// 	}
			// }else{
			// 	$this->load->view('incorrect_loans_list', $data);
			// }

			$this->load->view('incorrect_loans_list', $data);
		}

	public function loan_info(){
		$formArray = $this->input->post();
		// $id = base64_decode($id);
		// print($id);exit();
		$data['page'] = 'Incomplete Loan Information List';
		$this->load->model('loginModel');
		$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

		$this->load->model('userModel');
		$data['reviewType'] = $this->userModel->getReviewData();
		$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
		$data['loan_type'] = $this->userModel->getLoanType();
		$data['channelData'] = $this->userModel->getChannelData();
		$data['incorrectLoans'] = $this->userModel->getIncorrectLoans();
		$data['stateList'] = $this->userModel->getAllState();

		$formArray = $this->input->post();
		$data['loan'] = $this->userModel->getIncorrectLoanInfo($formArray);


		// if($this->input->post('btn_update')){
			// $this->load->library('form_validation');
			// if ($this->form_validation->run('update_loan_info')) {
			// 	print("success");exit();
			// } else {
			// 	print("1");exit();
			// }
		// }


		$this->load->view('update_loan_info', $data);
	}

	// update the incorrect loan details
	public function updateloansinfo(){
		$data['page'] = 'Incomplete Loan Information List';
		$this->load->model('loginModel');
		$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

		$this->load->model('userModel');
		$data['reviewType'] = $this->userModel->getReviewData();
		$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
		$data['loan_type'] = $this->userModel->getLoanType();
		$data['channelData'] = $this->userModel->getChannelData();
		$data['incorrectLoans'] = $this->userModel->getIncorrectLoans();
		$data['stateList'] = $this->userModel->getAllState();			

		$formArray = $this->input->post();
		$data['loan'] = $this->userModel->getIncorrectLoanInfo($formArray);
		
			$formArray = $this->input->post();
			$this->load->library('form_validation');
			if ($this->form_validation->run('update_loan_info')) {
				if($this->userModel->updateloansinfo($formArray)){
					$this->session->set_flashdata('success', 'Loan successfully updated.');
					return redirect('user/incorrect_loans_list');
				}else{
					$this->session->set_flashdata('error', 'Loan information not updated successfully!');
					$this->load->view('update_loan_info', $data);	
				}
			} else {	
				$this->load->view('update_loan_info', $data);	
			}
		

		// exit();
	}

	// get the client list
	public function client_list(){
		$data['page'] = 'Client List';
		$this->load->model('loginModel');
		$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

		$this->load->model('userModel');
		$data['reviewType'] = $this->userModel->getReviewData();
		$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();

		// $data['loans'] = $this->userModel->getAssignedPendingLoans();			

		$this->load->view('client_service_subservice_list', $data);
	}


	// manage the team
	public function manage_team(){
		$emp_info = $this->user_type();
		if($emp_info['user_type'] == 'user6'){
			return redirect('user/analyst_view');
		}
		$data['page'] = 'Manage Team';
		$this->load->model('loginModel');
		$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

		$this->load->model('userModel');
		$data['reviewType'] = $this->userModel->getReviewData();
		$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
		$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	
		$data['analystDetails'] = $this->userModel->getEmployees();			

		$this->load->view('manage_team', $data);
	}
	// add the new POD leader
	public function addNewPodLeader(){
		$formArray = $this->input->post();
		$this->load->model('userModel');
		$this->userModel->addNewPodLeader($formArray);
		$this->session->set_flashdata('success', 'UW name successfully added under the POD.');
		return redirect('user/manage_team');
	}

	// delete the emp 
	public function delete_empid($id){
		$this->load->model('userModel');
		if($this->userModel->delete_empid($id)){
			$this->session->set_flashdata('success', 'Employee deleted successfully.');
			return redirect('user/manage_team');
		}else{
			$this->session->set_flashdata('error', 'Error!');
			return redirect('user/manage_team');
		}
	} 


	// 
	public function emp_details(){	
		$emp_info = $this->user_type();
		if($emp_info['user_type'] == 'user6'){
			return redirect('user/analyst_view');
		}	
		$data['page'] = 'Manage Team';
		$this->load->model('loginModel');
		$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

		$this->load->model('userModel');
		$data['loan_type'] = $this->userModel->getLoanType();
		$data['channel'] = $this->userModel->getChannel();
		$data['reviewType'] = $this->userModel->getReviewData();
		$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();		
		$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	
		$data['analystDetails'] = $this->userModel->getEmployees();

		if($this->userModel->getEmpInfo($this->input->post('id'))) {
			$data['emp_info'] = $this->userModel->getEmpInfo($this->input->post('id'));
			$this->load->view('emp_skillset_details', $data);	
		}else{
			$this->session->set_flashdata('error', 'Choose the correct Employee!');
			$this->load->view('manage_team', $data);
		}		
	}
	// update the emp skillset
	public function update_skillset(){
		$data['page'] = 'Manage Team';
		$this->load->model('loginModel');
		$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

		$this->load->model('userModel');
		$data['loan_type'] = $this->userModel->getLoanType();
		$data['channel'] = $this->userModel->getChannel();
		$data['reviewType'] = $this->userModel->getReviewData();
		$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
		$data['employees'] = $this->userModel->getEmployees();	
		$data['emp_info'] = $this->userModel->getEmpInfo($this->input->post('id'));
		$data['analystDetails'] = $this->userModel->getEmployees();	

		$formArray = $this->input->post();		
		$this->load->library('form_validation');
		// print("1");exit();	
		if($this->form_validation->run('update_skillset')) {
			if($this->userModel->update_skillset($formArray)){
				$this->session->set_flashdata('success', 'Skillset and details are updated successfully.');
				$data['emp_info'] = $this->userModel->getEmpInfo($this->input->post('id'));
				$this->load->view('emp_skillset_details', $data);
			}else{
				// print("2");exit();
				$this->session->set_flashdata('error', 'Skillset and details are not updated!');
				$this->load->view('emp_skillset_details', $data);
			}			
		}else{
			// print("3");exit();	
			$this->load->view('emp_skillset_details', $data);
		}	
		// print("4");exit();	
	}

	// emp id validation 
	public function valid_empId($empId = ''){
		$empId = trim($empId);
		$regex_special = '/[!@#$%^&*()\-_=+{};:,<.>ยง~]/';

		if (empty($empId))
		{
			$this->form_validation->set_message('valid_empId', 'The {field} field is required.');

			return FALSE;
		}
		if (preg_match_all($regex_special, $empId) > 0)
		{
			$this->form_validation->set_message('valid_empId', 'The {field} field not excepted any special character.' . ' ' . htmlentities('!@#$%^&*()\-_=+{};:,<.>ยง~'));

			return FALSE;
		}
		return TRUE;
	}

	// user type validation
	public function valid_userType($userType = ''){
		$userType = trim($userType);
		$regex_special = '/[!@#$%^&*()\-_=+{};:,<.>ยง~]/';

		if (empty($userType))
		{
			$this->form_validation->set_message('valid_userType', 'The {field} field is required.');

			return FALSE;
		}
		if (preg_match_all($regex_special, $userType) > 0)
		{
			$this->form_validation->set_message('valid_userType', 'The {field} field not excepted any special character.' . ' ' . htmlentities('!@#$%^&*()\-_=+{};:,<.>ยง~'));

			return FALSE;
		}
		return TRUE;
	}
	
	

	// data upload
	public function loan_upload(){
		$emp_info = $this->user_type();
		if($emp_info['user_type'] == 'user6'){
			return redirect('user/analyst_view');
		}
		$data['page'] = 'Loan Upload';
		$this->load->model('loginModel');
		$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

		$this->load->model('userModel');
		$data['reviewType'] = $this->userModel->getReviewData();
		$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
		$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	

		// $data['loans'] = $this->userModel->getAssignedPendingLoans();			

		$this->load->view('loan_upload', $data);
	}


	// import the data
	public function import_data(){
  		$currentDate = $this->currectDateTime();
  		if($this->input->post('upload')) {
  			$upload_file = $_FILES['upload_file']['name'];
			$extension = pathinfo($upload_file, PATHINFO_EXTENSION);			
			if($extension == 'xlsx') {
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
				$spreadsheet = $reader->load($_FILES['upload_file']['tmp_name']);
				$sheetdata = $spreadsheet->getActiveSheet()->toArray();
				$sheetcount = count($sheetdata);
				if ($sheetcount > 1){
					if($this->session->userdata('client_id') == 'CL_34' && $this->session->userdata('service_id') == 'SR_02' && $this->session->userdata('subservice_id') == 'SR_002') {
						for($i=1; $i<$sheetcount; $i++){
							if(trim($sheetdata[$i][0]) !='') {
								$loan_no = trim($sheetdata[$i][0]);
							}else{
								$loan_no = NULL;
							}

							if($sheetdata[$i][1] !='') {
								$branch = trim($sheetdata[$i][1]);
							}else{
								$branch = NULL;
							}

							if($sheetdata[$i][2] !='') {
								$processing_branch = trim($sheetdata[$i][2]);
							}else{
								$processing_branch = NULL;
							}

							if($sheetdata[$i][3] !=''){
								$borrower_name = trim($sheetdata[$i][3]);
							}else{
								$borrower_name = NULL;
							}

							if($sheetdata[$i][4] !='') {
								$stage = trim($sheetdata[$i][4]);
							}else{
								$stage = NULL;
							}
							
							if($sheetdata[$i][5] !='') {
								$subject_property = trim($sheetdata[$i][5]);
							}else{
								$subject_property = NULL;
							}

							if($sheetdata[$i][6] !=''){
								$this->load->model('userModel');
								$loan_type = $this->userModel->get_loan_type_id();
								foreach($loan_type as $row) {
									if($row['loan_type'] == trim($sheetdata[$i][6])){
										$loan_type_id = $row['loan_type_id'];
										break;
									}else{
										$loan_type_id = NULL;
									}								
								}
								// print($loan_type_id);
							}else{
								$loan_type_id = NULL;
							}

							if($sheetdata[$i][7] !='') {
								$program_code = trim($sheetdata[$i][7]);
							}else{
								$program_code = NULL;
							}

							if($sheetdata[$i][8] !='') {
								$reocount = trim($sheetdata[$i][8]);
							}else{
								$reocount = NULL;
							}


							if($sheetdata[$i][9] !='') {
								if(date('Y-m-d H:i:s', strtotime($sheetdata[$i][9])) <= $currentDate) {
									$oldest_date = date('Y-m-d H:i:s', strtotime($sheetdata[$i][9]));
								}else{
									$oldest_date = $currentDate;
								}
							}

							if($sheetdata[$i][10] !='') {
								if(date('Y-m-d H:i:s', strtotime($sheetdata[$i][10])) <= $currentDate) {
									$recent_date = date('Y-m-d H:i:s', strtotime($sheetdata[$i][10]));
								}else{
									$recent_date = $currentDate;
								}
							}


							if($sheetdata[$i][11] !='') {
								$xdoc_unfiled_docs = trim($sheetdata[$i][11]);
							}else{
								$xdoc_unfiled_docs = NULL;
							}

							if($sheetdata[$i][12] !='') {
								if(date('Y-m-d H:i:s', strtotime($sheetdata[$i][12])) <= $currentDate) {
									$app_accepted_date = date('Y-m-d H:i:s', strtotime($sheetdata[$i][12]));
								}else{
									$app_accepted_date = $currentDate;
								}
							}

							if($sheetdata[$i][13] !='') {
								$loan_registration_analyst = trim($sheetdata[$i][13]);
							}else{
								$loan_registration_analyst = NULL;
							}						

							if($sheetdata[$i][14] !='') {
								if(date('Y-m-d H:i:s', strtotime($sheetdata[$i][14])) <= $currentDate) {
									$received_date = date('Y-m-d H:i:s', strtotime($sheetdata[$i][14]));
								}else{
									$received_date = $currentDate;
								}
							}
							
							if($sheetdata[$i][15] !=''){
								$state = trim($sheetdata[$i][15]);
							}else{
								$state = NULL;
							}

							if($sheetdata[$i][16] !=''){
								$this->load->model('userModel');
								$reviewType = $this->userModel->getReviewData();
								$clientServiceSubserviceName = $this->userModel->getClientServiceSubserviceName();
								foreach($reviewType as $row) {
									if($row['review_type'] == trim($sheetdata[$i][16])){
										$review_type_id = $row['review_type_id'];
										$explode = explode(",", $clientServiceSubserviceName['review_type_id']); 
										if(in_array($review_type_id , $explode)){
											$review_type_id = $row['review_type_id'];
											break;
										}
									}else{
										$review_type_id = NULL;
									}
								}
							}else{
								$review_type_id = NULL;
							}

							if($sheetdata[$i][17] !=''){
								if($sheetdata[$i][17] == 'Rush'){
									$priority = 4;	
								}elseif($sheetdata[$i][17] == 'High'){
									$priority = 3;	
								}elseif($sheetdata[$i][17] == 'Medium'){
									$priority = 2;	
								}elseif($sheetdata[$i][17] == 'Low'){
									$priority = 1;	
								}						
							}else{
								$priority = NULL;
							}

							if($sheetdata[$i][18] !=''){							
								$this->load->model('userModel');
								$emp_details = $this->userModel->getAnalyst();
								foreach($emp_details as $row) {
									if($row['emp_id'] == trim($sheetdata[$i][18])){
										$emp_id = trim($sheetdata[$i][18]);
										break;
									}else{
										$emp_id = NULL;
									}
								}							
							}else{
								$emp_id = NULL;
							}
							
							// if($sheetdata[$i][19] !=''){
							// 	if(trim($sheetdata[$i][19]) == 'Purchase' || trim($sheetdata[$i][19]) == 'Refinance') {
							// 		$transaction_type = trim($sheetdata[$i][19]);
							// 	}else{
							// 		$transaction_type = NULL;
							// 	}
							// }else{
							// 	$transaction_type = NULL;
							// }

							// if($sheetdata[$i][20] !=''){
							// 	if(trim($sheetdata[$i][20]) == 'Cash out' || trim($sheetdata[$i][20]) == 'No Cash-out' || trim($sheetdata[$i][20]) == 'Limited Cash-out') {
							// 		$loan_purpose = trim($sheetdata[$i][20]);
							// 	}else{
							// 		$loan_purpose = NULL;
							// 	}
							// }else{
							// 	$loan_purpose = NULL;
							// }

							$data[] = array(
								'loan_no'=>$loan_no,
								'branch'=>$branch,
								'processing_branch'=>$processing_branch,
								'borrower_name'=>$borrower_name,
								'stage'=>$stage,
								'subject_property'=>$subject_property,
								'loan_type_id'=>$loan_type_id,
								'program_code'=>$program_code,
								'reocount'=>$reocount,
								'oldest_date'=>$oldest_date,
								'recent_date'=>$recent_date,
								'xdoc_unfiled_docs'=>$xdoc_unfiled_docs,
								'app_accepted_date'=>$app_accepted_date,
								'loan_registration_analyst'=>$loan_registration_analyst,							
								'received_date'=>$received_date,
								'state'=>$state,
								'review_type_id'=>$review_type_id,
								'priority'=>$priority,
								'emp_id'=>$emp_id,								
								// 'transaction_type'=>$transaction_type,
								// 'loan_purpose'=>$loan_purpose,							
								'client_id'=>$this->session->userdata('client_id'),
								'service_id'=>$this->session->userdata('service_id'),
								'subservice_id'=>$this->session->userdata('subservice_id'),
							);
						}
					}elseif(($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_03' && $this->session->userdata('subservice_id') == 'SR_003') || ($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_04' && $this->session->userdata('subservice_id') == 'SR_004')) {
						for($i=1; $i<$sheetcount; $i++){
							if(trim($sheetdata[$i][0]) !='') {
								$loan_no = trim($sheetdata[$i][0]);
							}else{
								$loan_no = 'Test'.rand(1,99);
							}	

							if($sheetdata[$i][1] !='') {
								if(date('Y-m-d H:i:s', strtotime($sheetdata[$i][1])) <= $currentDate) {
									$received_date = date('Y-m-d H:i:s', strtotime($sheetdata[$i][1]));
								}else{
									$received_date = $currentDate;
								}
							}else{
								$received_date = $currentDate;
							}						

							if(trim($sheetdata[$i][2]) !=''){
								$borrower_name = trim($sheetdata[$i][2]);
							}else{
								$borrower_name = NULL;
							}

							if($sheetdata[$i][3] !=''){
								$state = trim($sheetdata[$i][3]);
							}else{
								$state = NULL;
							}

							if(trim($sheetdata[$i][4]) !=''){
								$this->load->model('userModel');
								$reviewType = $this->userModel->getReviewData();
								$clientServiceSubserviceName = $this->userModel->getClientServiceSubserviceName();
								foreach($reviewType as $row) {
									if($row['review_type'] == trim($sheetdata[$i][4])){
										$review_type_id = $row['review_type_id'];
										$explode = explode(",", $clientServiceSubserviceName['review_type_id']); 
										if(in_array($review_type_id , $explode)){
											$review_type_id = $row['review_type_id'];
											break;
										}
									}else{
										$review_type_id = NULL;
									}
								}
							}else{
								$review_type_id = NULL;
							}

							if(trim($sheetdata[$i][5]) !=''){
								$this->load->model('userModel');
								$channelData = $this->userModel->getChannelData();
								// $emp_details = $this->userModel->getAnalyst();
								foreach($channelData as $row) {
									if($row['channel'] == trim($sheetdata[$i][5])){
										$channel_id = $row['channel_id'];
										break;										
									}else{
										$channel_id = NULL;
									}
								}
							}else{
								$channel_id = NULL;
							}

							if(trim($sheetdata[$i][6]) !=''){
								if(trim($sheetdata[$i][6]) == 'Rush'){
									$priority = 4;	
								}elseif(trim($sheetdata[$i][6]) == 'High'){
									$priority = 3;	
								}elseif(trim($sheetdata[$i][6]) == 'Medium'){
									$priority = 2;	
								}elseif(trim($sheetdata[$i][6]) == 'Low'){
									$priority = 1;	
								}						
							}else{
								$priority = NULL;
							}

							if(trim($sheetdata[$i][7]) !=''){							
								$this->load->model('userModel');
								$emp_details = $this->userModel->getAnalyst();
								foreach($emp_details as $row) {
									if($row['emp_id'] == trim($sheetdata[$i][7])){
										$emp_id = trim($sheetdata[$i][7]);
										// $team = $row['team'];
										break;
									}else{
										$emp_id = NULL;
										// $team = NULL;
									}
								}							
							}else{
								$emp_id = NULL;
								// $team = NULL;
							}

							$data[] = array(
								'loan_no'=>$loan_no,
								'received_date'=>$received_date,
								'borrower_name'=>$borrower_name,																						
								'state'=>$state,
								'review_type_id'=>$review_type_id,
								'channel_id'=>$channel_id,
								'priority'=>$priority,
								'emp_id'=>$emp_id,	
								// 'team'=>$team,						
								'client_id'=>$this->session->userdata('client_id'),
								'service_id'=>$this->session->userdata('service_id'),
								'subservice_id'=>$this->session->userdata('subservice_id'),
							);
						}
					}else{
						for($i=1; $i<$sheetcount; $i++){
							if(trim($sheetdata[$i][0]) !='') {
								$loan_no = trim($sheetdata[$i][0]);
							}else{
								$loan_no = NULL;
							}

							if($sheetdata[$i][1] !='') {
								if(date('Y-m-d H:i:s', strtotime($sheetdata[$i][1])) <= $currentDate) {
									$received_date = date('Y-m-d H:i:s', strtotime($sheetdata[$i][1]));
								}else{
									$received_date = $currentDate;
								}
							}
							if($sheetdata[$i][2] !=''){
								$borrower_name = trim($sheetdata[$i][2]);
							}else{
								$borrower_name = NULL;
							}
							if($sheetdata[$i][3] !=''){
								$state = trim($sheetdata[$i][3]);
							}else{
								$state = NULL;
							}
							if($sheetdata[$i][4] !=''){
								$this->load->model('userModel');
								$reviewType = $this->userModel->getReviewData();
								$clientServiceSubserviceName = $this->userModel->getClientServiceSubserviceName();
								
								// $review_type_id = $this->userModel->get_review_id();
								// foreach($review_type_id as $row) {
								// 	if($row->review_type == trim($sheetdata[$i][4])){
								// 		$review_type_id = $row->review_type_id;
								// 	}else{
								// 		$review_type_id = NULL;
								// 	}
								// }

								

								foreach($reviewType as $row) {
									if($row['review_type'] == trim($sheetdata[$i][4])){
										$review_type_id = $row['review_type_id'];
										$explode = explode(",", $clientServiceSubserviceName['review_type_id']); 
										if(in_array($review_type_id , $explode)){
											$review_type_id = $row['review_type_id'];
											break;
										}
									}else{
										$review_type_id = NULL;
									}
								}

							}else{
								$review_type_id = NULL;
							}

							if($sheetdata[$i][5] !=''){
								if($sheetdata[$i][5] == 'Rush'){
									$priority = 4;	
								}elseif($sheetdata[$i][5] == 'High'){
									$priority = 3;	
								}elseif($sheetdata[$i][5] == 'Medium'){
									$priority = 2;	
								}elseif($sheetdata[$i][5] == 'Low'){
									$priority = 1;	
								}						
							}else{
								$priority = NULL;
							}
							if($sheetdata[$i][6] !=''){							
								$this->load->model('userModel');
								$emp_details = $this->userModel->getAnalyst();
								foreach($emp_details as $row) {
									if($row['emp_id'] == trim($sheetdata[$i][6])){
										$emp_id = trim($sheetdata[$i][6]);
										break;
									}else{
										$emp_id = NULL;
									}
								}							
							}else{
								$emp_id = NULL;
							}
							if($sheetdata[$i][7] !=''){
								$this->load->model('userModel');
								$loan_type = $this->userModel->get_loan_type_id();
								foreach($loan_type as $row) {
									if($row['loan_type'] == trim($sheetdata[$i][7])){
										$loan_type_id = $row['loan_type_id'];
										break;
									}else{
										$loan_type_id = NULL;
									}								
								}
								// print($loan_type_id);
							}else{
								$loan_type_id = NULL;
							}
							if($sheetdata[$i][8] !=''){
								if(trim($sheetdata[$i][8]) == 'Purchase' || trim($sheetdata[$i][8]) == 'Refinance') {
									$transaction_type = trim($sheetdata[$i][8]);
								}else{
									$transaction_type = NULL;
								}
							}else{
								$transaction_type = NULL;
							}
							if($sheetdata[$i][9] !=''){
								if(trim($sheetdata[$i][9]) == 'Cash out' || trim($sheetdata[$i][9]) == 'No Cash-out' || trim($sheetdata[$i][9]) == 'Limited Cash-out') {
									$loan_purpose = trim($sheetdata[$i][9]);
								}else{
									$loan_purpose = NULL;
								}
							}else{
								$loan_purpose = NULL;
							}

							$data[] = array(
								'loan_no'=>$loan_no,
								'received_date'=>$received_date,
								'borrower_name'=>$borrower_name,
								'state'=>$state,
								'review_type_id'=>$review_type_id,
								'priority'=>$priority,
								'emp_id'=>$emp_id,
								'loan_type_id'=>$loan_type_id,
								'transaction_type'=>$transaction_type,
								'loan_purpose'=>$loan_purpose,							
								'client_id'=>$this->session->userdata('client_id'),
								'service_id'=>$this->session->userdata('service_id'),
								'subservice_id'=>$this->session->userdata('subservice_id'),
							);
						}
					}

					$this->load->model('userModel');
					if($this->userModel->insert_batch($data)) {
						$this->session->set_flashdata('success', 'File successfully inserted.');
						return redirect('user/loan_upload');
					}else{
						$this->session->set_flashdata('error', 'Error!');
					}
				}else{
					$this->session->set_flashdata('error', 'Your excel sheet is blank!');
					return redirect('user/loan_upload');	
				}
			}else{
				$this->session->set_flashdata('error', 'File format is incorrect!');
				return redirect('user/loan_upload');
			}
  		}else{
  			$this->session->set_flashdata('error', 'error!');
			return redirect('user/loan_upload');
  		}
  		
	}

	// Review Type
	public function review_type(){			
		// $sessionArray['review_type_id'] = base64_decode($review_type_id);
		// $this->session->set_userdata($sessionArray);
		// print_r("1");exit();

		$data['page'] = 'Review Type';
		$this->load->model('loginModel');
		$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

		$this->load->model('userModel');
		$data['reviewType'] = $this->userModel->getReviewData();
		$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();


		$data['UAPloans'] = $this->userModel->getUAPLoans();
		$data['allEmpCompletedLoans'] = $this->userModel->getTodaysAllEmpCompletedLoans();

		$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	

		$this->load->view('review_type', $data);
	}
	public function review_type1($review_type_id){	
		$emp_info = $this->user_type();
		if($emp_info['user_type'] == 'user6'){
			return redirect('user/analyst_view');
		}		
		$sessionArray['review_type_id'] = base64_decode($review_type_id);
		$this->session->set_userdata($sessionArray);

		$data['page'] = 'Review Type';
		$this->load->model('loginModel');
		$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

		$this->load->model('userModel');
		$data['reviewType'] = $this->userModel->getReviewData();
		$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();


		$data['UAPloans'] = $this->userModel->getUAPLoans();
		$data['allEmpCompletedLoans'] = $this->userModel->getTodaysAllEmpCompletedLoans();

		$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	

		$this->load->view('review_type', $data);
	}
	// shitch to review type
	public function switch_review_type($review_type_id){
		// print_r("1");exit();
		$sessionArray['review_type_id'] = $review_type_id;
		$this->session->set_userdata($sessionArray);
		return redirect('user/analyst_view');
	}

	///////////////////////////////////////////////// Analyst View ///////////////////////////////////////////////////////
	public function analyst_view(){
		// time convert (H;i:s)
			// $hour_one = "01:20:20";
			// $hour_two = "05:50:20";
			// $h =  strtotime($hour_one);
			// $h2 = strtotime($hour_two);

			// $minute = date("i", $h2);
			// $second = date("s", $h2);
			// $hour = date("H", $h2);

			// $convert = strtotime("+$minute minutes", $h);
			// print($convert);
			// echo "<pre>";
			// $convert = strtotime("+$second seconds", $convert);
			// print($convert);
			// echo "<pre>";
			// $convert = strtotime("+$hour hours", $convert);
			// print($convert);
			// echo "<pre>";
			// $new_time = date('H:i:s', $convert);
			// echo "<br>";
			// echo $new_time;
			// exit();
		// end

		$data['page'] = 'Analyst View';
		$this->load->model('loginModel');
		$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

		$this->load->model('userModel');
		$data['reviewType'] = $this->userModel->getReviewData();
		$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
		$data['currentDate'] = $this->currectDateTime();
		$data['loan_type'] = $this->userModel->getLoanType();
		$data['channel'] = $this->userModel->getChannel();
		$data['loans'] = $this->userModel->getAssignedPendingLoans();
		$data['todaysCompletedLoans'] = $this->userModel->getTodaysCompletedLoans();
		$data['analystDetails'] = $this->userModel->getEmployees();	
		$data['specificEmployees'] = $this->userModel->getSpecificEmployees();
		$data['stateList'] = $this->userModel->getAllState();	


		// complete the activity
		if($this->input->post('complete_activity')){			
			$formArray = $this->input->post();
			$this->load->library('form_validation');
			if($this->form_validation->run('complete_activity')){
				if($this->userModel->complete_activity($formArray)){
					if($formArray['review_status'] == 'completed'){
						$this->session->set_flashdata('success', 'Activity successfully completed.');
						return redirect('user/analyst_view');
					}elseif($formArray['review_status'] == 'pending'){
						$this->session->set_flashdata('warning', 'Activity is no hold.');
						return redirect('user/analyst_view');
					}
				}else{
					// print_r("1");exit();
					$this->session->set_flashdata('error', 'Error!');
					return redirect('user/analyst_view');
				}
			}	
			// print_r("2");exit();	
		}
		$this->load->view('analyst_view', $data);
	}

	// switch to review type
	public function reviewType($review_type_id){
		$sessionArray['review_type_id'] = $review_type_id;
		$this->session->set_userdata($sessionArray);
		return redirect('user/analyst_view');	
	}



	// Start the new activity
	public function start_activity(){
		$this->load->model('userModel');

		// update the state 
		if(!empty($this->input->post('state'))) {
			$data['id'] = $this->input->post('id');
			$data['state'] = $this->input->post('state');
			if($this->userModel->stateNameUpdate($data)){
				$this->session->set_flashdata('success', 'State has been updated.');
			}else{
				$this->session->set_flashdata('warning', 'State has been updated, but this is the Non-Licensed State, So supervisor approval is required!');
			}

		// state the new activity
		}else{
			$id = $this->input->post('id');
			if($this->userModel->startActivity($id)){
				$this->session->set_flashdata('success', 'Activity started.');
			}else{
				$this->session->set_flashdata('error', 'You can not start this activity!');
			}
		}
		return redirect('user/analyst_view');	
	}

	/////////////////////////////////////////////////////// export the report /////////////////////////////////////////////
	public function export_report(){
		if($this->input->post('export_report')) {
			$formArray = $this->input->post();
			$this->load->model('userModel');

			$loans = $this->userModel->export_report($formArray); 	
			header('Content-Type: application/vnd.ms-excel');
			header('Content-Disposition: attachment;filename="Report.xlsx"');
			$spreadsheet = new Spreadsheet();
			$sheet = $spreadsheet->getActiveSheet();

			if($this->session->userdata('client_id') == 'CL_34' && $this->session->userdata('service_id') == 'SR_02' && $this->session->userdata('subservice_id') == 'SR_002') {
				$sheet->setCellValue('A1', 'Client Name');
				$sheet->setCellValue('B1', 'Service');
				$sheet->setCellValue('C1', 'Subservice');
				$sheet->setCellValue('D1', 'Review Type');
				$sheet->setCellValue('E1', 'Loan No');
				$sheet->setCellValue('F1', 'Received Date');
				$sheet->setCellValue('G1', 'Branch');
				$sheet->setCellValue('H1', 'Processing Branch');				
				$sheet->setCellValue('I1', 'Borrower Name');
				$sheet->setCellValue('J1', 'Stage');
				$sheet->setCellValue('K1', 'Subject Property');
				$sheet->setCellValue('L1', 'Loan Type');
				$sheet->setCellValue('M1', 'Program');
				$sheet->setCellValue('N1', 'REOCount');
				$sheet->setCellValue('O1', 'Oldest');
				$sheet->setCellValue('P1', 'Recent');
				$sheet->setCellValue('Q1', 'Xdoc Unfiled Docs');
				$sheet->setCellValue('R1', 'App Accepted');
				$sheet->setCellValue('S1', 'Loan Registration Analyst');				
				$sheet->setCellValue('T1', 'State');				
				$sheet->setCellValue('U1', 'Transaction Type');
				$sheet->setCellValue('V1', 'Loan Purpose');
				$sheet->setCellValue('W1', 'Assigned Date');
				$sheet->setCellValue('X1', 'Analyst ID');
				$sheet->setCellValue('Y1', 'Analyst Name');
				$sheet->setCellValue('Z1', 'Start Date');
				$sheet->setCellValue('AA1', 'End Date');
				$sheet->setCellValue('AB1', 'Review Status');
				$sheet->setCellValue('AC1', 'Time Taken');
				$sheet->setCellValue('AD1', 'SLA');

				$sn=2;
				foreach($loans as $row) {
					// 
						$received_date = date('m/d/Y h:i:s A', strtotime($row['initial_received_date']));
						$oldest_date = date('m/d/Y h:i:s A', strtotime($row['oldest_date']));
						$recent_date = date('m/d/Y h:i:s A', strtotime($row['recent_date']));
						$app_accepted_date = date('m/d/Y h:i:s A', strtotime($row['app_accepted_date']));
						$assigned_date = date('m/d/Y h:i:s A', strtotime($row['assigned_date']));
						$start_date = date('m/d/Y h:i:s A', strtotime($row['start_date']));
						$end_date = date('m/d/Y h:i:s A', strtotime($row['end_date']));

						$time_taken_minute = round($row['time_taken_minute'],2);
		 				$sla_time_taken_minute = round($row['sla_time_taken_minute'],2);

						$reviewType = $this->userModel->getReviewData();
						$clientServiceSubserviceName = $this->userModel->getClientServiceSubserviceName();
						$loan_type = $this->userModel->getLoanType();
						$employees = $this->userModel->getEmployees();

						if($row['client_id'] == $clientServiceSubserviceName['client_id']){
							$client_name = $clientServiceSubserviceName['client_name']; 
						}
						if($row['service_id'] == $clientServiceSubserviceName['service_id']){
							$service_name = $clientServiceSubserviceName['service_name']; 
						}
						if($row['subservice_id'] == $clientServiceSubserviceName['subservice_id']){
							$subservice_name = $clientServiceSubserviceName['subservice_name']; 
						}

						foreach($reviewType as $review_type) {
							if($row['review_type_id'] == $review_type['review_type_id']){
								$review_type = $review_type['review_type'];
								break;
							}
						}

						foreach($loan_type as $value) {
							if($row['loan_type_id'] == $value['loan_type_id']) {
								$loan_type = $value['loan_type'];
								break;
							}
						}

						foreach($employees as $emp) {
							if($row['emp_id'] == $emp['emp_id']){
								$emp_name = $emp['emp_fname'].' '.$emp['emp_lname'];
								break;
							}
						}
					// 


					$sheet->setCellValue('A'.$sn, $client_name);
					$sheet->setCellValue('B'.$sn, $service_name);
					$sheet->setCellValue('C'.$sn, $subservice_name);
					$sheet->setCellValue('D'.$sn, $review_type);
					$sheet->setCellValue('E'.$sn, $row['loan_no']);
					$sheet->setCellValue('F'.$sn, $received_date);
					$sheet->setCellValue('G'.$sn, $row['branch']);
					$sheet->setCellValue('H'.$sn, $row['processing_branch']);
					$sheet->setCellValue('I'.$sn, $row['borrower_name']);
					$sheet->setCellValue('J'.$sn, $row['stage']);
					$sheet->setCellValue('K'.$sn, $row['subject_property']);
					$sheet->setCellValue('L'.$sn, $loan_type);
					$sheet->setCellValue('M'.$sn, $row['program_code']);
					$sheet->setCellValue('N'.$sn, $row['reocount']);
					$sheet->setCellValue('O'.$sn, $oldest_date);
					$sheet->setCellValue('P'.$sn, $recent_date);
					$sheet->setCellValue('Q'.$sn, $row['xdoc_unfiled_docs']);
					$sheet->setCellValue('R'.$sn, $app_accepted_date);
					$sheet->setCellValue('S'.$sn, $row['loan_registration_analyst']);
					$sheet->setCellValue('T'.$sn, $row['state']);					
					$sheet->setCellValue('U'.$sn, $row['transaction_type']);
					$sheet->setCellValue('V'.$sn, $row['loan_purpose']);
					$sheet->setCellValue('W'.$sn, $assigned_date);
					$sheet->setCellValue('X'.$sn, $row['emp_id']);
					$sheet->setCellValue('Y'.$sn, $emp_name);
					$sheet->setCellValue('Z'.$sn, $start_date);
					$sheet->setCellValue('AA'.$sn, $end_date);
					$sheet->setCellValue('AB'.$sn, $row['review_status']);
					$sheet->setCellValue('AC'.$sn, $time_taken_minute);
					$sheet->setCellValue('AD'.$sn, $sla_time_taken_minute);

					$sn++;
				}

			}elseif(($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_03' && $this->session->userdata('subservice_id') == 'SR_003') || ($this->session->userdata('client_id') == 'CL_107' && $this->session->userdata('service_id') == 'SR_04' && $this->session->userdata('subservice_id') == 'SR_004')) {
				$sheet->setCellValue('A1', 'Client Name');
				$sheet->setCellValue('B1', 'Service');
				$sheet->setCellValue('C1', 'Subservice');
				$sheet->setCellValue('D1', 'Review Type');
				$sheet->setCellValue('E1', 'Loan No');
				$sheet->setCellValue('F1', 'Received Date');
				$sheet->setCellValue('G1', 'Borrower Name');
				$sheet->setCellValue('H1', 'State');
				$sheet->setCellValue('I1', 'Loan Type');
				$sheet->setCellValue('J1', 'Loan Purpose');
				$sheet->setCellValue('K1', 'Blue Print');
				$sheet->setCellValue('L1', 'Assigned Date');
				$sheet->setCellValue('M1', 'Analyst ID');
				$sheet->setCellValue('N1', 'Analyst Name');
				$sheet->setCellValue('O1', 'Start Date');
				$sheet->setCellValue('P1', 'End Date');
				$sheet->setCellValue('Q1', 'Review Status');
				$sheet->setCellValue('R1', 'Time Taken');
				$sheet->setCellValue('S1', 'SLA');

				$sn=2;
				foreach($loans as $row) {

					$received_date = date('m/d/Y h:i:s A', strtotime($row['initial_received_date']));
					$assigned_date = date('m/d/Y h:i:s A', strtotime($row['assigned_date']));
					$start_date = date('m/d/Y h:i:s A', strtotime($row['start_date']));
					$end_date = date('m/d/Y h:i:s A', strtotime($row['end_date']));

					$time_taken_minute = round($row['time_taken_minute'],2);
	 				$sla_time_taken_minute = round($row['sla_time_taken_minute'],2);


					// $client_service_reviewType = $this->userModel->getClientServiceReviewType();
					$reviewType = $this->userModel->getReviewData();
					$clientServiceSubserviceName = $this->userModel->getClientServiceSubserviceName();
					$loan_type = $this->userModel->getLoanType();
					$employees = $this->userModel->getEmployees();

					// foreach($client_service_reviewType as $value) {
					// 	if($row['client_id'] == $value->client_id){
					// 		$client_name = $value->client_name;
					// 		break;
					// 	}
					// }

					// foreach($client_service_reviewType as $value) {
					// 	if($row['service_id'] == $value->service_id){
					// 		$service_name = $value->service;
					// 		break;
					// 	}
					// }

					// foreach($client_service_reviewType as $value) {
					// 	if($row['review_type_id'] == $value->review_type_id){
					// 		$review_type_name = $value->review_type;
					// 		break;
					// 	}
					// }

					if($row['client_id'] == $clientServiceSubserviceName['client_id']){
						$client_name = $clientServiceSubserviceName['client_name']; 
					}
					if($row['service_id'] == $clientServiceSubserviceName['service_id']){
						$service_name = $clientServiceSubserviceName['service_name']; 
					}
					if($row['subservice_id'] == $clientServiceSubserviceName['subservice_id']){
						$subservice_name = $clientServiceSubserviceName['subservice_name']; 
					}

					foreach($reviewType as $review_type) {
						if($row['review_type_id'] == $review_type['review_type_id']){
							$review_type = $review_type['review_type'];
							break;
						}
					}

					foreach($loan_type as $value) {
						if($row['loan_type_id'] == $value['loan_type_id']) {
							$loan_type = $value['loan_type'];
							break;
						}
					}

					foreach($employees as $emp) {
						if($row['emp_id'] == $emp['emp_id']){
							$emp_name = $emp['emp_fname'].' '.$emp['emp_lname'];
							break;
						}
					}

					if($row['blue_print'] == 1){
						$blue_print = 'Yes';
					}else{
						$blue_print = 'No';
					}


					$sheet->setCellValue('A'.$sn, $client_name);
					$sheet->setCellValue('B'.$sn, $service_name);
					$sheet->setCellValue('C'.$sn, $subservice_name);
					$sheet->setCellValue('D'.$sn, $review_type);
					$sheet->setCellValue('E'.$sn, $row['loan_no']);
					$sheet->setCellValue('F'.$sn, $received_date);
					$sheet->setCellValue('G'.$sn, $row['borrower_name']);
					$sheet->setCellValue('H'.$sn, $row['state']);
					$sheet->setCellValue('I'.$sn, $loan_type);
					$sheet->setCellValue('J'.$sn, $row['loan_purpose']);
					$sheet->setCellValue('K'.$sn, $blue_print);
					$sheet->setCellValue('L'.$sn, $assigned_date);
					$sheet->setCellValue('M'.$sn, $row['emp_id']);
					$sheet->setCellValue('N'.$sn, $emp_name);
					$sheet->setCellValue('O'.$sn, $start_date);
					$sheet->setCellValue('P'.$sn, $end_date);
					$sheet->setCellValue('Q'.$sn, $row['review_status']);
					$sheet->setCellValue('R'.$sn, $time_taken_minute);
					$sheet->setCellValue('S'.$sn, $sla_time_taken_minute);

					$sn++;
				}	
			}
			
		}
		$writer = new Xlsx($spreadsheet);					
		$writer->save("php://output", "W");
	}



	//////////////////////////////////////////////////////// supervisor panel /////////////////////////////////////////////////

		// unassigned loans 
		public function unassignedloans(){
			$data['page'] = 'Review Type';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['loan_type'] = $this->userModel->getLoanType();
			$data['channel'] = $this->userModel->getChannel();
			$data['UAPloans'] = $this->userModel->getUAPLoans();
			$data['analystDetails'] = $this->userModel->getEmployees();
			$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	
			
			$this->load->view('unassigned_loans', $data);
		}
		// assigned loans 
		public function assignedloans(){
			$data['page'] = 'Review Type';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['loan_type'] = $this->userModel->getLoanType();
			$data['channel'] = $this->userModel->getChannel();
			$data['UAPloans'] = $this->userModel->getUAPLoans();
			$data['analystDetails'] = $this->userModel->getEmployees();
			$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	
			
			$this->load->view('assigned_loans', $data);
		}
		// progress loans 
		public function progressloans(){
			$data['page'] = 'Review Type';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['loan_type'] = $this->userModel->getLoanType();
			$data['UAPloans'] = $this->userModel->getUAPLoans();
			$data['analystDetails'] = $this->userModel->getEmployees();
			$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	
			
			$this->load->view('progress_loans', $data);
		}
		// pending loans 
		public function pendingloans(){
			$data['page'] = 'Review Type';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['loan_type'] = $this->userModel->getLoanType();
			$data['channel'] = $this->userModel->getChannel();
			$data['UAPloans'] = $this->userModel->getUAPLoans();
			$data['analystDetails'] = $this->userModel->getEmployees();
			$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	
			
			$this->load->view('pending_loans', $data);
		}
		// pulledback loans 
		public function pulledbackloans(){
			$data['page'] = 'Review Type';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['loan_type'] = $this->userModel->getLoanType();
			$data['channel'] = $this->userModel->getChannel();
			$data['UAPloans'] = $this->userModel->getUAPLoans();
			$data['analystDetails'] = $this->userModel->getEmployees();
			$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	
			
			$this->load->view('pulledback_loans', $data);
		}

		// rejected loans 
		public function rejectedloans(){
			$data['page'] = 'Rejected Loans';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['loan_type'] = $this->userModel->getLoanType();
			$data['channel'] = $this->userModel->getChannel();
			$data['rejectedloans'] = $this->userModel->getRejectedLoans();
			$data['analystDetails'] = $this->userModel->getEmployees();
			$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	
			
			$this->load->view('rejected_loans', $data);
		}

		// todays completed loans 
		public function todaysCompletedLoans(){
			$data['page'] = 'Review Type';
			$this->load->model('loginModel');
			$data['empDetails'] = $this->loginModel->getEmpDetails($this->session->userdata('emp_id'));

			$this->load->model('userModel');
			$data['reviewType'] = $this->userModel->getReviewData();
			$data['clientServiceSubserviceName'] = $this->userModel->getClientServiceSubserviceName();
			$data['loan_type'] = $this->userModel->getLoanType();
			$data['channel'] = $this->userModel->getChannel();
			// $data['UAPloans'] = $this->userModel->getUAPLoans();
			$data['allEmpCompletedLoans'] = $this->userModel->getTodaysAllEmpCompletedLoans();
			$data['analystDetails'] = $this->userModel->getEmployees();
			$data['specificEmployees'] = $this->userModel->getSpecificEmployees();	
			
			$this->load->view('todays_completed_loans', $data);
		}
		// loan assign
		public function loan_assign(){
			// print("5");exit();
			if($this->input->post('btn_assign')){
				if(!empty($this->input->post('update'))){
					$this->load->model('userModel');
					if($this->userModel->multiple_loan_assign($this->input->post("update"))){
						$this->session->set_flashdata('success', 'Loan has been assigned.');
						return redirect('user/unassignedloans');
					}					
				}else{
					$this->session->set_flashdata('warning', 'Select the loan no. first!');
					return redirect('user/unassignedloans');
				}
			}elseif($this->input->post('btn_reassign')){
				if(!empty($this->input->post('update'))){
					$this->load->model('userModel');
					if($this->userModel->multiple_loan_assign($this->input->post("update"))){
						$this->session->set_flashdata('success', 'Loan has been reassigned.');
						return redirect('user/assignedloans');
					}					
				}else{
					$this->session->set_flashdata('warning', 'Select the loan no. first!');
					return redirect('user/assignedloans');
				}
			}elseif($this->input->post('btn_progress')){
				if(!empty($this->input->post('update'))){
					$this->load->model('userModel');
					if($this->userModel->multiple_loan_assign($this->input->post("update"))){
						$this->session->set_flashdata('success', 'Loan has been reassigned.');
						return redirect('user/progressloans');
					}					
				}else{
					$this->session->set_flashdata('warning', 'Select the loan no. first!');
					return redirect('user/assignedloans');
				}
			}elseif($this->input->post('btn_pending')){
				if(!empty($this->input->post('update'))){
					$this->load->model('userModel');
					if($this->userModel->multiple_loan_assign($this->input->post("update"))){
						$this->session->set_flashdata('success', 'Loan has been reassigned.');
						return redirect('user/pendingloans');
					}					
				}else{
					$this->session->set_flashdata('warning', 'Select the loan no. first!');
					return redirect('user/pendingloans');
				}
			}else{
				print("error");
			}
		}



	// end
}