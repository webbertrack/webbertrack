<link rel="shortcut icon" type="image/x-icon" href="<?= base_url('assets/img/favicon.png') ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
<!-- <link rel="stylesheet" href="<?= base_url('assets/plugins/fontawesome/css/fontawesome.min.css') ?>"> -->
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/plugins/fontawesome/css/all.min.css') ?>">
<!-- <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>      -->
<link rel="stylesheet" href="<?= base_url('assets/plugins/datatables/datatables.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>"> </head>
<link rel="stylesheet" href="<?= base_url('assets/css/feathericon.min.css') ?>">
<!-- <link rel="stylesheet" href="<?= base_url('assets/css/select2.min.css') ?>"> -->
<!-- <link rel="stylesheet" href="../../../releases/v5.8.2/css/all.css"> </head> -->

<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/select2.css') ?>">


<style type="text/css">
	 @keyframes blinker {
        50% {
          opacity: 0;
        }
      }
</style>

<style type="text/css">
	
</style>