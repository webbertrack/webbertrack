<script src="<?= base_url('assets/js/jquery-3.5.1.min.js') ?>"></script>
<script src="<?= base_url('assets/js/popper.min.js') ?>"></script>
<script src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>
<!-- <script src="<?= base_url('assets/js/bootstrap.bundle.min.js') ?>"></script> -->
<script src="<?= base_url('assets/plugins/slimscroll/jquery.slimscroll.min.js') ?>"></script>
<script src="<?= base_url('assets/js/script.js') ?>"></script>
<script src="<?= base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?= base_url('assets/plugins/datatables/datatables.min.js') ?>"></script>
<!-- <script src="<?= base_url('assets/js/select2.min.js') ?>"></script> -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>


<!-- Plugins JS start-->
<script src="<?= base_url('assets/js/select2.full.min.js') ?>"></script>
<script src="<?= base_url('assets/js/select2-custom.js') ?>"></script>

<script type="text/javascript">
	$(document).ready(function() {
	    $('#example').DataTable();
	} );
</script>
<script type="text/javascript">
  $(document).ready(function() {
      $('#example1').DataTable();
  } );
</script>
<script type="text/javascript">
  $(document).ready(function() {
      $('#example2').DataTable();
  } );
</script>
<script type="text/javascript">
  $(document).ready(function() {
      $('#example3').DataTable();
  } );
</script>

<!-- <script type="text/javascript">
	$(document).ready(function() {
	    $('#select2').select2();
	});
</script> -->

<!-- Check Multiple Loans -->
  <script type="text/javascript">
    $(document).ready(function() {
      $('#checkAll').change(function() {
        if($(this).is(':checked')){
          $('input[name="update[]"]').prop('checked',true);

        }else{
          $('input[name="update[]"]').each(function(){
            $(this).prop('checked',false);
          });
        }
      });
      $('input[name="update[]"]').click(function(){
        var total_checkboxes = $('input[name="update[]"]').length;
        var total_checkboxes_checked = $('input[name="update[]"]:checked').length;
        if(total_checkboxes_checked == total_checkboxes){
          $('#checkAll').prop('checked',true);
        }else{
          $('#checkAll').prop('checked',false);
        }
      });
    });
  </script>


  <script>
      $(document).ready(function() {
          $("#search").mouseover(function() {
              $("#search").css("background-color", "#009688");
          });
          $("#search").mouseout(function() {
              $("#search").css("background-color", "#ffffff");
          });
      });
  </script>